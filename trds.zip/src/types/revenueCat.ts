/**
 * RevenueCat Integration Types & Entitlement Definitions for TRDS
 * Phase 6 — TRDS Premium
 */

export const TRDS_PREMIUM_ENTITLEMENT = 'trds_premium';

export type PackageType = 'monthly' | 'annual' | 'lifetime' | 'custom';

export interface RevenueCatPackage {
  identifier: string;
  packageType: PackageType;
  product: {
    identifier: string;
    description: string;
    title: string;
    price: number;
    priceString: string;
    currencyCode: string;
    subscriptionPeriod?: string;
    introductoryPrice?: {
      priceString: string;
      period: string;
      cycles: number;
    };
  };
  badgeText?: string;
  isPopular?: boolean;
}

export interface RevenueCatOffering {
  identifier: string;
  serverDescription: string;
  availablePackages: RevenueCatPackage[];
}

export interface CustomerEntitlement {
  identifier: string;
  isActive: boolean;
  willRenew?: boolean;
  periodType?: 'normal' | 'trial' | 'intro';
  latestPurchaseDateMillis?: number;
  originalPurchaseDateMillis?: number;
  expirationDateMillis?: number | null;
  productIdentifier?: string;
  isSandbox?: boolean;
}

export interface CustomerInfo {
  entitlements: {
    all: Record<string, CustomerEntitlement>;
    active: Record<string, CustomerEntitlement>;
  };
  activeSubscriptions: string[];
  allPurchasedProductIdentifiers: string[];
  latestExpirationDate?: string | null;
  originalAppUserId: string;
  requestDate: string;
}

export interface PremiumState {
  isPremium: boolean;
  entitlement: CustomerEntitlement | null;
  activePackageId: string | null;
  isConfigured: boolean; // whether real RevenueCat SDK key is connected
  isLoading: boolean;
  error: string | null;
  isDevelopmentMode: boolean; // testing flag when products are not in app store yet
}

export type PurchaseErrorCode =
  | 'PURCHASE_CANCELLED'
  | 'STORE_PROBLEM'
  | 'PURCHASE_NOT_ALLOWED'
  | 'PRODUCT_NOT_AVAILABLE'
  | 'NETWORK_ERROR'
  | 'INVALID_CREDENTIALS'
  | 'CONFIGURATION_ERROR'
  | 'RESTORE_NO_PURCHASES'
  | 'UNKNOWN_ERROR';

export interface PurchaseError {
  code: PurchaseErrorCode;
  message: string;
  userMessage: string;
  readableDetails?: string;
}
