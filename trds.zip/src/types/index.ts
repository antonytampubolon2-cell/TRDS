export type NavTab = 'home' | 'markets' | 'simulator' | 'learn' | 'ai' | 'profile';

export type ThemeMode = 'dark' | 'light';

export type AssetCategory = 'crypto' | 'stocks' | 'forex' | 'commodities';
export type MarketCategory = 'all' | 'crypto' | 'stocks' | 'forex' | 'commodities';
export type MarketFilter = 'all' | 'favorites' | 'trending' | 'gainers' | 'losers' | 'volume';
export type ChartTimeframe = '1H' | '4H' | '1D' | '1W' | '1M';

export interface MarketData {
  price: number;
  change24h: number; // percentage e.g. +3.42 or -1.18
  high24h: number;
  low24h: number;
  volume: string;
  sparkline: number[];
  timeframeData?: Record<ChartTimeframe, number[]>;
}

export interface Asset {
  id: string;
  symbol: string;
  name: string;
  category: AssetCategory;
  price: number;
  change24h: number; // percentage, e.g. +4.25 or -2.10
  high24h: number;
  low24h: number;
  volume: string;
  sparkline: number[];
  timeframeData?: Record<ChartTimeframe, number[]>;
  unit: string;
  description: string;
}

export interface Favorite {
  assetId: string;
  addedAt: number;
}

export interface PortfolioSummary {
  totalValue: number;
  simulatedPnL: number;
  pnlPercent: number;
  cashBalance: number;
  currency: string;
}

export type SimulatorTimeframe = '1m' | '5m' | '15m' | '1H' | '4H' | '1D';

export interface CandlestickBar {
  time: string;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  isUp: boolean;
}

export interface Holding {
  assetId: string;
  symbol: string;
  amount: number;
  avgBuyPrice: number;
  totalCost?: number;
}

export type OrderType = 'market' | 'limit';
export type OrderSide = 'buy' | 'sell';
export type OrderStatus = 'open' | 'filled' | 'cancelled';

export interface Order {
  id: string;
  assetId: string;
  symbol: string;
  type: OrderType;
  side: OrderSide;
  amount: number;
  price: number;
  status: OrderStatus;
  timestamp: number;
  filledAt?: number;
  cancelledAt?: number;
  fee?: number;
  totalValue?: number;
}

export interface Trade {
  id: string;
  orderId?: string;
  assetId: string;
  symbol: string;
  side: OrderSide;
  amount: number;
  price: number;
  totalValue: number;
  timestamp: number;
  fee?: number;
  costBasis?: number;
  simulatedPnL?: number; // Realized PnL from closed sell position
  journalEntry?: TradeJournalEntry;
}

export interface PnLBreakdown {
  unrealizedPnL: number;
  realizedPnL: number;
  totalPnL: number;
  pnlPercent: number;
}

export interface VirtualPortfolio {
  totalValue: number;
  cashBalance: number;
  assetValue: number;
  unrealizedPnL: number;
  realizedPnL: number;
  totalPnL: number;
  pnlPercent: number;
  currency: string;
}

export type LearningCategoryId =
  | 'basics'
  | 'market_price'
  | 'charts'
  | 'indicators'
  | 'risk'
  | 'psychology'
  | 'practice';

export interface LearningCategory {
  id: LearningCategoryId;
  title: string;
  subtitle: string;
  iconName: string;
  color: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  rewardXp: number;
  bonusPassXp?: number;
  questions: QuizQuestion[];
  isPremium?: boolean;
}

export interface QuizResult {
  quizId: string;
  lessonId: string;
  score: number;
  totalQuestions: number;
  passed: boolean;
  completedAt: number;
}

export interface LessonExample {
  title: string;
  scenario: string;
  analysis: string;
}

export interface Lesson {
  id: string;
  categoryId: LearningCategoryId;
  title: string;
  subtitle: string;
  track: 'beginner' | 'intermediate' | 'advanced';
  durationMinutes: number;
  xpReward: number;
  readTime: string;
  intro?: string;
  content: string[];
  example?: LessonExample;
  keyTakeaways: string[];
  quiz?: Quiz;
  isCompleted?: boolean;
  isPremium?: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  iconName: string;
  xpReward: number;
  isUnlocked: boolean;
  unlockedDate?: string;
  progress: number;
  maxProgress: number;
  isPremium?: boolean;
}

export interface UserProfile {
  name: string;
  handle: string;
  level: number;
  levelTitle: string;
  currentXp: number;
  nextLevelXp: number;
  totalXp?: number;
  streakDays: number;
  virtualBalance: number;
  initialBalance: number;
  tradesCount: number;
  profitableTradesCount: number;
  lessonsCompletedCount: number;
  quizzesPassedCount?: number;
  notificationsEnabled: boolean;
  soundEnabled: boolean;
  language: 'id' | 'en';
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: number;
  promptSuggestions?: string[];
  isError?: boolean;
  contextTag?: string;
}

export type AIMessage = ChatMessage;

export interface AIResponse {
  message: string;
  suggestions?: string[];
  source?: 'gemini' | 'educational_engine' | 'mock';
  error?: string;
}

export interface AIContext {
  portfolio?: {
    totalValue: number;
    cashBalance: number;
    assetValue: number;
    unrealizedPnL: number;
    realizedPnL: number;
    totalPnL: number;
    pnlPercent: number;
  };
  selectedAsset?: {
    id: string;
    symbol: string;
    name: string;
    price: number;
    change24h: number;
    category?: string;
  };
  simulator?: {
    openOrdersCount: number;
    holdingsCount: number;
    recentTradesCount: number;
  };
  learning?: {
    completedLessonsCount: number;
    totalLessons: number;
    progressPercent: number;
  };
  user?: {
    level: number;
    levelTitle: string;
    currentXp: number;
    totalXp: number;
    streakDays: number;
  };
  activeTarget?: {
    type: 'lesson' | 'quiz' | 'simulator' | 'general' | 'market_intelligence';
    title?: string;
    detail?: string;
    data?: any;
  };
}

export type MarketTrendType = 'Bullish' | 'Neutral' | 'Bearish';
export type MomentumType = 'Weak' | 'Moderate' | 'Strong';
export type VolatilityType = 'Low' | 'Medium' | 'High';

export type AdvancedMarketCondition = 'BULLISH' | 'BEARISH' | 'NEUTRAL' | 'MIXED';
export type AdvancedMomentumState = 'Strong Positive' | 'Positive' | 'Neutral' | 'Negative' | 'Strong Negative';
export type AdvancedVolatilityLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
export type AdvancedTrendContext = 'Uptrend Context' | 'Downtrend Context' | 'Range / Sideways' | 'Mixed';
export type AdvancedMarketStrengthType = 'Bullish Pressure' | 'Bearish Pressure' | 'Balanced';
export type VolumeContextState = 'Increasing' | 'Decreasing' | 'Average' | 'Unavailable';
export type AnalysisConfidenceLevel = 'HIGH DATA CONFIDENCE' | 'MEDIUM DATA CONFIDENCE' | 'LOW DATA CONFIDENCE';
export type AdvancedRiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'VERY HIGH';

export interface EducationalScenario {
  type: 'Bullish Scenario' | 'Neutral Scenario' | 'Bearish Scenario';
  title: string;
  supportingConditions: string;
  keyEducationalWatchpoint: string;
}

export interface DataQualityReport {
  status: import('./marketData').MarketDataStatus;
  statusLabel: string;
  lastUpdated: string;
  source: string;
  freshness: string;
  isStale: boolean;
}

export interface MarketViewSummary {
  condition: AdvancedMarketCondition;
  momentum: AdvancedMomentumState;
  volatility: AdvancedVolatilityLevel;
  trendContext: AdvancedTrendContext;
  marketStrength: string;
  riskContext: AdvancedRiskLevel;
  dataQuality: string;
  whyExplanation: string;
}

export interface IndicatorDetail {
  name: string;
  code: 'rsi' | 'macd' | 'ma' | 'bb' | 'volume' | 'momentum';
  value: string;
  status: string;
  explanation: string;
  lessonId?: string;
  conceptTitle: string;
  conceptSummary: string;
}

export interface MarketIntelligenceData {
  assetId: string;
  symbol: string;
  price: number;
  change24h: number;
  trend: MarketTrendType;
  trendExplanation: string;
  momentum: MomentumType;
  momentumExplanation: string;
  volatility: VolatilityType;
  volatilityExplanation: string;
  marketStrength: string;
  marketStrengthPercent: number;
  score: number; // 0-100 Educational Condition Score
  support: number;
  resistance: number;
  supportExplanation?: string;
  resistanceExplanation?: string;
  hasInsufficientSupportResistance?: boolean;
  volume: string;
  volumeEvaluation: string;
  indicators: IndicatorDetail[];
  rsi: IndicatorDetail;
  macd: IndicatorDetail;
  ma: IndicatorDetail;
  bollingerBands: IndicatorDetail;
  volumeIndicator: IndicatorDetail;
  priceMomentum: IndicatorDetail;
  whyAnalysis: {
    overview: string;
    factors: { title: string; detail: string; statusBadge: string }[];
    dataAvailability: 'real_simulated' | 'insufficient';
  };
  marketSummary: {
    whatHappened: string;
    whatToLearn: string;
  };
  riskContext: {
    volatilityNote: string;
    uncertaintyNote: string;
    trendStabilityNote: string;
    riskFactors: string[];
  };
  lastUpdated: string;
  isSimulatedData: boolean;
  dataStatus?: import('./marketData').MarketDataStatus;
  dataSource?: string;
  timestamp?: number;
  isStale?: boolean;
  changePercent24h?: number;

  // Advanced Multi-Factor Analysis Additions
  advancedCondition: AdvancedMarketCondition;
  conditionReasons: string[];
  advancedMomentum: AdvancedMomentumState;
  advancedMomentumExplanation: string;
  advancedVolatility: AdvancedVolatilityLevel;
  volatilityEducationalNote: string;
  trendContext: AdvancedTrendContext;
  trendContextExplanation: string;
  marketStrengthCategory: AdvancedMarketStrengthType;
  orderBookPressureAvailable: boolean;
  orderBookPressureNote: string;
  volumeContext: VolumeContextState;
  volumeContextExplanation: string;
  dataQuality: DataQualityReport;
  analysisConfidence: AnalysisConfidenceLevel;
  analysisConfidenceExplanation: string;
  riskLevel: AdvancedRiskLevel;
  riskPrimaryReasons: string[];
  marketView: MarketViewSummary;
  scenarios: EducationalScenario[];
}

export interface QuickQuestion {
  id: string;
  label: string;
  prompt: string;
  category?: 'basics' | 'simulator' | 'risk' | 'analysis';
}

export interface DailyChallenge {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  targetCount: number;
  currentCount: number;
  isCompleted: boolean;
  type: 'trade' | 'quiz' | 'view_market' | 'ask_ai' | 'lesson';
}

export * from './revenueCat';
export * from './marketData';

// ==========================================
// TRADE JOURNAL & TRADING PSYCHOLOGY TYPES
// ==========================================

export type EntryReasonCategory =
  | 'trend_following'      // Mengikuti Tren Pasar
  | 'support_resistance'   // Reaksi Support/Resistance
  | 'breakout'             // Penembusan Level (Breakout)
  | 'reversal_oversold'    // Indikator Jenuh/Reversal
  | 'trds_ai_analysis'     // Sesuai Analisis TRDS AI
  | 'fomo_impulsive'       // Cepat/FOMO/Tanpa Sabar
  | 'unplanned';           // Coba-coba / Spontan

export type TradingPsychologyState =
  | 'calm_disciplined'     // Tenang & Disiplin
  | 'confident_measured'   // Percaya Diri Terukur
  | 'fomo_rushed'          // Cemas / Takut Ketinggalan
  | 'greedy_aggressive'    // Serakah / Ingin Cepat Kaya
  | 'hesitant_fearful'     // Ragu-ragu / Takut Rugi
  | 'revenge_emotional';   // Balas Dendam Pasar (Revenge)

export type PlanAdherence =
  | 'strict_plan'          // Patuh Penuh Sesuai Rencana
  | 'early_exit_fear'      // Keluar Lebih Awal Karena Cemas
  | 'greed_delayed_exit'   // Menahan Terlalu Lama Karena Serakah
  | 'stopped_out_valid'    // Kena Stop Loss Terencana (Good Loss)
  | 'no_plan';             // Tidak Memiliki Rencana

export interface TradeJournalEntry {
  id: string;
  tradeId: string;
  symbol: string;
  side: OrderSide;
  entryReason: EntryReasonCategory;
  entryReasonDetail?: string;
  psychologyState: TradingPsychologyState;
  planAdherence: PlanAdherence;
  disciplineScore: number; // 1 to 5
  userReflectionNotes: string;
  educationalFeedback: string;
  isGoodRiskTrade: boolean; // Evaluates discipline over mere profit/loss
  createdAt: number;
  updatedAt: number;
}



