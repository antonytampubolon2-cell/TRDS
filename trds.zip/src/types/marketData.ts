/**
 * TRDS Live Market Data Foundation - Types & Interfaces
 *
 * Provides a normalized internal model and provider abstraction for both
 * simulated and real market data sources.
 */

import { AssetCategory } from './index';

export type MarketDataStatus =
  | 'LIVE'
  | 'SIMULATED'
  | 'UPDATING'
  | 'UNAVAILABLE'
  | 'STALE';

export interface MarketQuote {
  id: string;
  symbol: string;           // Normalized display symbol (e.g. "BTC/USD")
  rawSymbol?: string;        // Raw provider ticker (e.g. "BTCUSDT")
  name: string;
  assetType: AssetCategory;
  price: number;
  change24h: number;        // Percentage, e.g. +4.25 or -2.10
  changePercent24h: number; // Decimal percentage equivalent
  high24h?: number;
  low24h?: number;
  volume?: string;
  sparkline?: number[];
  timestamp: number;        // Milliseconds epoch timestamp from source
  dataStatus: MarketDataStatus;
  source: string;           // e.g. 'simulation' | 'provider_id'
  isStale: boolean;
  errorMessage?: string;
}

export interface MarketDataProvider {
  readonly id: string;
  readonly name: string;
  readonly isLive: boolean;

  /**
   * Fetches a single quote for the given symbol or asset id.
   */
  getQuote(symbol: string): Promise<MarketQuote>;

  /**
   * Fetches multiple quotes in batch.
   */
  getQuotes(symbols: string[]): Promise<Record<string, MarketQuote>>;

  /**
   * Verifies if this provider is properly configured, online, and accessible.
   */
  isAvailable(): Promise<boolean>;
}

export interface MarketDataValidationResult {
  isValid: boolean;
  error?: string;
  missingFields?: string[];
}

export interface MarketDataServiceConfig {
  staleThresholdMs: number; // e.g. 5 minutes
  cacheTtlMs: number;        // e.g. 15 seconds
}
