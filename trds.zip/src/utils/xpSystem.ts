export interface LevelThreshold {
  level: number;
  title: string;
  minXp: number;
  maxXp: number; // for the highest level, Infinity
}

export const LEVEL_THRESHOLDS: LevelThreshold[] = [
  { level: 1, title: 'Novice Trader', minXp: 0, maxXp: 100 },
  { level: 2, title: 'Market Apprentice', minXp: 100, maxXp: 250 },
  { level: 3, title: 'Chart Reader', minXp: 250, maxXp: 500 },
  { level: 4, title: 'Tactical Strategist', minXp: 500, maxXp: 1000 },
  { level: 5, title: 'Risk Guardian', minXp: 1000, maxXp: 1750 },
  { level: 6, title: 'Technical Specialist', minXp: 1750, maxXp: 2750 },
  { level: 7, title: 'Market Analyst', minXp: 2750, maxXp: 4500 },
  { level: 8, title: 'TRDS Master', minXp: 4500, maxXp: 10000 }
];

export interface UserLevelProgress {
  level: number;
  levelTitle: string;
  totalXp: number;
  currentLevelMinXp: number;
  nextLevelTargetXp: number;
  xpInCurrentLevel: number;
  xpNeededForNextLevel: number;
  progressPercent: number;
  isMaxLevel: boolean;
}

export function calculateLevelProgress(totalXp: number): UserLevelProgress {
  const safeXp = Math.max(0, totalXp);

  // Find corresponding level
  let currentThreshold = LEVEL_THRESHOLDS[0];
  for (let i = 0; i < LEVEL_THRESHOLDS.length; i++) {
    if (safeXp >= LEVEL_THRESHOLDS[i].minXp && safeXp < LEVEL_THRESHOLDS[i].maxXp) {
      currentThreshold = LEVEL_THRESHOLDS[i];
      break;
    }
    if (i === LEVEL_THRESHOLDS.length - 1 && safeXp >= LEVEL_THRESHOLDS[i].minXp) {
      currentThreshold = LEVEL_THRESHOLDS[i];
    }
  }

  const isMaxLevel = currentThreshold.level === LEVEL_THRESHOLDS[LEVEL_THRESHOLDS.length - 1].level && safeXp >= currentThreshold.maxXp;
  const currentLevelMinXp = currentThreshold.minXp;
  const nextLevelTargetXp = currentThreshold.maxXp;
  const levelRange = nextLevelTargetXp - currentLevelMinXp;
  const xpInCurrentLevel = Math.max(0, safeXp - currentLevelMinXp);
  const xpNeededForNextLevel = Math.max(0, nextLevelTargetXp - safeXp);
  const progressPercent = isMaxLevel
    ? 100
    : Math.min(100, Math.max(0, Math.round((xpInCurrentLevel / levelRange) * 100)));

  return {
    level: currentThreshold.level,
    levelTitle: currentThreshold.title,
    totalXp: safeXp,
    currentLevelMinXp,
    nextLevelTargetXp,
    xpInCurrentLevel,
    xpNeededForNextLevel,
    progressPercent,
    isMaxLevel
  };
}

export const XP_REWARDS = {
  LESSON_COMPLETED: 20,
  QUIZ_COMPLETED: 30,
  QUIZ_PASSED_BONUS: 20,
  DAILY_CHALLENGE: 50,
  SIMULATED_TRADE: 25,
  LIMIT_ORDER_PLACED: 15
} as const;
