import { CandlestickBar, SimulatorTimeframe } from '../types';

/**
 * Generates realistic candlestick sequences for an asset and timeframe.
 * The final candle always closes exactly at the current price.
 */
export function generateCandlestickData(
  currentPrice: number,
  change24h: number,
  timeframe: SimulatorTimeframe,
  count: number = 22
): CandlestickBar[] {
  // Volatility multiplier based on timeframe
  const timeframeMultiplier: Record<SimulatorTimeframe, { intervalMinutes: number; volatility: number }> = {
    '1m': { intervalMinutes: 1, volatility: 0.0018 },
    '5m': { intervalMinutes: 5, volatility: 0.0035 },
    '15m': { intervalMinutes: 15, volatility: 0.006 },
    '1H': { intervalMinutes: 60, volatility: 0.012 },
    '4H': { intervalMinutes: 240, volatility: 0.024 },
    '1D': { intervalMinutes: 1440, volatility: 0.045 }
  };

  const config = timeframeMultiplier[timeframe] || timeframeMultiplier['1H'];
  const now = Date.now();

  // Determine overall trend bias
  const trendSign = change24h >= 0 ? 1 : -1;
  const trendStrength = Math.min(0.04, Math.abs(change24h) / 100);

  // Generate walk backwards from currentPrice
  const rawCloses: number[] = new Array(count);
  rawCloses[count - 1] = currentPrice;

  // Pseudo-random deterministic seed based on current price & timeframe
  let seed = Math.abs(Math.sin(currentPrice * 100 + config.intervalMinutes)) * 10000;
  const pseudoRandom = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };

  for (let i = count - 2; i >= 0; i--) {
    const stepVolatility = config.volatility * (0.6 + pseudoRandom() * 0.8);
    // Walk backward against the trend
    const drift = -trendSign * (trendStrength / count) * (0.5 + pseudoRandom());
    const noise = (pseudoRandom() - 0.48) * stepVolatility;
    const prevClose = rawCloses[i + 1] / (1 + drift + noise);
    rawCloses[i] = Math.max(0.0001, prevClose);
  }

  // Build candle bars
  const bars: CandlestickBar[] = [];
  const decimals = currentPrice < 1 ? 4 : currentPrice < 10 ? 3 : 2;

  for (let i = 0; i < count; i++) {
    const candleTime = new Date(now - (count - 1 - i) * config.intervalMinutes * 60 * 1000);
    const close = Number(rawCloses[i].toFixed(decimals));
    const open = i === 0
      ? Number((close * (1 + (pseudoRandom() - 0.5) * config.volatility * 0.5)).toFixed(decimals))
      : bars[i - 1].close;

    const isUp = close >= open;
    const wickVariation = config.volatility * (0.2 + pseudoRandom() * 0.6);
    const maxVal = Math.max(open, close);
    const minVal = Math.min(open, close);

    const high = Number((maxVal + maxVal * wickVariation * pseudoRandom()).toFixed(decimals));
    const low = Number(Math.max(0.0001, minVal - minVal * wickVariation * pseudoRandom()).toFixed(decimals));

    // Simulated volume with spikes on larger candle bodies
    const bodySize = Math.abs(close - open) / (open || 1);
    const baseVolume = 100000 + pseudoRandom() * 400000;
    const volume = Math.round(baseVolume * (1 + bodySize * 30));

    // Format time label
    let timeStr = '';
    if (timeframe === '1D') {
      timeStr = candleTime.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
    } else if (timeframe === '4H' || timeframe === '1H') {
      timeStr = candleTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    } else {
      timeStr = candleTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    }

    bars.push({
      time: timeStr,
      timestamp: candleTime.getTime(),
      open,
      high: Math.max(high, maxVal),
      low: Math.min(low, minVal),
      close,
      volume,
      isUp
    });
  }

  return bars;
}
