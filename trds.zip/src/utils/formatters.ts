/**
 * TRDS Centralized Formatters
 */

import { MarketDataStatus } from '../types/marketData';

/**
 * Normalizes an incoming raw provider symbol or instrument string to the canonical
 * internal display format (e.g. "BTC/USD", "XAU/USD").
 *
 * Handles:
 * - "BTC/USD/USD" -> "BTC/USD"
 * - "BINANCE:BTCUSDT" -> "BTC/USD"
 * - "BTCUSDT" -> "BTC/USD"
 * - "BTCUSD" -> "BTC/USD"
 * - "NVDA" -> "NVDA/USD"
 */
export function normalizeInstrumentSymbol(rawSymbol: string): string {
  if (!rawSymbol) return '';
  let cleaned = rawSymbol.trim().toUpperCase();

  // Strip exchange prefix if present (e.g. BINANCE:BTCUSDT -> BTCUSDT)
  if (cleaned.includes(':')) {
    cleaned = cleaned.split(':')[1];
  }

  // Remove trailing duplicate /USD or /USDT fragments
  cleaned = cleaned.replace(/(\/USD)+$/i, '/USD');
  cleaned = cleaned.replace(/(\/USDT)+$/i, '/USD');

  // Convert raw USDT suffix to /USD
  if (cleaned.endsWith('USDT')) {
    cleaned = cleaned.slice(0, -4) + '/USD';
  } else if (cleaned.endsWith('USD') && !cleaned.includes('/')) {
    cleaned = cleaned.slice(0, -3) + '/USD';
  }

  // Delegate to formatMarketPairSymbol
  return formatMarketPairSymbol(cleaned);
}

/**
 * Returns the official TRDS UI label for each MarketDataStatus.
 */
export function formatDataStatusLabel(status: MarketDataStatus): string {
  switch (status) {
    case 'LIVE':
      return 'LIVE MARKET DATA';
    case 'SIMULATED':
      return 'DATA SIMULASI';
    case 'UPDATING':
      return 'UPDATING...';
    case 'UNAVAILABLE':
      return 'DATA UNAVAILABLE';
    case 'STALE':
      return 'STALE DATA';
    default:
      return 'DATA SIMULASI';
  }
}

/**
 * Formats an instrument symbol with exactly one quote currency suffix (e.g. /USD).
 * Prevents duplicates like BTC/USD/USD while ensuring equity or bare symbols (e.g. NVDA)
 * consistently display with /USD.
 *
 * Rules:
 * - If symbol already ends with /USD (or has duplicate /USD/USD), normalize to a single /USD.
 * - If symbol has another pair delimiter (e.g. EUR/JPY, USD/JPY), preserve it.
 * - Otherwise append /USD.
 */
export function formatMarketPairSymbol(symbol: string): string {
  if (!symbol) return '';
  let trimmed = symbol.trim();

  // Strip multiple consecutive slashes (e.g. BTC//USD -> BTC/USD)
  trimmed = trimmed.replace(/\/+/g, '/');

  // Strip repetitive /USD suffixes (e.g. BTC/USD/USD, BTC/USD/USD/USD, BTC/usd/usd)
  trimmed = trimmed.replace(/(\/USD)+$/i, '/USD');

  if (trimmed.toUpperCase().endsWith('/USD')) {
    const base = trimmed.slice(0, -4);
    const cleanBase = base.replace(/(\/USD)+$/i, '');
    return `${cleanBase}/USD`;
  }

  // If it contains a slash with another pair quote currency (e.g. EUR/GBP, USD/JPY)
  if (trimmed.includes('/')) {
    return trimmed;
  }

  return `${trimmed}/USD`;
}
