import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  NavTab,
  ThemeMode,
  Asset,
  Order,
  Trade,
  TradeJournalEntry,
  OrderType,
  OrderSide,
  Lesson,
  Achievement,
  DailyChallenge,
  UserProfile,
  ChatMessage,
  LearningCategoryId,
  Quiz,
  QuizResult,
  AIContext,
  QuizQuestion
} from '../types';
import {
  MOCK_ASSETS,
  INITIAL_USER_PROFILE,
  MOCK_LESSONS,
  MOCK_ACHIEVEMENTS,
  MOCK_DAILY_CHALLENGES,
  INITIAL_CHAT_MESSAGES
} from '../data/mockData';
import { calculateLevelProgress, XP_REWARDS } from '../utils/xpSystem';
import { aiService } from '../services/aiService';
import { revenueCatService } from '../services/revenueCatService';
import { CustomerInfo, PurchaseError } from '../types/revenueCat';

export interface HoldingMeta {
  avgBuyPrice: number;
  totalCost: number;
}

export interface PositionCloseDetails {
  symbol: string;
  amount: number;
  unit: string;
  exitPrice: number;
  entryPrice: number;
  closeValue: number;
  fee: number;
  netProceeds: number;
  costBasis: number;
  realizedPnL: number;
  pnlPercent: number;
  timestamp: number;
}

export interface ClosePositionResult {
  success: boolean;
  message: string;
  closeDetails?: PositionCloseDetails;
  trade?: Trade;
  order?: Order;
}

interface AppContextType {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  previousTab: NavTab;
  navigateBack: () => void;
  selectedAssetId: string;
  setSelectedAssetId: (id: string) => void;
  theme: ThemeMode;
  toggleTheme: () => void;
  assets: Asset[];
  favoriteAssetIds: string[];
  toggleFavorite: (id: string) => void;
  userProfile: UserProfile;
  orders: Order[];
  trades: Trade[];
  holdings: Record<string, number>;
  holdingsMeta: Record<string, HoldingMeta>;
  lessons: Lesson[];
  achievements: Achievement[];
  dailyChallenges: DailyChallenge[];
  chatMessages: ChatMessage[];
  isAiTyping: boolean;
  selectedAsset: Asset;
  selectedDetailAsset: Asset | null;
  openAssetDetail: (asset: Asset) => void;
  closeAssetDetail: () => void;
  isPortfolioModalOpen: boolean;
  openPortfolioModal: () => void;
  closePortfolioModal: () => void;
  isNotificationsModalOpen: boolean;
  openNotificationsModal: () => void;
  closeNotificationsModal: () => void;
  isRefreshing: boolean;
  lastRefreshed: Date;
  refreshMarkets: () => void;
  totalPortfolioValue: number;
  totalSimulatedPnL: number;
  simulatedPnLPercent: number;
  realizedPnL: number;
  unrealizedPnL: number;
  placeOrder: (params: {
    assetId: string;
    type: OrderType;
    side: OrderSide;
    amount: number;
    price?: number;
  }) => { success: boolean; message: string; trade?: Trade; order?: Order };
  cancelOrder: (orderId: string) => void;
  closeVirtualPosition: (assetId: string) => ClosePositionResult;
  triggerLimitOrderExecution: (orderId: string) => { success: boolean; message: string };
  completeLessonQuiz: (lessonId: string, earnedXp: number) => void;
  // Phase 4 additions:
  completedLessonIds: string[];
  quizResults: Record<string, QuizResult>;
  markLessonCompleted: (lessonId: string) => { isFirstTime: boolean; xpAwarded: number };
  submitQuizResult: (
    quizId: string,
    lessonId: string,
    score: number,
    totalQuestions: number
  ) => { isFirstTime: boolean; earnedXp: number; passed: boolean };
  claimDailyChallenge: (challengeId: string) => { success: boolean; xpAwarded: number };
  viewedAssetIds: string[];
  recordAssetView: (assetId: string) => void;
  isAchievementsModalOpen: boolean;
  openAchievementsModal: () => void;
  closeAchievementsModal: () => void;
  isDailyChallengesModalOpen: boolean;
  openDailyChallengesModal: () => void;
  closeDailyChallengesModal: () => void;
  activeLessonForModal: Lesson | null;
  openLessonModal: (lesson: Lesson) => void;
  closeLessonModal: () => void;
  activeQuizForModal: { lesson: Lesson; quiz: Quiz } | null;
  openQuizModal: (lesson: Lesson, quiz: Quiz) => void;
  closeQuizModal: () => void;
  latestUnlockedAchievement: Achievement | null;
  dismissAchievementToast: () => void;
  filterCategory: LearningCategoryId | 'all';
  setFilterCategory: (category: LearningCategoryId | 'all') => void;
  openCategoryInLearn: (category: LearningCategoryId) => void;
  sendChatMessage: (text: string, contextOverride?: Partial<AIContext>) => void;
  retryLastChatMessage: () => void;
  clearChatMessages: () => void;
  clearActiveAiContext: () => void;
  askAiAboutLesson: (lesson: Lesson) => void;
  askAiAboutQuiz: (quizTitle: string, question: QuizQuestion, userSelectedIndex: number) => void;
  askAiAboutSimulator: (promptPreset?: string) => void;
  activeAiContext: AIContext | null;
  aiError: string | null;
  resetVirtualAccount: () => void;
  resetSimulation: () => void;
  navigateToTrade: (assetId: string) => void;

  // Phase 6 — RevenueCat & TRDS Premium Entitlement
  isPremium: boolean;
  customerInfo: CustomerInfo | null;
  activePackageId: string | null;
  isRevenueCatConfigured: boolean;
  isPremiumModalOpen: boolean;
  setIsPremiumModalOpen: (open: boolean) => void;
  premiumModalContext: string | undefined;
  openPremiumModal: (featureName?: string) => void;
  closePremiumModal: () => void;
  purchasePackage: (packageId: string) => Promise<{ success: boolean; customerInfo?: CustomerInfo; error?: PurchaseError }>;
  restorePurchases: () => Promise<{ success: boolean; restored: boolean; customerInfo?: CustomerInfo; error?: PurchaseError }>;
  toggleDevelopmentEntitlement: (isActive: boolean, packageId?: string) => void;

  // Opening Experience (Splash & Welcome Screen)
  showOpeningScreen: boolean;
  setShowOpeningScreen: (show: boolean) => void;

  // TRDS Market Intelligence Feature Expansion
  isMarketIntelligenceOpen: boolean;
  selectedIntelligenceAsset: Asset | null;
  openMarketIntelligence: (asset?: Asset) => void;
  closeMarketIntelligence: () => void;
  askAiAboutMarketIntelligence: (asset: Asset, intelligence: any) => void;

  // Trade Journal & Trading Psychology
  journals: Record<string, TradeJournalEntry>;
  saveTradeJournal: (tradeId: string, entry: Omit<TradeJournalEntry, 'id' | 'createdAt' | 'updatedAt'>) => void;
  deleteTradeJournal: (tradeId: string) => void;
  activeJournalTrade: Trade | null;
  openJournalModal: (trade: Trade) => void;
  closeJournalModal: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  FAVORITES: 'trds_favorites',
  VIRTUAL_BALANCE: 'trds_virtual_balance',
  HOLDINGS: 'trds_holdings',
  HOLDINGS_META: 'trds_holdings_meta',
  ORDERS: 'trds_orders',
  TRADES: 'trds_trades',
  JOURNALS: 'trds_trade_journals',
  REALIZED_PNL: 'trds_realized_pnl',
  USER_PROFILE: 'trds_user_profile',
  COMPLETED_LESSONS: 'trds_completed_lessons',
  QUIZ_RESULTS: 'trds_quiz_results',
  ACHIEVEMENTS: 'trds_achievements',
  DAILY_CHALLENGES: 'trds_daily_challenges',
  VIEWED_ASSETS: 'trds_viewed_assets'
};

const INITIAL_VIRTUAL_BALANCE = 10000.00;

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTabState] = useState<NavTab>('home');
  const [previousTab, setPreviousTab] = useState<NavTab>('home');
  const [selectedAssetId, setSelectedAssetId] = useState<string>('btc');
  const [selectedDetailAsset, setSelectedDetailAsset] = useState<Asset | null>(null);
  const [isPortfolioModalOpen, setIsPortfolioModalOpen] = useState<boolean>(false);
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState<boolean>(false);
  const [theme, setTheme] = useState<ThemeMode>('dark');
  const [assets, setAssets] = useState<Asset[]>(MOCK_ASSETS);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastRefreshed, setLastRefreshed] = useState<Date>(new Date());

  // Phase 6 — RevenueCat & TRDS Premium Entitlement State
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo | null>(() => revenueCatService.getCustomerInfo());
  const [isPremium, setIsPremium] = useState<boolean>(() => revenueCatService.isPremiumUser());
  const [activePackageId, setActivePackageId] = useState<string | null>(() => {
    const info = revenueCatService.getCustomerInfo();
    return info.activeSubscriptions[0] || null;
  });
  const [isPremiumModalOpen, setIsPremiumModalOpen] = useState<boolean>(false);
  const [premiumModalContext, setPremiumModalContext] = useState<string | undefined>(undefined);
  const isRevenueCatConfigured = revenueCatService.isConfigured();

  // Opening Experience state (default true so user sees Splash -> Welcome upon open)
  const [showOpeningScreen, setShowOpeningScreen] = useState<boolean>(true);

  // TRDS Market Intelligence Feature Expansion state
  const [isMarketIntelligenceOpen, setIsMarketIntelligenceOpen] = useState<boolean>(false);
  const [selectedIntelligenceAsset, setSelectedIntelligenceAsset] = useState<Asset | null>(null);

  const openPremiumModal = useCallback((featureName?: string) => {
    setPremiumModalContext(featureName);
    setIsPremiumModalOpen(true);
  }, []);

  const closePremiumModal = useCallback(() => {
    setIsPremiumModalOpen(false);
    setPremiumModalContext(undefined);
  }, []);

  const purchasePackage = useCallback(async (packageId: string) => {
    const result = await revenueCatService.purchasePackage(packageId);
    if (result.success && result.customerInfo) {
      setCustomerInfo(result.customerInfo);
      setIsPremium(revenueCatService.isPremiumUser());
      setActivePackageId(packageId);
    }
    return result;
  }, []);

  const restorePurchases = useCallback(async () => {
    const result = await revenueCatService.restorePurchases();
    if (result.customerInfo) {
      setCustomerInfo(result.customerInfo);
      setIsPremium(revenueCatService.isPremiumUser());
      setActivePackageId(result.customerInfo.activeSubscriptions[0] || null);
    }
    return result;
  }, []);

  const toggleDevelopmentEntitlement = useCallback((isActive: boolean, packageId: string = '$rc_annual') => {
    const updated = revenueCatService.setDevelopmentMockEntitlement(isActive, packageId);
    setCustomerInfo(updated);
    setIsPremium(isActive);
    setActivePackageId(isActive ? packageId : null);
  }, []);

  const setActiveTab = (tab: NavTab) => {
    setActiveTabState(current => {
      if (current !== tab) {
        setPreviousTab(current);
      }
      return tab;
    });
  };

  const navigateBack = () => {
    setActiveTabState(prev => (prev === 'simulator' ? (previousTab || 'markets') : 'home'));
  };

  // 1. Favorites Persistence
  const [favoriteAssetIds, setFavoriteAssetIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FAVORITES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return ['btc', 'eth', 'sol', 'bnb', 'xrp'];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favoriteAssetIds));
    } catch (e) {
      // Ignore
    }
  }, [favoriteAssetIds]);

  // 2. User Profile & Virtual Balance (Default: 10,000 USDT virtual)
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const savedBalance = localStorage.getItem(STORAGE_KEYS.VIRTUAL_BALANCE);
      const savedProfile = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
      let base = { ...INITIAL_USER_PROFILE, virtualBalance: INITIAL_VIRTUAL_BALANCE, initialBalance: INITIAL_VIRTUAL_BALANCE };
      if (savedProfile) {
        base = { ...base, ...JSON.parse(savedProfile) };
      }
      if (savedBalance !== null) {
        const num = parseFloat(savedBalance);
        if (!isNaN(num)) base.virtualBalance = num;
      }
      return base;
    } catch (e) {
      return { ...INITIAL_USER_PROFILE, virtualBalance: INITIAL_VIRTUAL_BALANCE, initialBalance: INITIAL_VIRTUAL_BALANCE };
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.VIRTUAL_BALANCE, userProfile.virtualBalance.toString());
      localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(userProfile));
    } catch (e) {
      // Ignore
    }
  }, [userProfile]);

  // 3. Holdings & Cost Basis Meta Persistence
  const [holdings, setHoldings] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HOLDINGS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return {};
  });

  const [holdingsMeta, setHoldingsMeta] = useState<Record<string, HoldingMeta>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HOLDINGS_META);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return {};
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HOLDINGS, JSON.stringify(holdings));
    } catch (e) {
      // Ignore
    }
  }, [holdings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HOLDINGS_META, JSON.stringify(holdingsMeta));
    } catch (e) {
      // Ignore
    }
  }, [holdingsMeta]);

  // 4. Orders Persistence
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    } catch (e) {
      // Ignore
    }
  }, [orders]);

  // 5. Trades Persistence
  const [trades, setTrades] = useState<Trade[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TRADES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TRADES, JSON.stringify(trades));
    } catch (e) {
      // Ignore
    }
  }, [trades]);

  // 5b. Trade Journals Persistence
  const [journals, setJournals] = useState<Record<string, TradeJournalEntry>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.JOURNALS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return {};
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
    } catch (e) {
      // Ignore
    }
  }, [journals]);

  // 6. Realized PnL Persistence
  const [realizedPnL, setRealizedPnL] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REALIZED_PNL);
      if (saved !== null) {
        const num = parseFloat(saved);
        if (!isNaN(num)) return num;
      }
    } catch (e) {
      // Ignore
    }
    return 0;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.REALIZED_PNL, realizedPnL.toString());
    } catch (e) {
      // Ignore
    }
  }, [realizedPnL]);

  // 7. Completed Lessons Persistence (Anti-duplication)
  const [completedLessonIds, setCompletedLessonIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COMPLETED_LESSONS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.COMPLETED_LESSONS, JSON.stringify(completedLessonIds));
    } catch (e) {
      // Ignore
    }
  }, [completedLessonIds]);

  // 8. Quiz Results Persistence (Anti-duplication)
  const [quizResults, setQuizResults] = useState<Record<string, QuizResult>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.QUIZ_RESULTS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return {};
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.QUIZ_RESULTS, JSON.stringify(quizResults));
    } catch (e) {
      // Ignore
    }
  }, [quizResults]);

  // 9. Achievements Persistence
  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return MOCK_ACHIEVEMENTS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
    } catch (e) {
      // Ignore
    }
  }, [achievements]);

  // 10. Daily Challenges Persistence
  const [dailyChallenges, setDailyChallenges] = useState<DailyChallenge[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DAILY_CHALLENGES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return MOCK_DAILY_CHALLENGES;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.DAILY_CHALLENGES, JSON.stringify(dailyChallenges));
    } catch (e) {
      // Ignore
    }
  }, [dailyChallenges]);

  // 11. Viewed Assets Persistence (for Market Explorer achievement)
  const [viewedAssetIds, setViewedAssetIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.VIEWED_ASSETS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      // Ignore
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.VIEWED_ASSETS, JSON.stringify(viewedAssetIds));
    } catch (e) {
      // Ignore
    }
  }, [viewedAssetIds]);

  // Synchronize lessons list with completedLessonIds
  const [lessons, setLessons] = useState<Lesson[]>(() => {
    return MOCK_LESSONS.map(l => ({
      ...l,
      isCompleted: completedLessonIds.includes(l.id)
    }));
  });

  useEffect(() => {
    setLessons(MOCK_LESSONS.map(l => ({
      ...l,
      isCompleted: completedLessonIds.includes(l.id)
    })));
  }, [completedLessonIds]);

  // Modals & Navigation state
  const [isAchievementsModalOpen, setIsAchievementsModalOpen] = useState<boolean>(false);
  const [isDailyChallengesModalOpen, setIsDailyChallengesModalOpen] = useState<boolean>(false);
  const [activeLessonForModal, setActiveLessonForModal] = useState<Lesson | null>(null);
  const [activeQuizForModal, setActiveQuizForModal] = useState<{ lesson: Lesson; quiz: Quiz } | null>(null);
  const [latestUnlockedAchievement, setLatestUnlockedAchievement] = useState<Achievement | null>(null);
  const [filterCategory, setFilterCategory] = useState<LearningCategoryId | 'all'>('all');

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [isAiTyping, setIsAiTyping] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [activeAiContext, setActiveAiContext] = useState<AIContext | null>(null);
  const [lastUserPrompt, setLastUserPrompt] = useState<string>('');

  // Sync theme with HTML class
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const toggleFavorite = (assetId: string) => {
    setFavoriteAssetIds(prev =>
      prev.includes(assetId) ? prev.filter(id => id !== assetId) : [...prev, assetId]
    );
  };

  // ==========================================
  // XP & ACHIEVEMENTS SYSTEM
  // ==========================================

  const awardXp = useCallback((amount: number) => {
    if (amount <= 0) return;
    setUserProfile(prev => {
      const currentTotal = (prev.totalXp ?? (prev.level > 1 ? prev.currentXp + (prev.level - 1) * 150 : prev.currentXp)) + amount;
      const progress = calculateLevelProgress(currentTotal);

      return {
        ...prev,
        totalXp: currentTotal,
        currentXp: progress.xpInCurrentLevel,
        level: progress.level,
        nextLevelXp: progress.nextLevelTargetXp - progress.currentLevelMinXp,
        levelTitle: progress.levelTitle
      };
    });
  }, []);

  const triggerAchievementUnlock = useCallback((achId: string) => {
    setAchievements(prev => {
      const target = prev.find(a => a.id === achId);
      if (!target || target.isUnlocked) return prev;

      const updated = prev.map(a => {
        if (a.id === achId) {
          return {
            ...a,
            isUnlocked: true,
            progress: a.maxProgress,
            unlockedDate: 'Baru saja'
          };
        }
        return a;
      });

      if (target.xpReward > 0) {
        awardXp(target.xpReward);
      }

      setLatestUnlockedAchievement({
        ...target,
        isUnlocked: true,
        progress: target.maxProgress
      });

      return updated;
    });
  }, [awardXp]);

  const recordAssetView = useCallback((assetId: string) => {
    setViewedAssetIds(prev => {
      if (prev.includes(assetId)) return prev;
      const updated = [...prev, assetId];

      if (updated.length >= 5) {
        triggerAchievementUnlock('market-explorer');
      } else {
        setAchievements(curr =>
          curr.map(a => (a.id === 'market-explorer' ? { ...a, progress: Math.min(5, updated.length) } : a))
        );
      }

      setDailyChallenges(curr =>
        curr.map(dc => {
          if (dc.type === 'view_market') {
            const count = Math.min(dc.targetCount, updated.length);
            return {
              ...dc,
              currentCount: count,
              isCompleted: count >= dc.targetCount
            };
          }
          return dc;
        })
      );

      return updated;
    });
  }, [triggerAchievementUnlock]);

  const openAssetDetail = (asset: Asset) => {
    setSelectedDetailAsset(asset);
    recordAssetView(asset.id);
  };

  const closeAssetDetail = () => {
    setSelectedDetailAsset(null);
  };

  const openPortfolioModal = () => setIsPortfolioModalOpen(true);
  const closePortfolioModal = () => setIsPortfolioModalOpen(false);

  const openNotificationsModal = () => setIsNotificationsModalOpen(true);
  const closeNotificationsModal = () => setIsNotificationsModalOpen(false);

  const navigateToTrade = (assetId: string) => {
    setPreviousTab(activeTab);
    setSelectedAssetId(assetId);
    setSelectedDetailAsset(null);
    setActiveTabState('simulator');
  };

  const selectedAsset = assets.find(a => a.id === selectedAssetId) || assets[0];

  // ==========================================
  // MATHEMATICAL PNL & PORTFOLIO CALCULATIONS
  // ==========================================

  // Asset holdings nominal value
  const holdingsValue = Object.entries(holdings).reduce((total, [assetId, qty]) => {
    const numQty = typeof qty === 'number' ? qty : Number(qty);
    const asset = assets.find(a => a.id === assetId);
    if (!asset || numQty <= 0) return total;
    return total + numQty * asset.price;
  }, 0);

  // Unrealized PnL: sum of (currentPrice - avgBuyPrice) * amount for all active holdings
  const unrealizedPnL = Object.entries(holdings).reduce((total, [assetId, qty]) => {
    const numQty = typeof qty === 'number' ? qty : Number(qty);
    if (numQty <= 0) return total;
    const asset = assets.find(a => a.id === assetId);
    if (!asset) return total;
    const meta = holdingsMeta[assetId];
    const avgPrice = meta?.avgBuyPrice || asset.price;
    const pnl = (asset.price - avgPrice) * numQty;
    return total + pnl;
  }, 0);

  // Total portfolio value = virtual USDT cash + total asset value
  const totalPortfolioValue = userProfile.virtualBalance + holdingsValue;
  // Total PnL = Realized PnL + Unrealized PnL
  const totalSimulatedPnL = realizedPnL + unrealizedPnL;
  const initialTotal = userProfile.initialBalance || INITIAL_VIRTUAL_BALANCE;
  const simulatedPnLPercent = initialTotal > 0 ? (totalSimulatedPnL / initialTotal) * 100 : 0;

  // ==========================================
  // LIMIT ORDER EXECUTION ENGINE
  // ==========================================
  const executeLimitOrderInternal = useCallback((
    order: Order,
    executionPrice: number,
    currentHoldings: Record<string, number>,
    currentMeta: Record<string, HoldingMeta>
  ) => {
    const asset = assets.find(a => a.id === order.assetId);
    if (!asset) return null;

    const totalValue = order.amount * executionPrice;
    const simulatedFee = totalValue * 0.001; // 0.10% virtual fee

    if (order.side === 'buy') {
      const totalDeduction = totalValue + simulatedFee;
      setUserProfile(prev => ({
        ...prev,
        virtualBalance: Math.max(0, prev.virtualBalance - totalDeduction),
        tradesCount: prev.tradesCount + 1
      }));

      const prevQty = currentHoldings[order.assetId] || 0;
      const prevCost = (currentMeta[order.assetId]?.avgBuyPrice || 0) * prevQty;
      const newQty = prevQty + order.amount;
      const newTotalCost = prevCost + totalValue;
      const newAvgBuyPrice = newQty > 0 ? newTotalCost / newQty : executionPrice;

      setHoldings(prev => ({ ...prev, [order.assetId]: newQty }));
      setHoldingsMeta(prev => ({
        ...prev,
        [order.assetId]: { avgBuyPrice: newAvgBuyPrice, totalCost: newTotalCost }
      }));

      const newTrade: Trade = {
        id: `trd-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        orderId: order.id,
        assetId: order.assetId,
        symbol: order.symbol,
        side: 'buy',
        amount: order.amount,
        price: executionPrice,
        totalValue,
        fee: simulatedFee,
        timestamp: Date.now(),
        simulatedPnL: 0
      };

      setTrades(prev => [newTrade, ...prev]);

      setOrders(prev =>
        prev.map(o => (o.id === order.id ? { ...o, status: 'filled' as const, filledAt: Date.now() } : o))
      );

      awardXp(30);
      return newTrade;
    } else {
      // Limit Sell Execution
      const prevQty = currentHoldings[order.assetId] || 0;
      const sellQty = Math.min(prevQty, order.amount);
      const costBasis = (currentMeta[order.assetId]?.avgBuyPrice || executionPrice) * sellQty;
      const netProceeds = totalValue - simulatedFee;
      const tradeProfit = totalValue - costBasis - simulatedFee;

      setUserProfile(prev => ({
        ...prev,
        virtualBalance: prev.virtualBalance + netProceeds,
        tradesCount: prev.tradesCount + 1,
        profitableTradesCount: tradeProfit > 0 ? prev.profitableTradesCount + 1 : prev.profitableTradesCount
      }));

      setRealizedPnL(prev => prev + tradeProfit);

      const newQty = Math.max(0, prevQty - sellQty);
      const currentAvg = currentMeta[order.assetId]?.avgBuyPrice || executionPrice;
      const newTotalCost = newQty * currentAvg;

      setHoldings(prev => ({ ...prev, [order.assetId]: newQty }));
      setHoldingsMeta(prev => ({
        ...prev,
        [order.assetId]: { avgBuyPrice: newQty > 0 ? currentAvg : 0, totalCost: newTotalCost }
      }));

      const newTrade: Trade = {
        id: `trd-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        orderId: order.id,
        assetId: order.assetId,
        symbol: order.symbol,
        side: 'sell',
        amount: sellQty,
        price: executionPrice,
        totalValue,
        fee: simulatedFee,
        costBasis,
        timestamp: Date.now(),
        simulatedPnL: Number(tradeProfit.toFixed(2))
      };

      setTrades(prev => [newTrade, ...prev]);

      setOrders(prev =>
        prev.map(o => (o.id === order.id ? { ...o, status: 'filled' as const, filledAt: Date.now() } : o))
      );

      awardXp(30);
      return newTrade;
    }
  }, [assets, awardXp]);

  // Check and execute open limit orders matching prices
  const checkAndExecuteOpenOrders = useCallback((currentAssets: Asset[]) => {
    setOrders(prevOrders => {
      const openOrders = prevOrders.filter(o => o.status === 'open');
      if (openOrders.length === 0) return prevOrders;

      openOrders.forEach(order => {
        const asset = currentAssets.find(a => a.id === order.assetId);
        if (!asset) return;

        let shouldFill = false;
        if (order.side === 'buy' && asset.price <= order.price) {
          shouldFill = true;
        } else if (order.side === 'sell' && asset.price >= order.price) {
          shouldFill = true;
        }

        if (shouldFill) {
          executeLimitOrderInternal(order, order.price, holdings, holdingsMeta);
        }
      });

      return prevOrders;
    });
  }, [holdings, holdingsMeta, executeLimitOrderInternal]);

  // Manual limit order trigger (useful for instant testing in simulator)
  const triggerLimitOrderExecution = (orderId: string) => {
    const order = orders.find(o => o.id === orderId && o.status === 'open');
    if (!order) return { success: false, message: 'Pesanan tidak ditemukan atau sudah selesai' };

    const trade = executeLimitOrderInternal(order, order.price, holdings, holdingsMeta);
    if (trade) {
      return { success: true, message: `Limit Order ${order.symbol} berhasil dieksekusi @ $${order.price.toFixed(2)}!` };
    }
    return { success: false, message: 'Gagal mengeksekusi limit order' };
  };

  const refreshMarkets = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setAssets(prevAssets => {
        const updated = prevAssets.map(asset => {
          const deltaFactor = 1 + (Math.random() * 0.008 - 0.004);
          const newPrice = Math.max(0.0001, Number((asset.price * deltaFactor).toFixed(asset.price < 1 ? 4 : 2)));
          const newSparkline = [...asset.sparkline.slice(1), newPrice];
          const newHigh = Math.max(asset.high24h, newPrice);
          const newLow = Math.min(asset.low24h, newPrice);
          return {
            ...asset,
            price: newPrice,
            sparkline: newSparkline,
            high24h: newHigh,
            low24h: newLow
          };
        });

        // Trigger limit order check on new prices
        checkAndExecuteOpenOrders(updated);
        return updated;
      });

      setLastRefreshed(new Date());
      setIsRefreshing(false);
    }, 500);
  };

  // ==========================================
  // PLACE ORDER (MARKET & LIMIT)
  // ==========================================
  const placeOrder = ({
    assetId,
    type,
    side,
    amount,
    price
  }: {
    assetId: string;
    type: OrderType;
    side: OrderSide;
    amount: number;
    price?: number;
  }) => {
    const asset = assets.find(a => a.id === assetId);
    if (!asset) return { success: false, message: 'Aset tidak ditemukan' };
    if (!amount || isNaN(amount) || amount <= 0) {
      return { success: false, message: 'Masukkan jumlah pesanan yang valid (lebih dari 0)' };
    }

    const executionPrice = type === 'market' ? asset.price : (price || asset.price);
    if (type === 'limit' && (!executionPrice || executionPrice <= 0)) {
      return { success: false, message: 'Masukkan harga target limit yang valid' };
    }

    const totalValue = amount * executionPrice;
    const simulatedFee = totalValue * 0.001; // 0.10% virtual fee

    if (side === 'buy') {
      const totalDeduction = totalValue + simulatedFee;
      if (userProfile.virtualBalance < totalDeduction) {
        return {
          success: false,
          message: `Saldo virtual tidak mencukupi. Butuh $${totalDeduction.toLocaleString('en-US', { minimumFractionDigits: 2 })}, saldo saat ini: $${userProfile.virtualBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })} USDT`
        };
      }

      if (type === 'market') {
        // Immediate Market Buy Execution
        setUserProfile(prev => ({
          ...prev,
          virtualBalance: Math.max(0, prev.virtualBalance - totalDeduction),
          tradesCount: prev.tradesCount + 1
        }));

        const prevQty = holdings[assetId] || 0;
        const prevCost = (holdingsMeta[assetId]?.avgBuyPrice || 0) * prevQty;
        const newQty = prevQty + amount;
        const newTotalCost = prevCost + totalValue;
        const newAvgBuyPrice = newQty > 0 ? newTotalCost / newQty : executionPrice;

        setHoldings(prev => ({
          ...prev,
          [assetId]: newQty
        }));

        setHoldingsMeta(prev => ({
          ...prev,
          [assetId]: {
            avgBuyPrice: newAvgBuyPrice,
            totalCost: newTotalCost
          }
        }));

        const tradeId = `trd-${Date.now()}`;
        const newTrade: Trade = {
          id: tradeId,
          orderId: `ord-${Date.now()}`,
          assetId,
          symbol: asset.symbol,
          side: 'buy',
          amount,
          price: executionPrice,
          totalValue,
          fee: simulatedFee,
          timestamp: Date.now(),
          simulatedPnL: 0
        };

        const newOrder: Order = {
          id: `ord-${Date.now()}`,
          assetId,
          symbol: asset.symbol,
          type: 'market',
          side: 'buy',
          amount,
          price: executionPrice,
          status: 'filled',
          timestamp: Date.now(),
          filledAt: Date.now(),
          fee: simulatedFee,
          totalValue
        };

        setTrades(prev => [newTrade, ...prev]);
        setOrders(prev => [newOrder, ...prev]);

        // Complete daily trade challenge if active & trigger achievement
        setDailyChallenges(prev =>
          prev.map(dc => (dc.type === 'trade' ? { ...dc, currentCount: 1, isCompleted: true } : dc))
        );
        triggerAchievementUnlock('simulator-beginner');

        awardXp(25);

        return {
          success: true,
          message: `Virtual Market Buy Berhasil! Membeli ${amount} ${asset.unit} @ $${executionPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
          trade: newTrade,
          order: newOrder
        };
      } else {
        // Limit Buy Order
        const newOrder: Order = {
          id: `ord-${Date.now()}`,
          assetId,
          symbol: asset.symbol,
          type: 'limit',
          side: 'buy',
          amount,
          price: executionPrice,
          status: 'open',
          timestamp: Date.now(),
          fee: simulatedFee,
          totalValue
        };

        setOrders(prev => [newOrder, ...prev]);
        awardXp(15);

        // Check if market price already satisfies limit buy
        if (asset.price <= executionPrice) {
          executeLimitOrderInternal(newOrder, executionPrice, holdings, holdingsMeta);
          return {
            success: true,
            message: `Limit Buy Order Terpasang & Langsung Terisi @ $${executionPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}!`,
            order: newOrder
          };
        }

        return {
          success: true,
          message: `Limit Buy Order Terpasang! Menunggu harga $${executionPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
          order: newOrder
        };
      }
    } else {
      // SELL LOGIC
      const currentHolding = holdings[assetId] || 0;
      if (currentHolding < amount) {
        return {
          success: false,
          message: `Kepemilikan aset tidak mencukupi. Kamu memiliki ${currentHolding.toFixed(4)} ${asset.unit}, ingin menjual ${amount} ${asset.unit}`
        };
      }

      if (type === 'market') {
        // Immediate Market Sell Execution
        const costBasis = (holdingsMeta[assetId]?.avgBuyPrice || executionPrice) * amount;
        const netProceeds = totalValue - simulatedFee;
        const tradeRealizedGain = totalValue - costBasis - simulatedFee;

        setUserProfile(prev => ({
          ...prev,
          virtualBalance: prev.virtualBalance + netProceeds,
          tradesCount: prev.tradesCount + 1,
          profitableTradesCount: tradeRealizedGain > 0 ? prev.profitableTradesCount + 1 : prev.profitableTradesCount
        }));

        setRealizedPnL(prev => prev + tradeRealizedGain);

        const newQty = Math.max(0, currentHolding - amount);
        const currentAvg = holdingsMeta[assetId]?.avgBuyPrice || executionPrice;
        const newTotalCost = newQty * currentAvg;

        setHoldings(prev => ({
          ...prev,
          [assetId]: newQty
        }));

        setHoldingsMeta(prev => ({
          ...prev,
          [assetId]: {
            avgBuyPrice: newQty > 0 ? currentAvg : 0,
            totalCost: newTotalCost
          }
        }));

        const newTrade: Trade = {
          id: `trd-${Date.now()}`,
          orderId: `ord-${Date.now()}`,
          assetId,
          symbol: asset.symbol,
          side: 'sell',
          amount,
          price: executionPrice,
          totalValue,
          fee: simulatedFee,
          costBasis,
          timestamp: Date.now(),
          simulatedPnL: Number(tradeRealizedGain.toFixed(2))
        };

        const newOrder: Order = {
          id: `ord-${Date.now()}`,
          assetId,
          symbol: asset.symbol,
          type: 'market',
          side: 'sell',
          amount,
          price: executionPrice,
          status: 'filled',
          timestamp: Date.now(),
          filledAt: Date.now(),
          fee: simulatedFee,
          totalValue
        };

        setTrades(prev => [newTrade, ...prev]);
        setOrders(prev => [newOrder, ...prev]);

        // Complete daily trade challenge if active & trigger achievement
        setDailyChallenges(prev =>
          prev.map(dc => (dc.type === 'trade' ? { ...dc, currentCount: 1, isCompleted: true } : dc))
        );
        triggerAchievementUnlock('simulator-beginner');

        awardXp(25);

        return {
          success: true,
          message: `Virtual Market Sell Berhasil! Menjual ${amount} ${asset.unit} @ $${executionPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })} (PnL: ${tradeRealizedGain >= 0 ? '+' : ''}$${tradeRealizedGain.toFixed(2)})`,
          trade: newTrade,
          order: newOrder
        };
      } else {
        // Limit Sell Order
        const newOrder: Order = {
          id: `ord-${Date.now()}`,
          assetId,
          symbol: asset.symbol,
          type: 'limit',
          side: 'sell',
          amount,
          price: executionPrice,
          status: 'open',
          timestamp: Date.now(),
          fee: simulatedFee,
          totalValue
        };

        setOrders(prev => [newOrder, ...prev]);
        awardXp(15);

        // Check if market price already satisfies limit sell
        if (asset.price >= executionPrice) {
          executeLimitOrderInternal(newOrder, executionPrice, holdings, holdingsMeta);
          return {
            success: true,
            message: `Limit Sell Order Terpasang & Langsung Terisi @ $${executionPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}!`,
            order: newOrder
          };
        }

        return {
          success: true,
          message: `Limit Sell Order Terpasang! Menunggu harga $${executionPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
          order: newOrder
        };
      }
    }
  };

  const cancelOrder = (orderId: string) => {
    setOrders(prev =>
      prev.map(ord => (ord.id === orderId ? { ...ord, status: 'cancelled' as const, cancelledAt: Date.now() } : ord))
    );
  };

  // ==========================================
  // ONE-TAP CLOSE POSITION (SIMULATOR FEATURE)
  // ==========================================
  const closeVirtualPosition = (assetId: string): ClosePositionResult => {
    const asset = assets.find(a => a.id === assetId);
    if (!asset) {
      return { success: false, message: 'Aset tidak ditemukan dalam simulator.' };
    }

    const currentHolding = holdings[assetId] || 0;
    if (typeof currentHolding !== 'number' || currentHolding <= 0) {
      return {
        success: false,
        message: `Tidak ada posisi terbuka untuk ${asset.symbol}. Posisi mungkin sudah ditutup.`
      };
    }

    const executionPrice = asset.price;
    if (!executionPrice || isNaN(executionPrice) || executionPrice <= 0) {
      return {
        success: false,
        message: 'Harga pasar virtual saat ini tidak valid atau tidak tersedia.'
      };
    }

    const amount = currentHolding;
    const totalValue = amount * executionPrice;
    const simulatedFee = totalValue * 0.001; // 0.10% virtual fee
    const entryPrice = holdingsMeta[assetId]?.avgBuyPrice || executionPrice;
    const costBasis = entryPrice * amount;
    const netProceeds = totalValue - simulatedFee;
    const tradeRealizedGain = totalValue - costBasis - simulatedFee;
    const pnlPercent = costBasis > 0 ? (tradeRealizedGain / costBasis) * 100 : 0;

    // 1. Update virtual cash balance & trade counters
    setUserProfile(prev => ({
      ...prev,
      virtualBalance: prev.virtualBalance + netProceeds,
      tradesCount: prev.tradesCount + 1,
      profitableTradesCount: tradeRealizedGain > 0 ? prev.profitableTradesCount + 1 : prev.profitableTradesCount
    }));

    // 2. Update realized PnL
    setRealizedPnL(prev => prev + tradeRealizedGain);

    // 3. Remove holding completely
    setHoldings(prev => {
      const updated = { ...prev };
      delete updated[assetId];
      return updated;
    });

    // 4. Reset holding meta
    setHoldingsMeta(prev => {
      const updated = { ...prev };
      delete updated[assetId];
      return updated;
    });

    // 5. Record executed trade in history
    const tradeId = `trd-${Date.now()}`;
    const newTrade: Trade = {
      id: tradeId,
      orderId: `ord-${Date.now()}`,
      assetId,
      symbol: asset.symbol,
      side: 'sell',
      amount,
      price: executionPrice,
      totalValue,
      fee: simulatedFee,
      costBasis,
      timestamp: Date.now(),
      simulatedPnL: Number(tradeRealizedGain.toFixed(2))
    };

    // 6. Record order in history
    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      assetId,
      symbol: asset.symbol,
      type: 'market',
      side: 'sell',
      amount,
      price: executionPrice,
      status: 'filled',
      timestamp: Date.now(),
      filledAt: Date.now(),
      fee: simulatedFee,
      totalValue
    };

    setTrades(prev => [newTrade, ...prev]);
    setOrders(prev => [newOrder, ...prev]);

    // 7. Complete daily trade challenge if active & award XP
    setDailyChallenges(prev =>
      prev.map(dc => (dc.type === 'trade' ? { ...dc, currentCount: 1, isCompleted: true } : dc))
    );
    triggerAchievementUnlock('simulator-beginner');
    awardXp(25);

    const closeDetails: PositionCloseDetails = {
      symbol: asset.symbol,
      amount,
      unit: asset.unit,
      exitPrice: executionPrice,
      entryPrice,
      closeValue: totalValue,
      fee: simulatedFee,
      netProceeds,
      costBasis,
      realizedPnL: Number(tradeRealizedGain.toFixed(2)),
      pnlPercent: Number(pnlPercent.toFixed(2)),
      timestamp: Date.now()
    };

    return {
      success: true,
      message: `Posisi virtual ${asset.symbol} berhasil ditutup pada $${executionPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}.`,
      closeDetails,
      trade: newTrade,
      order: newOrder
    };
  };

  // ==========================================
  // PHASE 4: LEARN, QUIZ, XP & ACHIEVEMENTS
  // ==========================================

  const markLessonCompleted = useCallback((lessonId: string) => {
    if (completedLessonIds.includes(lessonId)) {
      return { isFirstTime: false, xpAwarded: 0 };
    }

    const newCompleted = [...completedLessonIds, lessonId];
    setCompletedLessonIds(newCompleted);

    setUserProfile(prev => ({
      ...prev,
      lessonsCompletedCount: prev.lessonsCompletedCount + 1
    }));

    const earnedXp = XP_REWARDS.LESSON_COMPLETED;
    awardXp(earnedXp);

    // Achievements check:
    triggerAchievementUnlock('first-lesson');

    if (newCompleted.length >= 5) {
      triggerAchievementUnlock('quick-learner');
    } else {
      setAchievements(prev =>
        prev.map(a => (a.id === 'quick-learner' ? { ...a, progress: newCompleted.length } : a))
      );
    }

    if (newCompleted.length >= 10) {
      triggerAchievementUnlock('knowledge-builder');
    } else {
      setAchievements(prev =>
        prev.map(a => (a.id === 'knowledge-builder' ? { ...a, progress: Math.min(10, newCompleted.length) } : a))
      );
    }

    // Check risk guardian
    const currentLesson = lessons.find(l => l.id === lessonId);
    if (currentLesson?.categoryId === 'risk') {
      const allRiskLessons = lessons.filter(l => l.categoryId === 'risk');
      const completedRiskCount = allRiskLessons.filter(l => newCompleted.includes(l.id)).length;
      if (completedRiskCount >= allRiskLessons.length && allRiskLessons.length > 0) {
        triggerAchievementUnlock('risk-guardian');
      } else {
        setAchievements(prev =>
          prev.map(a => (a.id === 'risk-guardian' ? { ...a, progress: completedRiskCount } : a))
        );
      }
    }

    // Daily challenge update
    setDailyChallenges(prev =>
      prev.map(dc => (dc.type === 'lesson' ? { ...dc, currentCount: 1, isCompleted: true } : dc))
    );

    return { isFirstTime: true, xpAwarded: earnedXp };
  }, [completedLessonIds, lessons, awardXp, triggerAchievementUnlock]);

  const submitQuizResult = useCallback((
    quizId: string,
    lessonId: string,
    score: number,
    totalQuestions: number
  ) => {
    const passed = totalQuestions > 0 ? (score / totalQuestions) >= 0.7 : true;
    const isFirstTime = !quizResults[quizId];

    const result: QuizResult = {
      quizId,
      lessonId,
      score,
      totalQuestions,
      passed,
      completedAt: Date.now()
    };

    setQuizResults(prev => ({
      ...prev,
      [quizId]: result
    }));

    // Auto complete parent lesson
    if (!completedLessonIds.includes(lessonId)) {
      markLessonCompleted(lessonId);
    }

    if (!isFirstTime) {
      return { isFirstTime: false, earnedXp: 0, passed };
    }

    // Award first-time XP
    const baseReward = XP_REWARDS.QUIZ_COMPLETED;
    const bonusReward = passed ? XP_REWARDS.QUIZ_PASSED_BONUS : 0;
    const totalEarnedXp = baseReward + bonusReward;

    awardXp(totalEarnedXp);

    if (passed) {
      setUserProfile(prev => ({
        ...prev,
        quizzesPassedCount: (prev.quizzesPassedCount || 0) + 1
      }));
    }

    triggerAchievementUnlock('first-quiz');

    if (passed) {
      const existingPassed = Object.values(quizResults).filter((q: QuizResult) => q.passed).length;
      const newPassedCount = existingPassed + 1;
      if (newPassedCount >= 5) {
        triggerAchievementUnlock('quiz-master');
      } else {
        setAchievements(prev =>
          prev.map(a => (a.id === 'quiz-master' ? { ...a, progress: Math.min(5, newPassedCount) } : a))
        );
      }
    }

    setDailyChallenges(prev =>
      prev.map(dc => (dc.type === 'quiz' ? { ...dc, currentCount: 1, isCompleted: true } : dc))
    );

    return { isFirstTime: true, earnedXp: totalEarnedXp, passed };
  }, [quizResults, completedLessonIds, awardXp, markLessonCompleted, triggerAchievementUnlock]);

  const claimDailyChallenge = useCallback((challengeId: string) => {
    const challenge = dailyChallenges.find(dc => dc.id === challengeId);
    if (!challenge || !challenge.isCompleted) {
      return { success: false, xpAwarded: 0 };
    }

    awardXp(challenge.xpReward);

    const completedChallengesCount = dailyChallenges.filter(dc => dc.isCompleted).length;
    if (completedChallengesCount >= 3) {
      triggerAchievementUnlock('dedicated-learner');
    } else {
      setAchievements(prev =>
        prev.map(a => (a.id === 'dedicated-learner' ? { ...a, progress: Math.min(3, completedChallengesCount) } : a))
      );
    }

    return { success: true, xpAwarded: challenge.xpReward };
  }, [dailyChallenges, awardXp, triggerAchievementUnlock]);

  const completeLessonQuiz = (lessonId: string, earnedXp: number) => {
    markLessonCompleted(lessonId);
    if (earnedXp > 0) {
      awardXp(earnedXp);
    }
  };

  const openAchievementsModal = () => setIsAchievementsModalOpen(true);
  const closeAchievementsModal = () => setIsAchievementsModalOpen(false);

  const openDailyChallengesModal = () => setIsDailyChallengesModalOpen(true);
  const closeDailyChallengesModal = () => setIsDailyChallengesModalOpen(false);

  const openLessonModal = (lesson: Lesson) => setActiveLessonForModal(lesson);
  const closeLessonModal = () => setActiveLessonForModal(null);

  const openQuizModal = (lesson: Lesson, quiz: Quiz) => {
    setActiveQuizForModal({ lesson, quiz });
  };
  const closeQuizModal = () => setActiveQuizForModal(null);

  const dismissAchievementToast = () => setLatestUnlockedAchievement(null);

  const openCategoryInLearn = (category: LearningCategoryId) => {
    setFilterCategory(category);
    setActiveTabState('learn');
  };

  const buildCurrentAiContext = (override?: Partial<AIContext>): AIContext => {
    return {
      portfolio: {
        totalValue: totalPortfolioValue,
        cashBalance: userProfile.virtualBalance,
        assetValue: totalPortfolioValue - userProfile.virtualBalance,
        unrealizedPnL: unrealizedPnL,
        realizedPnL: realizedPnL,
        totalPnL: totalSimulatedPnL,
        pnlPercent: simulatedPnLPercent
      },
      selectedAsset: {
        id: selectedAsset.id,
        symbol: selectedAsset.symbol,
        name: selectedAsset.name,
        price: selectedAsset.price,
        change24h: selectedAsset.change24h,
        category: selectedAsset.category
      },
      simulator: {
        openOrdersCount: orders.filter(o => o.status === 'open').length,
        holdingsCount: Object.keys(holdings).length,
        recentTradesCount: trades.length
      },
      learning: {
        completedLessonsCount: completedLessonIds.length,
        totalLessons: lessons.length,
        progressPercent: Math.round((completedLessonIds.length / lessons.length) * 100)
      },
      user: {
        level: userProfile.level,
        levelTitle: userProfile.levelTitle,
        currentXp: userProfile.currentXp,
        totalXp: userProfile.totalXp ?? (userProfile.level > 1 ? 250 : userProfile.currentXp),
        streakDays: userProfile.streakDays
      },
      activeTarget: override?.activeTarget || activeAiContext?.activeTarget,
      ...override
    };
  };

  const sendChatMessage = async (text: string, contextOverride?: Partial<AIContext>) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    setAiError(null);
    setLastUserPrompt(trimmed);

    const target = contextOverride?.activeTarget || activeAiContext?.activeTarget;
    const contextTag = target?.title
      ? `${target.type === 'lesson' ? 'Modul' : target.type === 'quiz' ? 'Kuis' : 'Simulator'}: ${target.title}`
      : undefined;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: trimmed,
      timestamp: Date.now(),
      contextTag
    };

    const updatedHistory = [...chatMessages, userMsg];
    setChatMessages(updatedHistory);
    setIsAiTyping(true);

    try {
      const fullContext = buildCurrentAiContext(contextOverride);
      const response = await aiService.sendMessage(trimmed, updatedHistory, fullContext);

      const assistantMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: response.message,
        timestamp: Date.now(),
        promptSuggestions: response.suggestions
      };

      setChatMessages(prev => [...prev, assistantMsg]);
      awardXp(10);
    } catch (err) {
      const fallbackErr = 'Terjadi kendala saat menyusun respon edukatif. Silakan coba lagi.';
      setAiError(fallbackErr);
      const assistantErrMsg: ChatMessage = {
        id: `ai-err-${Date.now()}`,
        sender: 'assistant',
        text: fallbackErr,
        timestamp: Date.now(),
        isError: true,
        promptSuggestions: [
          'Coba lagi pertanyaan tadi',
          'Apa itu Candlestick?',
          'Jelaskan konsep PnL'
        ]
      };
      setChatMessages(prev => [...prev, assistantErrMsg]);
    } finally {
      setIsAiTyping(false);
    }
  };

  const retryLastChatMessage = () => {
    if (lastUserPrompt) {
      setChatMessages(prev => prev.filter(m => !m.isError));
      setAiError(null);
      sendChatMessage(lastUserPrompt);
    }
  };

  const clearChatMessages = () => {
    setChatMessages(INITIAL_CHAT_MESSAGES);
    setAiError(null);
    setActiveAiContext(null);
  };

  const clearActiveAiContext = () => {
    setActiveAiContext(null);
  };

  const askAiAboutLesson = (lesson: Lesson) => {
    setActiveLessonForModal(null);
    const targetContext: AIContext = {
      activeTarget: {
        type: 'lesson',
        title: lesson.title,
        detail: lesson.subtitle,
        data: { id: lesson.id, category: lesson.categoryId }
      }
    };
    setActiveAiContext(targetContext);
    setActiveTabState('ai');
    sendChatMessage(
      `Jelaskan materi modul "${lesson.title}" dengan bahasa yang lebih sederhana dan berikan contoh penerapannya di pasar virtual.`,
      targetContext
    );
  };

  const askAiAboutQuiz = (quizTitle: string, question: QuizQuestion, userSelectedIndex: number) => {
    setActiveQuizForModal(null);
    const isCorrect = userSelectedIndex === question.correctIndex;
    const userOptionText = question.options[userSelectedIndex] || 'Tidak dijawab';
    const correctOptionText = question.options[question.correctIndex];

    const targetContext: AIContext = {
      activeTarget: {
        type: 'quiz',
        title: quizTitle,
        detail: question.question,
        data: {
          question: question.question,
          userAnswer: userOptionText,
          correctAnswer: correctOptionText,
          isCorrect,
          explanation: question.explanation
        }
      }
    };
    setActiveAiContext(targetContext);
    setActiveTabState('ai');
    sendChatMessage(
      `Tolong jelaskan pembahasan kuis: "${question.question}". Jawaban yang benar adalah "${correctOptionText}". Mengapa demikian dan apa konsep pentingnya?`,
      targetContext
    );
  };

  const askAiAboutSimulator = (promptPreset?: string) => {
    const targetContext: AIContext = {
      activeTarget: {
        type: 'simulator',
        title: selectedAsset.symbol,
        detail: `${selectedAsset.name} - $${selectedAsset.price}`,
        data: {
          asset: selectedAsset,
          portfolioPnL: totalSimulatedPnL,
          pnlPercent: simulatedPnLPercent
        }
      }
    };
    setActiveAiContext(targetContext);
    setActiveTabState('ai');
    const prompt = promptPreset || `Bagaimana cara membaca pergerakan harga ${selectedAsset.symbol} dan risiko posisinya di Simulator TRDS?`;
    sendChatMessage(prompt, targetContext);
  };

  const openMarketIntelligence = useCallback((asset?: Asset) => {
    if (asset) {
      setSelectedIntelligenceAsset(asset);
    } else if (selectedDetailAsset) {
      setSelectedIntelligenceAsset(selectedDetailAsset);
    } else {
      const fallback = assets.find(a => a.id === selectedAssetId) || assets[0];
      setSelectedIntelligenceAsset(fallback);
    }
    setIsMarketIntelligenceOpen(true);
  }, [assets, selectedAssetId, selectedDetailAsset]);

  const closeMarketIntelligence = useCallback(() => {
    setIsMarketIntelligenceOpen(false);
  }, []);

  const askAiAboutMarketIntelligence = useCallback((asset: Asset, intelligence: any) => {
    setIsMarketIntelligenceOpen(false);
    if (selectedDetailAsset) {
      setSelectedDetailAsset(null);
    }

    const symbol = intelligence.symbol || asset.symbol;
    const price = intelligence.price ?? asset.price;
    const change24h = intelligence.change24h ?? asset.change24h;
    const changePercent24h = intelligence.changePercent24h ?? (change24h / 100);
    const timestamp = intelligence.timestamp ?? Date.now();
    const dataStatus = intelligence.dataStatus || 'SIMULATED';
    const source = intelligence.dataSource || intelligence.quote?.source || 'simulation';
    const isStale = Boolean(intelligence.isStale);
    const marketCondition = intelligence.advancedCondition || intelligence.trend || 'NEUTRAL';
    const momentum = intelligence.advancedMomentum || intelligence.momentum || 'Neutral';
    const volatility = intelligence.advancedVolatility || intelligence.volatility || 'MEDIUM';
    const trendContext = intelligence.trendContext || 'Range / Sideways';
    const marketStrength = intelligence.marketStrength || 'Balanced';
    const riskLevel = intelligence.riskLevel || 'MODERATE';
    const analysisConfidence = intelligence.analysisConfidence || 'MEDIUM DATA CONFIDENCE';
    const volumeContext = intelligence.volumeContext || 'Unavailable';
    const volumeStr = intelligence.volume || 'N/A';
    const conditionReasons = intelligence.conditionReasons || [];
    const riskContext = intelligence.riskContext;

    const statusLabel = dataStatus === 'LIVE'
      ? 'LIVE MARKET DATA'
      : dataStatus === 'STALE'
      ? 'STALE DATA'
      : dataStatus === 'UNAVAILABLE'
      ? 'DATA UNAVAILABLE'
      : 'DATA SIMULASI';

    const targetContext: AIContext = {
      activeTarget: {
        type: 'market_intelligence',
        title: `${symbol} Advanced Market Intelligence`,
        detail: `[${statusLabel}] Kondisi ${marketCondition} • Momentum ${momentum} • Volatilitas ${volatility} • Risk ${riskLevel}`,
        data: {
          asset,
          intelligence,
          symbol,
          price,
          change24h,
          changePercent24h,
          timestamp,
          dataStatus,
          source,
          isStale,
          marketCondition,
          momentum,
          volatility,
          trendContext,
          marketStrength,
          riskLevel,
          analysisConfidence,
          volumeContext,
          volumeStr,
          conditionReasons,
          riskContext
        }
      }
    };
    setActiveAiContext(targetContext);
    setActiveTabState('ai');
    sendChatMessage(
      `MARKET DATA STATUS: ${statusLabel}\nJelaskan analisis Advanced Market Intelligence untuk ${symbol}: Harga $${Number(price).toLocaleString('en-US')}, Perubahan 24h ${change24h >= 0 ? '+' : ''}${change24h}%, Kondisi Pasar ${marketCondition}, Momentum ${momentum}, Volatilitas ${volatility}, Konteks Tren ${trendContext}, Market Strength "${marketStrength}", Risk Context ${riskLevel}, Data Confidence ${analysisConfidence}. Mengapa kondisi ini muncul, apa implikasi status datanya, skenario apa yang mungkin terjadi, dan bagaimana manajemen risikonya?`,
      targetContext
    );
  }, [selectedDetailAsset, sendChatMessage]);

  // ==========================================
  // TRADE JOURNAL & TRADING PSYCHOLOGY (Phase 7)
  // ==========================================
  const [activeJournalTrade, setActiveJournalTrade] = useState<Trade | null>(null);

  const openJournalModal = useCallback((trade: Trade) => {
    setActiveJournalTrade(trade);
  }, []);

  const closeJournalModal = useCallback(() => {
    setActiveJournalTrade(null);
  }, []);

  const saveTradeJournal = useCallback(
    (tradeId: string, entryData: Omit<TradeJournalEntry, 'id' | 'createdAt' | 'updatedAt'>) => {
      const now = Date.now();
      let createdEntry: TradeJournalEntry;

      setJournals(prev => {
        const existing = prev[tradeId];
        createdEntry = {
          ...entryData,
          id: existing?.id || `jnl-${now}-${Math.random().toString(36).substr(2, 4)}`,
          tradeId,
          createdAt: existing?.createdAt || now,
          updatedAt: now
        };
        return {
          ...prev,
          [tradeId]: createdEntry
        };
      });

      // Update trades in-memory so the journal entry is immediately linked
      setTrades(prevTrades =>
        prevTrades.map(t =>
          t.id === tradeId
            ? {
                ...t,
                journalEntry: {
                  ...entryData,
                  id: `jnl-${now}`,
                  tradeId,
                  createdAt: now,
                  updatedAt: now
                }
              }
            : t
        )
      );

      // Reward XP for trading discipline reflection
      awardXp(20);
    },
    [awardXp]
  );

  const deleteTradeJournal = useCallback((tradeId: string) => {
    setJournals(prev => {
      const updated = { ...prev };
      delete updated[tradeId];
      return updated;
    });

    setTrades(prevTrades =>
      prevTrades.map(t => (t.id === tradeId ? { ...t, journalEntry: undefined } : t))
    );
  }, []);

  // ==========================================
  // RESET SIMULATION (Section 13)
  // ==========================================
  const resetSimulation = () => {
    setUserProfile(prev => ({
      ...prev,
      virtualBalance: INITIAL_VIRTUAL_BALANCE,
      initialBalance: INITIAL_VIRTUAL_BALANCE,
      tradesCount: 0,
      profitableTradesCount: 0
    }));
    setHoldings({});
    setHoldingsMeta({});
    setOrders([]);
    setTrades([]);
    setJournals({});
    setRealizedPnL(0);

    try {
      localStorage.setItem(STORAGE_KEYS.VIRTUAL_BALANCE, INITIAL_VIRTUAL_BALANCE.toString());
      localStorage.setItem(STORAGE_KEYS.HOLDINGS, JSON.stringify({}));
      localStorage.setItem(STORAGE_KEYS.HOLDINGS_META, JSON.stringify({}));
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.TRADES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify({}));
      localStorage.setItem(STORAGE_KEYS.REALIZED_PNL, '0');
    } catch (e) {
      // Ignore
    }
  };

  const resetVirtualAccount = resetSimulation;

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        previousTab,
        navigateBack,
        selectedAssetId,
        setSelectedAssetId,
        selectedDetailAsset,
        openAssetDetail,
        closeAssetDetail,
        isPortfolioModalOpen,
        openPortfolioModal,
        closePortfolioModal,
        isNotificationsModalOpen,
        openNotificationsModal,
        closeNotificationsModal,
        isRefreshing,
        lastRefreshed,
        refreshMarkets,
        theme,
        toggleTheme,
        assets,
        favoriteAssetIds,
        toggleFavorite,
        userProfile,
        orders,
        trades,
        holdings,
        holdingsMeta,
        lessons,
        achievements,
        dailyChallenges,
        chatMessages,
        isAiTyping,
        selectedAsset,
        totalPortfolioValue,
        totalSimulatedPnL,
        simulatedPnLPercent,
        realizedPnL,
        unrealizedPnL,
        placeOrder,
        cancelOrder,
        closeVirtualPosition,
        triggerLimitOrderExecution,
        completeLessonQuiz,
        completedLessonIds,
        quizResults,
        markLessonCompleted,
        submitQuizResult,
        claimDailyChallenge,
        viewedAssetIds,
        recordAssetView,
        isAchievementsModalOpen,
        openAchievementsModal,
        closeAchievementsModal,
        isDailyChallengesModalOpen,
        openDailyChallengesModal,
        closeDailyChallengesModal,
        activeLessonForModal,
        openLessonModal,
        closeLessonModal,
        activeQuizForModal,
        openQuizModal,
        closeQuizModal,
        latestUnlockedAchievement,
        dismissAchievementToast,
        filterCategory,
        setFilterCategory,
        openCategoryInLearn,
        sendChatMessage,
        retryLastChatMessage,
        clearChatMessages,
        clearActiveAiContext,
        askAiAboutLesson,
        askAiAboutQuiz,
        askAiAboutSimulator,
        activeAiContext,
        aiError,
        resetVirtualAccount,
        resetSimulation,
        navigateToTrade,
        isPremium,
        customerInfo,
        activePackageId,
        isRevenueCatConfigured,
        isPremiumModalOpen,
        setIsPremiumModalOpen,
        premiumModalContext,
        openPremiumModal,
        closePremiumModal,
        purchasePackage,
        restorePurchases,
        toggleDevelopmentEntitlement,
        showOpeningScreen,
        setShowOpeningScreen,
        isMarketIntelligenceOpen,
        selectedIntelligenceAsset,
        openMarketIntelligence,
        closeMarketIntelligence,
        askAiAboutMarketIntelligence,
        journals,
        saveTradeJournal,
        deleteTradeJournal,
        activeJournalTrade,
        openJournalModal,
        closeJournalModal
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
