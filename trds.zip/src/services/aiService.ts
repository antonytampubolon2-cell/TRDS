import { AIMessage, AIResponse, AIContext, QuickQuestion } from '../types';

export interface IAIService {
  sendMessage(
    userMessage: string,
    history: AIMessage[],
    context?: AIContext
  ): Promise<AIResponse>;
}

export const QUICK_QUESTIONS: QuickQuestion[] = [
  {
    id: 'qq-pnl',
    label: 'Explain PnL',
    prompt: 'Jelaskan konsep PnL (Profit & Loss) dan perbedaan Unrealized PnL vs Realized PnL dalam simulasi.',
    category: 'simulator'
  },
  {
    id: 'qq-candlestick',
    label: 'What is a candlestick?',
    prompt: 'Apa itu Candlestick dan bagaimana cara membaca harga Open, High, Low, dan Close pada grafik?',
    category: 'analysis'
  },
  {
    id: 'qq-snr',
    label: 'Explain support & resistance',
    prompt: 'Jelaskan apa itu Support dan Resistance, serta bagaimana trader menggunakannya untuk menentukan area beli/jual.',
    category: 'analysis'
  },
  {
    id: 'qq-orders',
    label: 'Market vs Limit Order',
    prompt: 'Apa perbedaan antara Market Order dan Limit Order di simulator TRDS, serta kapan sebaiknya digunakan?',
    category: 'simulator'
  },
  {
    id: 'qq-simulator',
    label: 'How does the simulator work?',
    prompt: 'Bagaimana cara kerja Simulator Trading TRDS dan bagaimana saya bisa melatih strategi tanpa risiko modal riil?',
    category: 'simulator'
  },
  {
    id: 'qq-risk',
    label: 'Explain risk management',
    prompt: 'Mengapa manajemen risiko sangat penting dalam trading, dan apa itu aturan risiko modal 1% serta Risk-to-Reward Ratio?',
    category: 'risk'
  }
];

/**
 * Development & Educational AI Service
 * Provides rich, context-aware financial market education, strict safety guardrails,
 * and simulator integration without exposing private API keys or requiring external dependencies.
 */
export class DevelopmentAIService implements IAIService {
  // Safety keywords that indicate attempt to execute real transactions or access real funds
  private readonly SAFETY_KEYWORDS = [
    'beli sekarang untuk saya',
    'eksekusi order',
    'buy now for me',
    'execute trade',
    'deposit uang',
    'setor dana',
    'tarik uang',
    'withdraw',
    'rekening bank',
    'transfer bca',
    'transfer mandiri',
    'rekomendasi beli koin apa',
    'sinyal pasti profit',
    'leverage 100x',
    'hubungkan binance',
    'hubungkan indodax'
  ];

  async sendMessage(
    userMessage: string,
    history: AIMessage[],
    context?: AIContext
  ): Promise<AIResponse> {
    // Artificial latency for authentic typing experience
    await new Promise(resolve => setTimeout(resolve, 600 + Math.random() * 400));

    const trimmed = userMessage.trim();
    if (!trimmed) {
      return {
        message: 'Mohon masukkan pertanyaan atau topik edukasi pasar yang ingin kamu diskusikan.',
        suggestions: ['Apa itu Candlestick?', 'Jelaskan konsep PnL', 'Bagaimana cara kerja Limit Order?']
      };
    }

    const lower = trimmed.toLowerCase();

    // 1. Check Safety Guardrails (Section 6)
    if (this.isSafetyViolation(lower)) {
      return this.handleSafetyViolation();
    }

    // 2. Active Context Specific Queries (Lesson, Quiz, Simulator)
    if (context?.activeTarget) {
      const targetedResponse = this.handleActiveTarget(trimmed, context.activeTarget, context);
      if (targetedResponse) return targetedResponse;
    }

    // 3. Contextual Virtual PnL Queries ("Why is my PnL negative?", "Berapa saldo saya?", etc.)
    if (
      lower.includes('kenapa pnl') ||
      lower.includes('mengapa pnl') ||
      lower.includes('pnl saya') ||
      lower.includes('pnl negatif') ||
      lower.includes('pnl minus') ||
      lower.includes('why is my pnl') ||
      lower.includes('why is my virtual pnl')
    ) {
      return this.handleContextualPnL(context);
    }

    // 4. Simulator mechanics & Order queries
    if (
      lower.includes('simulator') ||
      lower.includes('cara kerja simulator') ||
      lower.includes('how does the simulator work')
    ) {
      return this.handleSimulatorWork(context);
    }

    if (
      lower.includes('market vs limit') ||
      lower.includes('market order') ||
      lower.includes('limit order') ||
      lower.includes('jenis order') ||
      lower.includes('tipe order')
    ) {
      return this.handleOrderTypes();
    }

    // 5. Candlestick & Technical Analysis
    if (
      lower.includes('candlestick') ||
      lower.includes('candle') ||
      lower.includes('lilin') ||
      lower.includes('what is a candlestick')
    ) {
      return this.handleCandlestick();
    }

    if (
      lower.includes('support') ||
      lower.includes('resistance') ||
      lower.includes('snr') ||
      lower.includes('support & resistance')
    ) {
      return this.handleSupportResistance();
    }

    if (lower.includes('rsi') || lower.includes('relative strength index')) {
      return this.handleRsi();
    }

    if (lower.includes('moving average') || lower.includes('ma cross') || lower.includes('ema')) {
      return this.handleMovingAverage();
    }

    // 6. Risk Management & Psychology
    if (
      lower.includes('risk management') ||
      lower.includes('manajemen risiko') ||
      lower.includes('stop loss') ||
      lower.includes('rrr') ||
      lower.includes('risk to reward')
    ) {
      return this.handleRiskManagement();
    }

    if (
      lower.includes('psikologi') ||
      lower.includes('fomo') ||
      lower.includes('revenge trading') ||
      lower.includes('disiplin')
    ) {
      return this.handlePsychology();
    }

    // 7. General PnL Definition
    if (lower.includes('pnl') || lower.includes('profit') || lower.includes('loss') || lower.includes('rugi')) {
      return this.handleGeneralPnL(context);
    }

    // 8. Selected Asset Context Inquiry
    if (context?.selectedAsset && (lower.includes('aset ini') || lower.includes(context.selectedAsset.symbol.toLowerCase()))) {
      return this.handleSelectedAssetInquiry(context.selectedAsset, context);
    }

    // 9. Greeting / General Introduction
    if (lower.includes('halo') || lower.includes('hai') || lower.includes('hello') || lower.includes('bantuan')) {
      return this.handleGreeting(context);
    }

    // 10. Fallback Educational Response
    return this.handleFallback(trimmed, context);
  }

  private isSafetyViolation(lower: string): boolean {
    return this.SAFETY_KEYWORDS.some(kw => lower.includes(kw));
  }

  private handleSafetyViolation(): AIResponse {
    return {
      message: `⚠️ **Batasan Keamanan & Ruang Lingkup TRDS AI**

TRDS AI adalah asisten edukasi pasar finansial yang **100% beroperasi di lingkungan simulasi virtual**. 

Saya **tidak dapat** dan **tidak diizinkan** untuk:
• Mengeksekusi order transaksi atau membuka posisi otomatis untuk Anda
• Menghubungkan akun ke bursa / broker / exchange finansial riil
• Mengelola, menyetor (deposit), atau mencairkan (withdraw) dana nyata
• Memberikan sinyal rekomendasi investasi keuangan riil

💡 **Eksplorasi di TRDS:**
Semua eksekusi order dilakukan secara mandiri oleh Anda di tab **Simulator** menggunakan saldo virtual edukasi $10,000 USDT. Ini melatih disiplin dan manajemen risiko Anda tanpa bahaya kerugian materiil sepeserpun!`,
      suggestions: [
        'Bagaimana cara pasang Limit Order di Simulator?',
        'Jelaskan konsep Aturan Risiko 1%',
        'Apa perbedaan Unrealized PnL vs Realized PnL?'
      ],
      source: 'educational_engine'
    };
  }

  private handleActiveTarget(userPrompt: string, activeTarget: NonNullable<AIContext['activeTarget']>, context: AIContext): AIResponse | null {
    if (activeTarget.type === 'lesson') {
      return {
        message: `📚 **Penjelasan Edukatif: Modul "${activeTarget.title}"**

Berikut adalah rangkuman inti dan penerapan praktisnya dalam simulasi pasar:

1. **Konsep Inti:**
Modul ini menekankan pemahaman struktural pasar, bagaimana dinamika pembeli (buyers) dan penjual (sellers) membentuk pergerakan harga, serta pentingnya memiliki rencana trading yang teruji.

2. **Penerapan di Simulator TRDS:**
Ketika mengamati grafik di simulator, jangan terburu-buru mengambil keputusan. Gunakan konsep dari modul ini untuk menandai level penting sebelum memasang order.

3. **Tips untuk Pemula:**
• Catat alasan entrimu sebelum menekan tombol beli.
• Selalu tentukan batas risiko (Stop Loss) sebelum masuk pasar.
• Uji konsep ini di beberapa aset (seperti BTC/USD atau NVDA) untuk melihat perbedaannya.`,
        suggestions: [
          'Bagaimana cara menguji modul ini di Simulator?',
          'Apa kesalahan pemula paling sering pada topik ini?',
          'Mulai kuis untuk modul ini'
        ],
        source: 'educational_engine'
      };
    }

    if (activeTarget.type === 'quiz') {
      const qData = activeTarget.data;
      return {
        message: `🧠 **Pembahasan Kuis: "${activeTarget.title}"**

**Pertanyaan:**
*"${qData?.question || activeTarget.detail}"*

${qData?.correctAnswer ? `✅ **Jawaban Benar:** ${qData.correctAnswer}\n\n` : ''}
**Mengapa ini adalah jawaban yang tepat?**
${qData?.explanation || 'Dalam prinsip trading terstruktur, pemahaman probabilitas dan kontrol risiko selalu lebih krusial daripada sekadar menebak arah harga.'}

💡 **Kunci Pemahaman:**
Dalam simulasi trading, keberhasilan jangka panjang tidak ditentukan oleh satu transaksi untung besar, melainkan konsistensi mengikuti aturan manajemen risiko dan pemahaman struktur pasar.`,
        suggestions: [
          'Jelaskan konsep ini lebih mendalam',
          'Berikan contoh kasus nyata di grafik',
          'Bagaimana cara menghindari kesalahan ini?'
        ],
        source: 'educational_engine'
      };
    }

    if (activeTarget.type === 'simulator') {
      const asset = context.selectedAsset;
      return {
        message: `📊 **Panduan Simulator: Analisis & Risiko (${asset ? asset.symbol : 'Pasar Demo'})**

Saat menganalisis instrumen di simulator TRDS:
• **Harga Saat Ini:** ${asset ? `$${asset.price.toLocaleString('en-US')}` : '$0'}
• **Perubahan 24 Jam:** ${asset ? `${asset.change24h >= 0 ? '+' : ''}${asset.change24h}%` : '0%'}

**Rekomendasi Latihan di Simulator:**
1. **Analisis Tren:** Perhatikan grafik candlestick (1H atau 1D). Apakah harga sedang membentuk *higher highs* (uptrend) atau *lower lows* (downtrend)?
2. **Pilih Tipe Order:** Jika ingin masuk pada harga saat ini, gunakan **Market Order**. Jika ingin menunggu harga diskon di area support, gunakan **Limit Order**.
3. **Kendalikan Ukuran Posisi:** Batasi alokasi modal maksimal 2–5% dari total saldo virtual Anda per transaksi.`,
        suggestions: [
          'Apa perbedaan Market Order vs Limit Order?',
          'Bagaimana menentukan area Support pada grafik ini?',
          'Jelaskan dampak pergerakan harga terhadap PnL'
        ],
        source: 'educational_engine'
      };
    }

    if (activeTarget.type === 'market_intelligence') {
      const data = activeTarget.data || {};
      const asset = data.asset || context?.selectedAsset;
      const intel = data.intelligence || {};
      const symbol = data.symbol || asset?.symbol || 'Aset Terpilih';
      const price = data.price ?? asset?.price ?? 0;
      const change24h = data.change24h ?? asset?.change24h ?? 0;
      const changePercent24h = data.changePercent24h !== undefined ? (data.changePercent24h * 100).toFixed(2) : `${change24h}%`;
      const timestamp = data.timestamp || intel.timestamp || Date.now();
      const dataStatus = data.dataStatus || intel.dataStatus || 'SIMULATED';
      const source = data.source || intel.dataSource || 'simulation';
      const isStale = Boolean(data.isStale || intel.isStale);
      const condition = data.marketCondition || intel.advancedCondition || intel.trend || 'NEUTRAL';
      const momentum = data.momentum || intel.advancedMomentum || intel.momentum || 'Neutral';
      const volatility = data.volatility || intel.advancedVolatility || intel.volatility || 'MEDIUM';
      const trendContext = data.trendContext || intel.trendContext || 'Range / Sideways';
      const marketStrength = data.marketStrength || intel.marketStrength || 'Balanced';
      const riskLevel = data.riskLevel || intel.riskLevel || 'MODERATE';
      const analysisConfidence = data.analysisConfidence || intel.analysisConfidence || 'MEDIUM DATA CONFIDENCE';
      const volumeStr = data.volumeStr || intel.volume || 'Volume data unavailable';
      const score = intel.score !== undefined ? `${intel.score}/100` : 'Analisis Edukasi';
      const rsiVal = intel.rsi?.value || '50';
      const rsiStatus = intel.rsi?.status || 'Moderat';
      const support = intel.support ? `$${Number(intel.support).toLocaleString('en-US')}` : 'Level Support';
      const resistance = intel.resistance ? `$${Number(intel.resistance).toLocaleString('en-US')}` : 'Level Resistance';
      const formattedTime = new Date(timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const reasons: string[] = data.conditionReasons && data.conditionReasons.length > 0
        ? data.conditionReasons
        : (intel.conditionReasons || [
            `Momentum 24 jam tercatat ${change24h >= 0 ? '+' : ''}${change24h}%`,
            `Struktur harga berada pada ${trendContext.toLowerCase()}`,
            `Volatilitas berada di tingkat ${volatility.toLowerCase()}`
          ]);

      let dataStatusHeader = 'DATA SIMULASI';
      let dataStatusNotice = '';
      if (dataStatus === 'LIVE') {
        dataStatusHeader = 'LIVE MARKET DATA';
        dataStatusNotice = '• **Status Umpan Data (LIVE MARKET DATA):** Analisis ini dihitung berdasarkan feed pasar tervalidasi. Ingat bahwa pergerakan masa lalu tidak menjamin tren masa depan.';
      } else if (dataStatus === 'STALE' || isStale) {
        dataStatusHeader = 'STALE DATA';
        dataStatusNotice = '• **Status Umpan Data (STALE DATA):** Umpan data mengalami keterlambatan pembaruan dari penyedia feed. Analisis ini menggunakan data tersimpan terakhir.';
      } else if (dataStatus === 'UNAVAILABLE') {
        dataStatusHeader = 'DATA UNAVAILABLE';
        dataStatusNotice = '• **Status Umpan Data (DATA UNAVAILABLE):** Umpan data pasar sementara tidak dapat diakses. Hindari mengambil asumsi analisis sebelum koneksi feed pulih.';
      } else {
        dataStatusHeader = 'DATA SIMULASI';
        dataStatusNotice = '• **Status Umpan Data (DATA SIMULASI):** Menggunakan data pasar simulasi edukatif TRDS. Angka ini disusun khusus untuk pelatihan analisis virtual tanpa risiko modal riil.';
      }

      return {
        message: `🧠 **TRDS Advanced Market Intelligence: ${symbol}**

━━━━━━━━━━━━━━━━━━━━━━━━━━━
**MARKET DATA STATUS:**
**${dataStatusHeader}**
*Sumber Feed: ${source} | Timestamp: ${formattedTime} | Freshness: ${isStale ? 'Stale (Keterlambatan data)' : 'Fresh (Tersinkronisasi)'}*
━━━━━━━━━━━━━━━━━━━━━━━━━━━

${dataStatusNotice}

1. **TRDS Market View (Multi-Factor Overview):**
• **Market Condition:** ${condition}
• **24h Momentum:** ${momentum} (${change24h >= 0 ? '+' : ''}${change24h}%)
• **Volatilitas:** ${volatility}
• **Trend Context:** ${trendContext}
• **Market Strength:** ${marketStrength} (Skor Edukatif: ${score})
• **Risk Context:** ${riskLevel}
• **Analysis Confidence:** ${analysisConfidence}
*(Confidence merefleksikan kelengkapan & konsistensi data pasar yang tersedia, bukan jaminan arah masa depan).*

2. **Mengapa Kondisi "${condition}" Muncul?**
${reasons.map(r => `• ${r}`).join('\n')}

3. **Zona Minat & Konteks Likuiditas:**
• **Support:** ${support} — *Area di mana aktivitas pasar sebelumnya menunjukkan minat beli potensial.*
• **Resistance:** ${resistance} — *Area di mana aktivitas pasar sebelumnya menunjukkan potensi tekanan jual.*
• **Konteks Volume:** ${volumeStr} — *Mengukur partisipasi transaksi tanpa rekayasa data.*
• **RSI (14):** ${rsiVal} (${rsiStatus})

4. **Skenario Edukasi Pasar (Bukan Prediksi Pasti):**
• **Skenario Penguatan (Bullish):** Didukung jika momentum beli bertahan di atas support ${support} dan menembus resistance ${resistance} dengan peningkatan volume.
• **Skenario Konsolidasi (Neutral):** Terjadi jika harga terus berfluktuasi seimbang di koridor rentang ${support} – ${resistance}.
• **Skenario Pelemahan (Bearish):** Terkonfirmasi jika tekanan jual menembus ke bawah support ${support} disertai akselerasi momentum negatif.

5. **Prinsip TRDS: No Blind Signal & Manajemen Risiko:**
• TRDS tidak pernah menyediakan sinyal beli/jual buta. Format edukasi kami adalah: **Kondisi Pasar + Bukti Data + Ketidakpastian + Konteks Risiko + Konsep Edukasi**.
• Uji skenario analisis ini secara aman di Simulator Virtual dengan disiplin Stop Loss terukur!`,
        suggestions: [
          `Bagaimana cara menguji skenario ${symbol} di Simulator?`,
          'Jelaskan konsep Overbought & Oversold pada RSI',
          'Bagaimana cara menentukan batas risiko (Stop Loss)?'
        ],
        source: 'educational_engine'
      };
    }

    return null;
  }

  private handleContextualPnL(context?: AIContext): AIResponse {
    const portfolio = context?.portfolio;
    const unrealized = portfolio?.unrealizedPnL ?? 0;
    const realized = portfolio?.realizedPnL ?? 0;
    const isNegative = unrealized < 0;
    const formattedUnrealized = `$${Math.abs(unrealized).toFixed(2)}`;

    return {
      message: `📉 **Penjelasan Edukatif: Mengapa Virtual PnL Bisa Bernilai Negatif?**

${portfolio ? `Saat ini portofolio virtualmu mencatat **Unrealized PnL sebesar ${isNegative ? '-' : '+'}${formattedUnrealized}** (${portfolio.pnlPercent}%).` : ''}

Berikut 3 alasan utama mengapa PnL mengalami penurunan:

1. **Sifat "Unrealized" (Belum Terealisasi):**
Angka ini hanyalah selisih antara harga pasar saat ini dengan harga rata-rata belimu (*Average Buy Price*). Kerugian ini **belum permanen** sebelum kamu benar-benar menjual aset tersebut.

2. **Dinamika Fluktuasi Pasar:**
Harga aset finansial bergerak naik dan turun karena hukum penawaran (*supply*) dan permintaan (*demand*). Koreksi sementara adalah hal wajar dalam setiap tren pasar.

3. **Biaya Transaksi Simulasi:**
Di TRDS, setiap transaksi memperhitungkan simulasi fee sebesar 0.10% untuk mereplikasi kondisi pasar nyata, sehingga posisi baru biasanya diawali sedikit di bawah titik impas (*break-even*).

💡 **Saran Disiplin Trader:**
Jangan panik saat melihat angka merah di simulator! Periksa kembali: apakah alasan entrimu masih valid? Jika harga menyentuh batas risiko yang kamu tetapkan, disiplinlah mengevaluasi posisi.`,
      suggestions: [
        'Bagaimana cara menghitung Risk-to-Reward Ratio?',
        'Kapan waktu yang tepat untuk Cut Loss?',
        'Jelaskan perbedaan Unrealized vs Realized PnL'
      ],
      source: 'educational_engine'
    };
  }

  private handleSimulatorWork(context?: AIContext): AIResponse {
    const balance = context?.portfolio?.cashBalance ?? 10000;
    const level = context?.user?.level ?? 1;

    return {
      message: `🕹️ **Bagaimana Cara Kerja Simulator Trading TRDS?**

Simulator TRDS dirancang khusus untuk mereplikasi pengalaman trading profesional secara **100% aman dan bebas risiko finansial**:

1. **Saldo Virtual Demo:**
Kamu dibekali modal simulasi awal sebesar **$10,000 USDT** (Saldo saat ini: **$${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}**).

2. **Data Pasar Realistis:**
Menyajikan grafik interaktif (Candlestick & Garis) dengan rentang waktu 1m, 5m, 15m, 1H, 4H, hingga 1D untuk kripto, saham, dan komoditas.

3. **Eksekusi Order Fleksibel:**
• **Market Order:** Beli/jual instan pada harga pasar terkini.
• **Limit Order:** Pasang antrean beli di bawah harga pasar atau jual di atas target harga.

4. **Portofolio & PnL Otomatis:**
Sistem menghitung otomatis laba/rugi berjalan (*Unrealized PnL*) dan laba/rugi terealisasi (*Realized PnL*).

5. **Gamifikasi & Progres:**
Setiap kali berlatih dan menyelesaikan modul, kamu meraih XP untuk meningkatkan level (saat ini kamu berada di **Level ${level}**).`,
      suggestions: [
        'Bagaimana cara pasang Limit Order?',
        'Apa itu Aturan Risiko 1%?',
        'Jelaskan cara membaca Candlestick'
      ],
      source: 'educational_engine'
    };
  }

  private handleOrderTypes(): AIResponse {
    return {
      message: `⚡ **Market Order vs Limit Order**

Keduanya adalah alat dasar dalam mengeksekusi perdagangan di pasar finansial:

| Fitur | Market Order | Limit Order |
| :--- | :--- | :--- |
| **Kecepatan** | Seketika / Instan | Menunggu harga tercapai |
| **Kepastian Harga** | Mengikuti harga pasar berjalan | Dijamin pada harga target (atau lebih baik) |
| **Tujuan Utama** | Mengutamakan kecepatan eksekusi | Mengutamakan harga masuk terbaik |
| **Potensi Risiko** | Rentan *slippage* saat pasar volatil | Ada kemungkinan order tidak pernah tereksekusi |

💡 **Contoh Praktis:**
• Jika harga BTC saat ini $62,000 dan kamu ingin beli detik ini juga ➡️ gunakan **Market Buy**.
• Jika kamu menganalisis ada support kuat di $60,500 dan ingin menunggu harga turun ke sana ➡️ pasang **Limit Buy** di $60,500.`,
      suggestions: [
        'Bagaimana cara kerja antrean Limit Order?',
        'Apa yang dimaksud dengan Slippage?',
        'Jelaskan cara menentukan Stop Loss'
      ],
      source: 'educational_engine'
    };
  }

  private handleCandlestick(): AIResponse {
    return {
      message: `🕯️ **Apa Itu Candlestick dan Cara Membacanya?**

Candlestick adalah visualisasi pergerakan harga dalam periode waktu tertentu yang memuat 4 data harga utama (**OHLC**):

• **Open (O):** Harga pembukaan pada awal periode.
• **High (H):** Harga tertinggi yang pernah dicapai.
• **Low (L):** Harga terendah yang pernah dicapai.
• **Close (C):** Harga penutupan pada akhir periode.

**Anatomi Candlestick:**
🟢 **Candle Hijau (Bullish):**
Close > Open. Menandakan tekanan beli (*buyers*) lebih dominan dari penjual.

🔴 **Candle Merah (Bearish):**
Close < Open. Menandakan tekanan jual (*sellers*) lebih dominan dari pembeli.

🦯 **Sumbu / Jarum (Wick / Shadow):**
Garis tipis di atas dan bawah badan (*body*) merepresentasikan penolakan harga (*price rejection*). Sumbu bawah panjang menunjukkan pembeli menekan harga naik kembali!`,
      suggestions: [
        'Apa itu pola Candlestick Hammer dan Doji?',
        'Bagaimana cara menentukan Support & Resistance?',
        'Jelaskan timeframe 1H vs 1D'
      ],
      source: 'educational_engine'
    };
  }

  private handleSupportResistance(): AIResponse {
    return {
      message: `🧱 **Konsep Dasar: Support & Resistance (SNR)**

Support dan Resistance adalah zona psikologis di mana aktivitas pembeli dan penjual saling berbenturan:

1. **Support (Lantai Harga):**
Area di mana minat beli (*demand*) cukup kuat untuk menghentikan penurunan harga lebih lanjut. Trader memandang area ini sebagai zona "harga diskon".

2. **Resistance (Atap Harga):**
Area di mana tekanan jual (*supply*) cukup kuat untuk menahan kenaikan harga. Trader cenderung merealisasikan profit (*take profit*) di area ini.

3. **Prinsip Breakout & Role Reversal:**
Ketika harga menembus Resistance dengan volume besar, zona tersebut sering kali berubah fungsi menjadi Support baru (*Resistance becomes Support*).`,
      suggestions: [
        'Bagaimana cara menggambar garis Support & Resistance?',
        'Apa itu False Breakout?',
        'Bagaimana cara memasang Stop Loss di dekat Support?'
      ],
      source: 'educational_engine'
    };
  }

  private handleRsi(): AIResponse {
    return {
      message: `📈 **Indikator RSI (Relative Strength Index)**

RSI adalah indikator momentum osilator yang mengukur kecepatan dan perubahan pergerakan harga dalam skala **0 hingga 100**:

• **Area Overbought (> 70):**
Aset telah mengalami pembelian masif dalam waktu singkat. Ada potensi jenuh beli dan risiko koreksi harga.

• **Area Oversold (< 30):**
Aset mengalami tekanan jual berlebihan. Ada potensi jenuh jual dan peluang pantulan harga (*rebound*).

• **Garis Tengah (50):**
Diatas 50 mengindikasikan dominasi momentum bullish; dibawah 50 mengindikasikan dominasi bearish.

⚠️ *Peringatan Edukasi:* Jangan pernah mengambil keputusan beli/jual hanya berdasarkan RSI saja. Selalu kombinasikan dengan struktur tren dan area Support/Resistance!`,
      suggestions: [
        'Apa itu RSI Divergence?',
        'Bagaimana menggabungkan RSI dengan Candlestick?',
        'Jelaskan indikator Moving Average'
      ],
      source: 'educational_engine'
    };
  }

  private handleMovingAverage(): AIResponse {
    return {
      message: `📊 **Moving Average (MA) dan Tren Pasar**

Moving Average meratakan data harga historis untuk membantu trader mengenali arah tren pasar tanpa terganggu fluktuasi jangka pendek (*noise*):

1. **SMA (Simple Moving Average):**
Rata-rata aritmatika harga penutupan selama periode tertentu (misal: 20, 50, 200 hari).

2. **EMA (Exponential Moving Average):**
Memberi bobot lebih besar pada data harga terbaru, sehingga bereaksi lebih cepat terhadap perubahan harga terkini.

3. **Golden Cross & Death Cross:**
• **Golden Cross:** MA periode pendek (misal MA 50) memotong ke atas MA periode panjang (misal MA 200) ➡️ Sinyal tren jangka panjang berpotensi bullish.
• **Death Cross:** MA periode pendek memotong ke bawah MA periode panjang ➡️ Sinyal tren jangka panjang berpotensi bearish.`,
      suggestions: [
        'Pilih mana: SMA atau EMA untuk trading harian?',
        'Bagaimana cara menggunakan MA sebagai Dinamic Support?',
        'Jelaskan indikator MACD'
      ],
      source: 'educational_engine'
    };
  }

  private handleRiskManagement(): AIResponse {
    return {
      message: `🛡️ **Pilar Terpenting: Manajemen Risiko Trading**

Tujuan nomor satu seorang trader bukanlah mencari keuntungan instan, melainkan **melindungi modal dari kehancuran**:

1. **Aturan Risiko 1% (The 1% Rule):**
Jangan pernah mempertaruhkan lebih dari 1% dari total modalmu dalam satu kali transaksi. Jika modalmu $10,000, batas kerugian maksimal per transaksi adalah $100.

2. **Risk-to-Reward Ratio (RRR):**
Usahakan rasio minimal **1:2** atau **1:3**.
• Risiko (Risk): $50 (Stop Loss)
• Potensi Hadiah (Reward): $100 (Take Profit)
Dengan rasio 1:2, meskipun tingkat kemenangan (*win rate*) kamu hanya 40%, akunmu secara akumulatif tetap mencatatkan profit!

3. **Disiplin Stop Loss:**
Tentukan selalu batas keluar (*exit plan*) sebelum kamu menekan tombol eksekusi order.`,
      suggestions: [
        'Bagaimana cara menghitung Position Sizing?',
        'Mengapa trader pemula sering mengabaikan Stop Loss?',
        'Jelaskan psikologi menghadapi kerugian (Cut Loss)'
      ],
      source: 'educational_engine'
    };
  }

  private handlePsychology(): AIResponse {
    return {
      message: `🧠 **Psikologi Trading & Pengendalian Emosi**

Lebih dari 80% kegagalan trader pemula berakar dari faktor psikologis, bukan kelemahan analisis teknikal:

1. **FOMO (Fear of Missing Out):**
Rasa takut tertinggal saat melihat harga aset melonjak tajam (candle hijau besar), mendorong aksi beli di puncak harga (*buying at the top*).

2. **Revenge Trading:**
Mencoba segera membalas kekalahan setelah mengalami kerugian dengan memperbesar ukuran posisi secara membabi-buta.

3. **Solusi Disiplin:**
• Gunakan checklist rencana sebelum masuk pasar.
• Istirahat sejenak setelah mengalami 2 kerugian beruntun.
• Selalu ingat bahwa peluang di pasar finansial akan selalu ada setiap hari.`,
      suggestions: [
        'Bagaimana cara mengatasi emosi saat mengalami loss?',
        'Pentingnya mencatat Trading Journal',
        'Jelaskan aturan risiko modal 1%'
      ],
      source: 'educational_engine'
    };
  }

  private handleGeneralPnL(context?: AIContext): AIResponse {
    return {
      message: `💰 **Konsep PnL (Profit & Loss)**

PnL mengukur performa keuntungan atau kerugian dari kegiatan trading:

• **Unrealized PnL (Floating PnL):**
Laba atau rugi berjalan dari posisi yang masih aktif terbuka. Nilai ini berubah setiap detik seiring naik-turunnya harga pasar dan baru akan menjadi riil setelah posisi ditutup.

• **Realized PnL (Laba/Rugi Terealisasi):**
Laba atau rugi bersih yang sudah permanen masuk ke saldo kas kamu setelah kamu menekan tombol Jual (*Sell*).

${context?.portfolio ? `📊 **Status Portofolio Demo Anda:**\n• Total Nilai: $${context.portfolio.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}\n• Saldo Kas: $${context.portfolio.cashBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}\n• Total PnL: ${context.portfolio.totalPnL >= 0 ? '+' : ''}$${context.portfolio.totalPnL.toFixed(2)} (${context.portfolio.pnlPercent}%)` : ''}`,
      suggestions: [
        'Kenapa Unrealized PnL saya bisa negatif?',
        'Bagaimana rumus menghitung PnL persentase?',
        'Jelaskan biaya simulasi (Trading Fee)'
      ],
      source: 'educational_engine'
    };
  }

  private handleSelectedAssetInquiry(asset: NonNullable<AIContext['selectedAsset']>, context: AIContext): AIResponse {
    return {
      message: `🔍 **Ringkasan Edukasi Instrumen: ${asset.name} (${asset.symbol})**

• **Harga Demo Terkini:** $${asset.price.toLocaleString('en-US', { minimumFractionDigits: asset.price < 1 ? 4 : 2 })}
• **Perubahan 24 Jam:** ${asset.change24h >= 0 ? '+' : ''}${asset.change24h}%
• **Kategori Instrumen:** ${asset.category?.toUpperCase() || 'VIRTUAL ASSET'}

💡 **Saran Eksplorasi di Simulator:**
1. Buka tab **Simulator** dan amati pola pergerakan harga pada timeframe 15m dan 1H.
2. Identifikasi titik terendah 24 jam terakhir sebagai zona support awal.
3. Coba pasang **Limit Order Beli** di bawah harga saat ini untuk melatih kesabaran antrean pasar!`,
      suggestions: [
        `Bagaimana prospek analisis teknikal ${asset.symbol}?`,
        'Berapa ukuran posisi yang aman untuk aset ini?',
        'Jelaskan perbedaan volatilitas kripto vs saham'
      ],
      source: 'educational_engine'
    };
  }

  private handleGreeting(context?: AIContext): AIResponse {
    const userName = context?.user?.levelTitle || 'Trader Pembelajar';

    return {
      message: `Halo, **${userName}**! 👋 Senang bisa mendampingi proses belajarmu di TRDS.

Saya adalah **TRDS AI**, asisten edukasi pasar finansial virtual. Kamu bisa menanyakan:
• Istilah trading (PnL, Candlestick, Support & Resistance)
• Analisis teknikal & indikator (RSI, MA, MACD)
• Prinsip manajemen risiko & psikologi pasar
• Cara kerja fitur order dan portofolio di Simulator TRDS

Apa konsep atau modul yang ingin kamu bedah hari ini?`,
      suggestions: [
        'Jelaskan konsep PnL',
        'Apa itu Candlestick?',
        'Market vs Limit Order',
        'Bagaimana cara kerja simulator?'
      ],
      source: 'educational_engine'
    };
  }

  private handleFallback(trimmed: string, context?: AIContext): AIResponse {
    return {
      message: `Pertanyaan yang sangat menarik mengenai **"${trimmed}"**!

Dalam edukasi pasar finansial dan simulasi trading, memahami konsep fundamental adalah langkah awal yang krusial sebelum menerapkan strategi eksekusi.

Berikut 3 pilar yang dapat kamu jadikan acuan belajar:
1. **Analisis Teknis & Tren:** Amati apakah pasar sedang berada dalam fase tren (*trending*) atau fase konsolidasi (*sideways*).
2. **Kalkulasi Risiko:** Selalu pastikan potensi kerugian sudah kamu ketahui dan terima sebelum membuka posisi di simulator.
3. **Praktik Mandiri:** Uji coba konsep ini secara langsung dengan modal virtual $10,000 USDT di tab Simulator.

Apakah kamu ingin penjelasan lebih spesifik terkait indikator, tipe order, atau manajemen risiko untuk topik ini?`,
      suggestions: [
        'Jelaskan strategi manajemen risiko yang aman',
        'Bagaimana cara membaca grafik Candlestick?',
        'Apa perbedaan Market Order dan Limit Order?'
      ],
      source: 'educational_engine'
    };
  }
}

// Singleton export
export const aiService: IAIService = new DevelopmentAIService();
