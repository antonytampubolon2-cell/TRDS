/**
 * RevenueCat Service Layer for TRDS
 * Phase 6 — TRDS Premium + RevenueCat Integration Foundation
 *
 * Responsibilities:
 * - Initialize RevenueCat configuration safely (without exposing secrets)
 * - Load offerings and packages
 * - Manage and verify "trds_premium" customer entitlement
 * - Execute purchase flow with store state handling
 * - Restore existing purchases
 * - Graceful fallback and development testing mode when live store products are pending
 */

import {
  TRDS_PREMIUM_ENTITLEMENT,
  RevenueCatPackage,
  RevenueCatOffering,
  CustomerInfo,
  CustomerEntitlement,
  PremiumState,
  PurchaseError,
  PurchaseErrorCode
} from '../types/revenueCat';

const STORAGE_KEYS = {
  PREMIUM_STATE: 'trds_rc_premium_state',
  ACTIVE_PACKAGE: 'trds_rc_active_package',
  DEV_MOCK_OVERRIDE: 'trds_rc_dev_mock_override'
};

// Default educational offering packages
export const DEFAULT_TRDS_OFFERING: RevenueCatOffering = {
  identifier: 'default_educational_offering',
  serverDescription: 'TRDS Premium Educational & Simulator Access',
  availablePackages: [
    {
      identifier: '$rc_monthly',
      packageType: 'monthly',
      badgeText: 'Fleksibel',
      isPopular: false,
      product: {
        identifier: 'trds_premium_monthly_499',
        title: 'TRDS Premium Bulanan',
        description: 'Akses penuh ke seluruh materi lanjutan, kuis pro, & metrik simulator.',
        price: 4.99,
        priceString: '$4.99/bulan',
        currencyCode: 'USD',
        subscriptionPeriod: 'P1M'
      }
    },
    {
      identifier: '$rc_annual',
      packageType: 'annual',
      badgeText: 'Paling Populer • Hemat 33%',
      isPopular: true,
      product: {
        identifier: 'trds_premium_annual_3999',
        title: 'TRDS Premium Tahunan',
        description: 'Termasuk 7 hari demo trial gratis, kurikulum lengkap, dan AI Deep Dive.',
        price: 39.99,
        priceString: '$39.99/tahun (~$3.33/bln)',
        currencyCode: 'USD',
        subscriptionPeriod: 'P1Y',
        introductoryPrice: {
          priceString: 'Gratis 7 Hari',
          period: 'P7D',
          cycles: 1
        }
      }
    },
    {
      identifier: '$rc_lifetime',
      packageType: 'lifetime',
      badgeText: 'Sekali Bayar',
      isPopular: false,
      product: {
        identifier: 'trds_premium_lifetime_9999',
        title: 'TRDS Premium Lifetime Pass',
        description: 'Akses seumur hidup ke semua pembaruan materi dan instrumen baru.',
        price: 99.99,
        priceString: '$99.99 sekali bayar',
        currencyCode: 'USD'
      }
    }
  ]
};

export class RevenueCatService {
  private apiKey: string;
  private appUserId: string;
  private isInitialized: boolean = false;
  private currentOffering: RevenueCatOffering | null = null;
  private customerInfo: CustomerInfo | null = null;

  constructor() {
    // Read public SDK key from Vite environment if available (safe, public key placeholder)
    this.apiKey = (import.meta as any).env?.VITE_REVENUECAT_PUBLIC_SDK_KEY || '';
    this.appUserId = 'trds_user_' + Math.floor(100000 + Math.random() * 900000);
  }

  /**
   * Initializes RevenueCat configuration safely
   */
  public initialize(customApiKey?: string): { success: boolean; isConfigured: boolean; message: string } {
    if (customApiKey) {
      this.apiKey = customApiKey;
    }

    this.isInitialized = true;
    this.currentOffering = DEFAULT_TRDS_OFFERING;

    const hasValidKey = Boolean(this.apiKey && !this.apiKey.includes('REVENUECAT_PUBLIC_SDK_KEY'));

    return {
      success: true,
      isConfigured: hasValidKey,
      message: hasValidKey
        ? 'RevenueCat SDK terkonfigurasi dengan Public Key.'
        : 'RevenueCat berjalan dalam Development Sandbox Mode (Key Store belum terhubung).'
    };
  }

  /**
   * Checks whether a live production RevenueCat API key is configured
   */
  public isConfigured(): boolean {
    return Boolean(this.apiKey && !this.apiKey.includes('REVENUECAT_PUBLIC_SDK_KEY'));
  }

  /**
   * Gets available offerings for the customer
   */
  public async getOfferings(): Promise<{ offering: RevenueCatOffering; isMock: boolean }> {
    // In production with SDK, this calls Purchases.getOfferings()
    // Here we return the configured educational offering packages
    return {
      offering: this.currentOffering || DEFAULT_TRDS_OFFERING,
      isMock: !this.isConfigured()
    };
  }

  /**
   * Gets customer info and checks entitlement status
   */
  public getCustomerInfo(): CustomerInfo {
    const isMockPremiumActive = localStorage.getItem(STORAGE_KEYS.PREMIUM_STATE) === 'true';
    const activePackageId = localStorage.getItem(STORAGE_KEYS.ACTIVE_PACKAGE) || '$rc_annual';

    const entitlement: CustomerEntitlement = {
      identifier: TRDS_PREMIUM_ENTITLEMENT,
      isActive: isMockPremiumActive,
      willRenew: true,
      periodType: 'normal',
      latestPurchaseDateMillis: Date.now() - 86400000,
      expirationDateMillis: Date.now() + 30 * 86400000,
      productIdentifier: activePackageId,
      isSandbox: !this.isConfigured()
    };

    const info: CustomerInfo = {
      entitlements: {
        all: { [TRDS_PREMIUM_ENTITLEMENT]: entitlement },
        active: isMockPremiumActive ? { [TRDS_PREMIUM_ENTITLEMENT]: entitlement } : {}
      },
      activeSubscriptions: isMockPremiumActive ? [activePackageId] : [],
      allPurchasedProductIdentifiers: isMockPremiumActive ? [activePackageId] : [],
      latestExpirationDate: isMockPremiumActive ? new Date(Date.now() + 30 * 86400000).toISOString() : null,
      originalAppUserId: this.appUserId,
      requestDate: new Date().toISOString()
    };

    this.customerInfo = info;
    return info;
  }

  /**
   * Checks if user has the active "trds_premium" entitlement
   */
  public isPremiumUser(): boolean {
    const info = this.getCustomerInfo();
    return Boolean(info.entitlements.active[TRDS_PREMIUM_ENTITLEMENT]?.isActive);
  }

  /**
   * Purchases a package through RevenueCat
   */
  public async purchasePackage(packageId: string): Promise<{
    success: boolean;
    customerInfo?: CustomerInfo;
    error?: PurchaseError;
  }> {
    try {
      // Simulate network / store interaction latency
      await new Promise(resolve => setTimeout(resolve, 800));

      const selectedPackage = DEFAULT_TRDS_OFFERING.availablePackages.find(p => p.identifier === packageId);
      if (!selectedPackage) {
        return {
          success: false,
          error: {
            code: 'PRODUCT_NOT_AVAILABLE',
            message: `Package ${packageId} not found in offerings`,
            userMessage: 'Paket langganan yang dipilih tidak ditemukan atau belum aktif di store.'
          }
        };
      }

      // If configured with real store SDK in native app, it triggers Purchases.purchasePackage(package)
      // For web/preview development environment without live App Store connection:
      localStorage.setItem(STORAGE_KEYS.PREMIUM_STATE, 'true');
      localStorage.setItem(STORAGE_KEYS.ACTIVE_PACKAGE, packageId);

      const updatedInfo = this.getCustomerInfo();

      return {
        success: true,
        customerInfo: updatedInfo
      };
    } catch (err: any) {
      return {
        success: false,
        error: {
          code: 'STORE_PROBLEM',
          message: err?.message || 'Store error during purchase',
          userMessage: 'Terjadi kendala saat memproses pembelian ke store. Silakan coba kembali.'
        }
      };
    }
  }

  /**
   * Restores past purchases
   */
  public async restorePurchases(): Promise<{
    success: boolean;
    restored: boolean;
    customerInfo: CustomerInfo;
    error?: PurchaseError;
  }> {
    try {
      await new Promise(resolve => setTimeout(resolve, 700));

      const hasPreviousPurchase = localStorage.getItem(STORAGE_KEYS.PREMIUM_STATE) === 'true';

      if (!hasPreviousPurchase) {
        return {
          success: true,
          restored: false,
          customerInfo: this.getCustomerInfo(),
          error: {
            code: 'RESTORE_NO_PURCHASES',
            message: 'No previous active purchases found for this user',
            userMessage: 'Tidak ditemukan riwayat langganan aktif yang dapat dipulihkan pada akun ini.'
          }
        };
      }

      const info = this.getCustomerInfo();
      return {
        success: true,
        restored: true,
        customerInfo: info
      };
    } catch (err: any) {
      return {
        success: false,
        restored: false,
        customerInfo: this.getCustomerInfo(),
        error: {
          code: 'NETWORK_ERROR',
          message: err?.message || 'Failed to restore purchases',
          userMessage: 'Gagal menghubungkan ke server store untuk pemulihan pembelian.'
        }
      };
    }
  }

  /**
   * Development mode helper: allows toggling state cleanly for UI verification
   */
  public setDevelopmentMockEntitlement(isActive: boolean, packageId: string = '$rc_annual'): CustomerInfo {
    localStorage.setItem(STORAGE_KEYS.PREMIUM_STATE, isActive ? 'true' : 'false');
    if (isActive) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_PACKAGE, packageId);
    } else {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_PACKAGE);
    }
    return this.getCustomerInfo();
  }
}

export const revenueCatService = new RevenueCatService();
