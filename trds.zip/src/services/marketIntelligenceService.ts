import {
  Asset,
  MarketIntelligenceData,
  IndicatorDetail,
  MarketTrendType,
  MomentumType,
  VolatilityType,
  MarketQuote,
  AdvancedMarketCondition,
  AdvancedMomentumState,
  AdvancedVolatilityLevel,
  AdvancedTrendContext,
  AdvancedMarketStrengthType,
  VolumeContextState,
  AnalysisConfidenceLevel,
  AdvancedRiskLevel,
  EducationalScenario,
  DataQualityReport,
  MarketViewSummary
} from '../types';

/**
 * TRDS Advanced Market Intelligence Multi-Factor Calculation Engine
 * "Jangan hanya melihat pasar. Pahami alasannya."
 *
 * Catatan Edukasi Kritis:
 * Seluruh analisis ini disusun sebagai instrumen edukasi teknikal multi-faktor objektif,
 * BUKAN sinyal beli/jual dan BUKAN jaminan masa depan. TRDS tidak menyediakan rekomendasi finansial nyata.
 */

export function calculateMarketIntelligence(asset: Asset | MarketQuote): MarketIntelligenceData {
  const isQuote = 'dataStatus' in asset;
  const quoteStatus = isQuote ? (asset as MarketQuote).dataStatus : 'SIMULATED';
  const quoteSource = isQuote ? (asset as MarketQuote).source : 'simulation';
  const timestamp = isQuote ? (asset as MarketQuote).timestamp : Date.now();
  const isStale = isQuote ? Boolean((asset as MarketQuote).isStale) : false;
  const changePercent24h = isQuote
    ? ((asset as MarketQuote).changePercent24h ?? (asset.change24h ? asset.change24h / 100 : 0))
    : (asset.change24h ? asset.change24h / 100 : 0);
  const isUnavailable = quoteStatus === 'UNAVAILABLE' || asset.price <= 0;

  const quoteDate = new Date(timestamp);
  const lastUpdated = quoteDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  // 1. Transparent Fallback for UNAVAILABLE or non-positive price state
  if (isUnavailable) {
    const insufficientDetail: IndicatorDetail = {
      name: 'Data Tidak Tersedia',
      code: 'volume',
      value: 'N/A',
      status: 'Data belum mencukupi',
      explanation: 'Data historis belum mencukupi untuk menghitung indikator ini secara akurat.',
      conceptTitle: 'Ketersediaan Data',
      conceptSummary: 'Analisis teknikal memerlukan umpan data harga yang valid dan kontinu.'
    };

    const dataQuality: DataQualityReport = {
      status: 'UNAVAILABLE',
      statusLabel: 'DATA UNAVAILABLE',
      lastUpdated,
      source: quoteSource,
      freshness: 'Terputus (Feed Disconnected)',
      isStale: true
    };

    const marketView: MarketViewSummary = {
      condition: 'NEUTRAL',
      momentum: 'Neutral',
      volatility: 'LOW',
      trendContext: 'Mixed',
      marketStrength: 'Order-book pressure unavailable',
      riskContext: 'VERY HIGH',
      dataQuality: 'DATA UNAVAILABLE',
      whyExplanation: 'Analisis multi-faktor belum dapat disusun karena umpan data harga pasar sementara tidak dapat diakses dari penyedia feed.'
    };

    const scenarios: EducationalScenario[] = [
      {
        type: 'Bullish Scenario',
        title: 'Skenario Penguatan (Bullish Scenario)',
        supportingConditions: 'Jika koneksi feed pulih dan pembeli mempertahankan harga di atas support teknikal dengan peningkatan likuiditas.',
        keyEducationalWatchpoint: 'Perhatikan apakah harga stabil setelah data feed kembali aktif.'
      },
      {
        type: 'Neutral Scenario',
        title: 'Skenario Konsolidasi (Neutral Scenario)',
        supportingConditions: 'Jika harga bergerak menyamping dalam koridor sempit setelah koneksi pulih tanpa dorongan volume dominan.',
        keyEducationalWatchpoint: 'Amati formasi sideways dan penyempitan rentang harga.'
      },
      {
        type: 'Bearish Scenario',
        title: 'Skenario Pelemahan (Bearish Scenario)',
        supportingConditions: 'Jika tekanan jual dominan menekan harga ke bawah level penahan saat data feed aktif kembali.',
        keyEducationalWatchpoint: 'Waspadai potensi gap harga jika pergerakan terjadi saat feed terputus.'
      }
    ];

    return {
      assetId: asset.id,
      symbol: asset.symbol,
      price: asset.price,
      change24h: asset.change24h || 0,
      changePercent24h,
      trend: 'Neutral',
      trendExplanation: 'Data harga pasar saat ini belum tersedia untuk menentukan arah tren secara objektif.',
      momentum: 'Weak',
      momentumExplanation: 'Momentum tidak dapat diukur karena keterbatasan data feed.',
      volatility: 'Low',
      volatilityExplanation: 'Rentang volatilitas tidak dapat dipastikan tanpa data pergerakan kontinu.',
      marketStrength: 'Order-book pressure unavailable',
      marketStrengthPercent: 50,
      score: 50,
      support: 0,
      resistance: 0,
      supportExplanation: 'Insufficient data',
      resistanceExplanation: 'Insufficient data',
      hasInsufficientSupportResistance: true,
      volume: 'N/A',
      volumeEvaluation: 'Volume data unavailable',
      indicators: [insufficientDetail],
      rsi: { ...insufficientDetail, name: 'RSI (Relative Strength Index)', code: 'rsi' },
      macd: { ...insufficientDetail, name: 'MACD', code: 'macd' },
      ma: { ...insufficientDetail, name: 'Moving Average (MA)', code: 'ma' },
      bollingerBands: { ...insufficientDetail, name: 'Bollinger Bands', code: 'bb' },
      volumeIndicator: insufficientDetail,
      priceMomentum: { ...insufficientDetail, name: 'Price Momentum', code: 'momentum' },
      whyAnalysis: {
        overview: 'Analisis belum dapat ditampilkan karena data pasar sementara tidak tersedia.',
        factors: [{
          title: 'Koneksi Data Pasar',
          detail: 'Data pasar untuk instrumen ini sedang dalam pembaruan atau belum tersedia dari penyedia feed.',
          statusBadge: 'Tertunda'
        }],
        dataAvailability: 'insufficient'
      },
      marketSummary: {
        whatHappened: `Umpan data untuk ${asset.symbol} sementara belum dapat diakses.`,
        whatToLearn: 'Dalam trading nyata, data feed yang terputus atau tidak lengkap memerlukan kehati-hatian ekstra.'
      },
      riskContext: {
        volatilityNote: 'Tidak ada data volatilitas yang dapat diandalkan saat data terputus.',
        uncertaintyNote: 'Jangan mengambil keputusan simulasi saat kondisi data belum terverifikasi.',
        trendStabilityNote: 'Status data pasar: DATA UNAVAILABLE.',
        riskFactors: [
          'Umpan data belum diperbarui dari penyedia feed.',
          'Tidak dapat menghitung level support/resistance yang reliabel.'
        ]
      },
      lastUpdated,
      isSimulatedData: quoteStatus !== 'LIVE',
      dataStatus: quoteStatus,
      dataSource: quoteSource,
      timestamp,
      isStale,

      // Advanced Multi-Factor Analysis
      advancedCondition: 'NEUTRAL',
      conditionReasons: [
        'Data pasar saat ini tidak tersedia dari feed',
        'Analisis tidak dapat disimpulkan tanpa data harga kontinu'
      ],
      advancedMomentum: 'Neutral',
      advancedMomentumExplanation: 'Momentum tidak dapat diukur karena umpan data belum aktif.',
      advancedVolatility: 'LOW',
      volatilityEducationalNote: 'Higher volatility means larger price movement and greater uncertainty. Data saat ini tidak tersedia.',
      trendContext: 'Mixed',
      trendContextExplanation: 'Konteks tren tidak dapat dievaluasi tanpa data pergerakan kontinu.',
      marketStrengthCategory: 'Balanced',
      orderBookPressureAvailable: false,
      orderBookPressureNote: 'Order-book pressure unavailable (Umpan data tidak aktif)',
      volumeContext: 'Unavailable',
      volumeContextExplanation: 'Volume data unavailable',
      dataQuality,
      analysisConfidence: 'LOW DATA CONFIDENCE',
      analysisConfidenceExplanation: 'Confidence reflects the quality and consistency of the available market data, not a guarantee of future price direction. Tingkat keyakinan data rendah karena feed data pasar belum tersedia.',
      riskLevel: 'VERY HIGH',
      riskPrimaryReasons: [
        'Data pasar tidak tersedia (Data feed disconnected)',
        'Keputusan simulasi tidak dapat diuji secara reliabel'
      ],
      marketView,
      scenarios
    };
  }

  // 2. Continuous Data Processing
  const sparkline = asset.sparkline && asset.sparkline.length > 0 ? asset.sparkline : [asset.price];
  const hasSufficientHistory = sparkline.length >= 3;
  const price = asset.price;
  const high24h = asset.high24h ?? Math.max(...sparkline, price);
  const low24h = asset.low24h ?? Math.min(...sparkline, price);
  const change24h = asset.change24h ?? 0;

  // Volume Context validation (strictly never fabricate fake volume)
  const rawVolume = asset.volume ? asset.volume.trim() : '';
  const hasValidVolume = Boolean(
    rawVolume &&
    rawVolume !== 'N/A' &&
    rawVolume !== 'Data belum tersedia' &&
    rawVolume !== '-'
  );
  const volumeStr = hasValidVolume ? rawVolume : 'Volume data unavailable';

  let volumeContext: VolumeContextState = 'Unavailable';
  let volumeContextExplanation = 'Volume data unavailable';
  if (hasValidVolume) {
    if (Math.abs(change24h) > 3.0) {
      volumeContext = 'Increasing';
      volumeContextExplanation = `Volume likuiditas aktif (${volumeStr}) menunjukkan peningkatan partisipasi transaksi dalam rentang pergerakan 24 jam.`;
    } else if (Math.abs(change24h) < 0.8) {
      volumeContext = 'Decreasing';
      volumeContextExplanation = `Volume likuiditas (${volumeStr}) mencerminkan penurunan aktivitas perdagangan, konsisten dengan fase konsolidasi.`;
    } else {
      volumeContext = 'Average';
      volumeContextExplanation = `Volume likuiditas sebesar ${volumeStr} berada di kisaran rata-rata normal untuk aset ini.`;
    }
  }

  // 3. Mathematical Calculations: Moving Average, Intraday Range, Sparkline Slope
  const sum = sparkline.reduce((acc, v) => acc + v, 0);
  const sparklineAvg = sum / sparkline.length;
  const priceVsAvgPercent = ((price - sparklineAvg) / sparklineAvg) * 100;
  const intradayRangePercent = ((high24h - low24h) / (price || 1)) * 100;

  // RSI calculation from sparkline steps
  let gains = 0;
  let losses = 0;
  for (let i = 1; i < sparkline.length; i++) {
    const diff = sparkline[i] - sparkline[i - 1];
    if (diff > 0) gains += diff;
    else losses += Math.abs(diff);
  }
  const avgGain = gains / Math.max(1, sparkline.length - 1);
  const avgLoss = losses / Math.max(1, sparkline.length - 1);

  let calculatedRsi = 50;
  if (avgLoss === 0) {
    calculatedRsi = gains > 0 ? 78 : 50;
  } else {
    const rs = avgGain / avgLoss;
    calculatedRsi = Math.round(100 - (100 / (1 + rs)));
  }
  if (change24h > 5 && calculatedRsi < 65) calculatedRsi = Math.min(84, 60 + Math.round(change24h * 2));
  if (change24h < -5 && calculatedRsi > 35) calculatedRsi = Math.max(18, 40 - Math.round(Math.abs(change24h) * 2));
  calculatedRsi = Math.max(15, Math.min(88, calculatedRsi));

  // 4. Trend Context Classification & Explanation
  let trendContext: AdvancedTrendContext = 'Range / Sideways';
  let trendContextExplanation = '';
  let trend: MarketTrendType = 'Neutral';
  let trendExplanation = '';

  if (change24h > 1.2 && price >= sparklineAvg) {
    trend = 'Bullish';
    trendContext = 'Uptrend Context';
    trendContextExplanation = 'Struktur pergerakan harga saat ini berada di atas moving average jangka pendek dengan momentum 24 jam positif.';
    trendExplanation = 'Harga bergerak di atas rata-rata tren jangka pendek dengan akumulasi kenaikan 24 jam positif.';
  } else if (change24h < -1.2 && price <= sparklineAvg) {
    trend = 'Bearish';
    trendContext = 'Downtrend Context';
    trendContextExplanation = 'Struktur pergerakan harga berada di bawah moving average jangka pendek dengan desakan penurunan 24 jam.';
    trendExplanation = 'Harga tertekan di bawah rata-rata tren jangka pendek dengan tekanan jual dominan 24 jam.';
  } else if ((change24h > 1.0 && price < sparklineAvg) || (change24h < -1.0 && price > sparklineAvg)) {
    trend = 'Neutral';
    trendContext = 'Mixed';
    trendContextExplanation = 'Price movement is currently showing conflicting trend signals; arah 24 jam dan posisi relatif terhadap moving average belum selaras.';
    trendExplanation = 'Sinyal arah pergerakan harga belum selaras antara pergerakan 24 jam dan posisi garis moving average.';
  } else {
    trend = 'Neutral';
    trendContext = 'Range / Sideways';
    trendContextExplanation = 'Price movement is currently showing a sideways/range context di sekitar rata-rata pergerakannya.';
    trendExplanation = 'Harga berada di area konsolidasi seimbang antara kekuatan beli dan jual.';
  }

  // 5. Momentum Classification (Strong Positive, Positive, Neutral, Negative, Strong Negative)
  let advancedMomentum: AdvancedMomentumState = 'Neutral';
  let advancedMomentumExplanation = '';
  let legacyMomentum: MomentumType = 'Moderate';

  if (change24h >= 4.0 || (change24h >= 2.5 && calculatedRsi >= 68)) {
    advancedMomentum = 'Strong Positive';
    legacyMomentum = 'Strong';
    advancedMomentumExplanation = `Momentum sangat positif didorong kenaikan signifikan +${change24h}% dalam 24 jam dan laju RSI (${calculatedRsi}) yang ekspansif. Ini mendeskripsikan laju perubahan harga saat ini, bukan jaminan kenaikan terus-menerus.`;
  } else if (change24h >= 0.8) {
    advancedMomentum = 'Positive';
    legacyMomentum = 'Moderate';
    advancedMomentumExplanation = `Momentum positif moderat (+${change24h}% dalam 24 jam) dengan pergerakan teratur di atas garis netral.`;
  } else if (change24h <= -4.0 || (change24h <= -2.5 && calculatedRsi <= 32)) {
    advancedMomentum = 'Strong Negative';
    legacyMomentum = 'Strong';
    advancedMomentumExplanation = `Momentum sangat negatif akibat penurunan ${change24h}% dalam 24 jam dan tekanan jual intensif pada RSI (${calculatedRsi}). Ini menggambarkan desakan penurunan terkini tanpa ramalan masa depan.`;
  } else if (change24h <= -0.8) {
    advancedMomentum = 'Negative';
    legacyMomentum = 'Moderate';
    advancedMomentumExplanation = `Momentum negatif moderat (${change24h}% dalam 24 jam) mencerminkan tekanan jual bertahap di bawah garis ekuilibrium.`;
  } else {
    advancedMomentum = 'Neutral';
    legacyMomentum = 'Weak';
    advancedMomentumExplanation = `Momentum netral (${change24h >= 0 ? '+' : ''}${change24h}%), fluktuasi harga dalam 24 jam terakhir relatif stabil dan tidak menunjukkan akselerasi dominan.`;
  }

  // 6. Volatility Classification (LOW, MEDIUM, HIGH, EXTREME)
  let advancedVolatility: AdvancedVolatilityLevel = 'MEDIUM';
  let legacyVolatility: VolatilityType = 'Medium';
  let volatilityExplanation = '';

  if (intradayRangePercent < 2.0) {
    advancedVolatility = 'LOW';
    legacyVolatility = 'Low';
    volatilityExplanation = `Rentang pergerakan harga relatif sempit (${intradayRangePercent.toFixed(2)}%), menandakan fluktuasi tenang.`;
  } else if (intradayRangePercent <= 5.5) {
    advancedVolatility = 'MEDIUM';
    legacyVolatility = 'Medium';
    volatilityExplanation = `Rentang fluktuasi harian dalam batas normal (${intradayRangePercent.toFixed(2)}%), dinamika harga berimbang.`;
  } else if (intradayRangePercent <= 9.0) {
    advancedVolatility = 'HIGH';
    legacyVolatility = 'High';
    volatilityExplanation = `Rentang pergerakan harga lebar (${intradayRangePercent.toFixed(2)}%), risiko ayunan harga tajam meningkat.`;
  } else {
    advancedVolatility = 'EXTREME';
    legacyVolatility = 'High';
    volatilityExplanation = `Rentang harga sangat ekstrem (${intradayRangePercent.toFixed(2)}%), pergerakan liar dengan ketidakpastian tinggi.`;
  }

  const volatilityEducationalNote = 'Higher volatility means larger price movement and greater uncertainty.';

  // 7. Support & Resistance Calculations (with honest educational context)
  const minSpark = Math.min(...sparkline);
  const maxSpark = Math.max(...sparkline);
  const support = Math.min(low24h, minSpark);
  const resistance = Math.max(high24h, maxSpark);
  const hasInsufficientSupportResistance = !hasSufficientHistory || support <= 0 || resistance <= 0;

  const supportExplanation = hasInsufficientSupportResistance
    ? 'Insufficient data'
    : 'Area di mana aktivitas pasar sebelumnya menunjukkan minat beli potensial yang mampu menahan laju penurunan.';
  const resistanceExplanation = hasInsufficientSupportResistance
    ? 'Insufficient data'
    : 'Area di mana aktivitas pasar sebelumnya menunjukkan potensi tekanan jual yang membatasi kenaikan lebih lanjut.';

  // 8. Market Strength (Bullish Pressure, Bearish Pressure, Balanced)
  // Strictly avoid fabricating order-book data!
  let marketStrengthCategory: AdvancedMarketStrengthType = 'Balanced';
  let marketStrengthPercent = 50;

  if (priceVsAvgPercent > 0.8 && change24h > 0.5) {
    marketStrengthPercent = Math.min(92, Math.max(58, Math.round(50 + change24h * 2.8)));
    marketStrengthCategory = 'Bullish Pressure';
  } else if (priceVsAvgPercent < -0.8 && change24h < -0.5) {
    marketStrengthPercent = Math.min(92, Math.max(58, Math.round(50 + Math.abs(change24h) * 2.8)));
    marketStrengthCategory = 'Bearish Pressure';
  } else {
    marketStrengthPercent = 50;
    marketStrengthCategory = 'Balanced';
  }

  const marketStrength = marketStrengthCategory;
  const orderBookPressureAvailable = false;
  const orderBookPressureNote = 'Order-book pressure unavailable (tidak tersedia tanpa feed kedalaman order Level-2)';

  // 9. Market Condition (BULLISH, BEARISH, NEUTRAL, MIXED)
  let advancedCondition: AdvancedMarketCondition = 'NEUTRAL';
  const conditionReasons: string[] = [];

  if (
    trendContext === 'Uptrend Context' &&
    (advancedMomentum === 'Positive' || advancedMomentum === 'Strong Positive') &&
    marketStrengthCategory === 'Bullish Pressure'
  ) {
    advancedCondition = 'BULLISH';
    conditionReasons.push(`positive recent momentum (${change24h >= 0 ? '+' : ''}${change24h}%)`);
    conditionReasons.push(`price holding above relevant support ($${support.toLocaleString('en-US', { maximumFractionDigits: support < 1 ? 4 : 2 })})`);
    conditionReasons.push('market strength showing buying pressure');
  } else if (
    trendContext === 'Downtrend Context' &&
    (advancedMomentum === 'Negative' || advancedMomentum === 'Strong Negative') &&
    marketStrengthCategory === 'Bearish Pressure'
  ) {
    advancedCondition = 'BEARISH';
    conditionReasons.push(`negative recent momentum (${change24h}%)`);
    conditionReasons.push(`price pressing towards support area ($${support.toLocaleString('en-US', { maximumFractionDigits: support < 1 ? 4 : 2 })})`);
    conditionReasons.push('market strength showing selling pressure');
  } else if (
    trendContext === 'Mixed' ||
    (change24h > 1.2 && price < sparklineAvg) ||
    (change24h < -1.2 && price > sparklineAvg)
  ) {
    advancedCondition = 'MIXED';
    conditionReasons.push('conflicting momentum and moving average signals');
    conditionReasons.push('price testing boundary zones without unified direction');
    conditionReasons.push('market strength showing divided pressure between buyers and sellers');
  } else {
    advancedCondition = 'NEUTRAL';
    conditionReasons.push('momentum is within balanced sideways boundaries');
    conditionReasons.push(`price oscillating between support and resistance ($${support.toLocaleString('en-US', { maximumFractionDigits: support < 1 ? 4 : 2 })} – $${resistance.toLocaleString('en-US', { maximumFractionDigits: resistance < 1 ? 4 : 2 })})`);
    conditionReasons.push('market strength is balanced without breakout pressure');
  }

  // 10. Data Quality Report
  let statusLabel = 'DATA SIMULASI';
  let freshness = 'Fresh (Tersinkronisasi)';
  if (quoteStatus === 'LIVE') {
    statusLabel = 'LIVE MARKET DATA';
    freshness = isStale ? 'Stale (Keterlambatan pembaruan provider)' : 'Fresh (Real-time feed)';
  } else if (quoteStatus === 'STALE' || isStale) {
    statusLabel = 'STALE DATA';
    freshness = 'Stale (Keterlambatan pembaruan feed)';
  } else if (quoteStatus === 'UPDATING') {
    statusLabel = 'UPDATING...';
    freshness = 'Sedang memperbarui...';
  }

  const dataQuality: DataQualityReport = {
    status: isStale ? 'STALE' : quoteStatus,
    statusLabel,
    lastUpdated,
    source: quoteSource,
    freshness,
    isStale
  };

  // 11. Analysis Confidence & Uncertainty
  let analysisConfidence: AnalysisConfidenceLevel = 'MEDIUM DATA CONFIDENCE';
  let analysisConfidenceExplanation = '';

  if (quoteStatus === 'LIVE' && !isStale && hasSufficientHistory && hasValidVolume) {
    analysisConfidence = 'HIGH DATA CONFIDENCE';
    analysisConfidenceExplanation = 'Tingkat kelengkapan data feed tinggi dengan validasi histori harga dan volume likuiditas aktif.';
  } else if (!isStale && hasSufficientHistory) {
    analysisConfidence = 'MEDIUM DATA CONFIDENCE';
    analysisConfidenceExplanation = 'Data pasar memadai untuk evaluasi teknikal edukatif, dengan parameter konsisten pada simulasi virtual.';
  } else {
    analysisConfidence = 'LOW DATA CONFIDENCE';
    analysisConfidenceExplanation = 'Kelengkapan data terbatas akibat status stale atau keterbatasan histori pergerakan.';
  }

  // 12. Risk Context (LOW, MODERATE, HIGH, VERY HIGH)
  let riskLevel: AdvancedRiskLevel = 'MODERATE';
  const riskPrimaryReasons: string[] = [];

  if (isStale || advancedVolatility === 'EXTREME') {
    riskLevel = 'VERY HIGH';
    if (isStale) riskPrimaryReasons.push('Umpan data berstatus STALE (keterlambatan feed)');
    if (advancedVolatility === 'EXTREME') riskPrimaryReasons.push('Volatilitas ekstrem dengan fluktuasi harga >9%');
  } else if (advancedVolatility === 'HIGH' || Math.abs(change24h) > 5.0 || advancedCondition === 'MIXED') {
    riskLevel = 'HIGH';
    if (advancedVolatility === 'HIGH') riskPrimaryReasons.push('Rentang volatilitas tinggi meningkatkan potensi ayunan liar (whipsaw)');
    if (Math.abs(change24h) > 5.0) riskPrimaryReasons.push('Perubahan harga 24 jam sangat tajam');
    if (advancedCondition === 'MIXED') riskPrimaryReasons.push('Sinyal teknikal saling bertentangan (Conflicting signals)');
  } else if (advancedVolatility === 'MEDIUM' || Math.abs(change24h) > 1.2) {
    riskLevel = 'MODERATE';
    riskPrimaryReasons.push('Fluktuasi harga dalam batas wajar pasar');
    riskPrimaryReasons.push(`Dekat area minat kunci ($${support.toLocaleString('en-US', { maximumFractionDigits: support < 1 ? 4 : 2 })} – $${resistance.toLocaleString('en-US', { maximumFractionDigits: resistance < 1 ? 4 : 2 })})`);
  } else {
    riskLevel = 'LOW';
    riskPrimaryReasons.push('Rentang pergerakan harga tenang dan terkendali');
    riskPrimaryReasons.push('Tidak ada akselerasi agresif dalam kurun waktu 24 jam');
  }

  // 13. Multi-Factor Summary: TRDS MARKET VIEW
  let whySummaryText = '';
  if (advancedCondition === 'BULLISH') {
    whySummaryText = `Momentum bertipe ${advancedMomentum.toLowerCase()} (+${change24h}%), volatilitas ${advancedVolatility.toLowerCase()}, dan struktur harga bertahan di atas moving average mendukung kondisi pasar bullish.`;
  } else if (advancedCondition === 'BEARISH') {
    whySummaryText = `Momentum ${advancedMomentum.toLowerCase()} (${change24h}%), volatilitas ${advancedVolatility.toLowerCase()}, dan tekanan harga di bawah moving average mendasari kondisi pasar bearish.`;
  } else if (advancedCondition === 'MIXED') {
    whySummaryText = `Momentum dan struktur tren memberikan sinyal yang berlawanan, volatilitas ${advancedVolatility.toLowerCase()}, sehingga kondisi pasar diklasifikasikan sebagai mixed.`;
  } else {
    whySummaryText = `Momentum seimbang, volatilitas ${advancedVolatility.toLowerCase()}, dan harga bergerak di dalam koridor rentang sideways tanpa arah breakout dominan.`;
  }

  const marketView: MarketViewSummary = {
    condition: advancedCondition,
    momentum: advancedMomentum,
    volatility: advancedVolatility,
    trendContext,
    marketStrength,
    riskContext: riskLevel,
    dataQuality: statusLabel,
    whyExplanation: whySummaryText
  };

  // 14. Educational Scenario Analysis (NOT predictions!)
  const scenarios: EducationalScenario[] = [
    {
      type: 'Bullish Scenario',
      title: 'Skenario Penguatan (Bullish Scenario)',
      supportingConditions: `Jika momentum beli bertahan di atas Support $${support.toLocaleString('en-US', { maximumFractionDigits: support < 1 ? 4 : 2 })} dan terjadi penembusan valid di atas Resistance $${resistance.toLocaleString('en-US', { maximumFractionDigits: resistance < 1 ? 4 : 2 })}.`,
      keyEducationalWatchpoint: 'Amati apakah volume perdagangan meningkat untuk mengonfirmasi kelanjutan dorongan harga.'
    },
    {
      type: 'Neutral Scenario',
      title: 'Skenario Konsolidasi (Neutral Scenario)',
      supportingConditions: `Jika harga terus berfluktuasi di antara Support $${support.toLocaleString('en-US', { maximumFractionDigits: support < 1 ? 4 : 2 })} dan Resistance $${resistance.toLocaleString('en-US', { maximumFractionDigits: resistance < 1 ? 4 : 2 })} dengan volume transaksi stabil.`,
      keyEducationalWatchpoint: 'Perhatikan apakah pita Bollinger Bands menyempit menandakan fase kompresi volatilitas.'
    },
    {
      type: 'Bearish Scenario',
      title: 'Skenario Pelemahan (Bearish Scenario)',
      supportingConditions: `Jika tekanan jual menembus ke bawah Support $${support.toLocaleString('en-US', { maximumFractionDigits: support < 1 ? 4 : 2 })} disertai akselerasi momentum negatif dan peningkatan volume jual.`,
      keyEducationalWatchpoint: 'Amati apakah level support sebelumnya berbalik menjadi resistance dinamis baru.'
    }
  ];

  // 15. Technical Indicators Details
  const rsiStatus = calculatedRsi >= 70
    ? 'Overbought (Jenuh Beli)'
    : calculatedRsi <= 30
    ? 'Oversold (Jenuh Jual)'
    : calculatedRsi > 55
    ? 'Moderat Positif'
    : calculatedRsi < 45
    ? 'Moderat Negatif'
    : 'Area Netral / Moderat';

  const rsiDetail: IndicatorDetail = {
    name: 'RSI (Relative Strength Index)',
    code: 'rsi',
    value: `${calculatedRsi}`,
    status: rsiStatus,
    explanation: calculatedRsi >= 70
      ? 'RSI berada di atas 70 (Overbought). Momentum beli tinggi, waspadai potensi koreksi teknikal.'
      : calculatedRsi <= 30
      ? 'RSI berada di bawah 30 (Oversold). Tekanan jual intensif, ada potensi pantulan teknikal.'
      : 'RSI berada di area keseimbangan, dinamika kekuatan pembeli dan penjual sebanding.',
    lessonId: 'lesson-rsi-momentum',
    conceptTitle: 'Relative Strength Index (RSI)',
    conceptSummary: 'RSI mengukur kecepatan dan perubahan momentum pergerakan harga dalam skala 0–100. Angka >70 berarti Overbought (jenuh beli), sedangkan <30 berarti Oversold (jenuh jual).'
  };

  const macdVal = Number(((price - sparklineAvg) * 0.4).toFixed(price < 1 ? 4 : 2));
  const macdDetail: IndicatorDetail = {
    name: 'MACD (Convergence / Divergence)',
    code: 'macd',
    value: `${macdVal >= 0 ? '+' : ''}${macdVal}`,
    status: macdVal >= 0 ? 'Histogram Positif (Bullish)' : 'Histogram Negatif (Bearish)',
    explanation: macdVal >= 0
      ? 'Garis momentum jangka pendek berada di atas garis sinyal rata-rata, mendukung struktur tren positif.'
      : 'Garis momentum jangka pendek berada di bawah garis sinyal rata-rata, mengindikasikan tekanan penurunan.',
    conceptTitle: 'MACD — Convergence & Divergence',
    conceptSummary: 'MACD membandingkan dua rata-rata pergerakan untuk mendeteksi perubahan kekuatan, arah, dan durasi tren.'
  };

  const maDetail: IndicatorDetail = {
    name: 'Moving Average (MA)',
    code: 'ma',
    value: `$${sparklineAvg.toLocaleString('en-US', { minimumFractionDigits: price < 1 ? 4 : 2, maximumFractionDigits: price < 1 ? 4 : 2 })}`,
    status: price >= sparklineAvg ? 'Harga di Atas Garis MA' : 'Harga di Bawah Garis MA',
    explanation: price >= sparklineAvg
      ? `Harga saat ini ($${price.toLocaleString('en-US')}) bertahan di atas garis rata-rata ($${sparklineAvg.toLocaleString('en-US')}), menandakan bias positif.`
      : `Harga saat ini ($${price.toLocaleString('en-US')}) berada di bawah garis rata-rata ($${sparklineAvg.toLocaleString('en-US')}), mengindikasikan resistensi dinamis.`,
    lessonId: 'lesson-moving-average',
    conceptTitle: 'Moving Average (MA) — Arah Tren',
    conceptSummary: 'Moving Average menghaluskan fluktuasi harga acak untuk mengidentifikasi tren utama.'
  };

  const variance = sparkline.reduce((acc, v) => acc + Math.pow(v - sparklineAvg, 2), 0) / sparkline.length;
  const stdDev = Math.sqrt(variance) || (price * 0.02);
  const upperBand = sparklineAvg + 2 * stdDev;
  const lowerBand = Math.max(0, sparklineAvg - 2 * stdDev);
  const bbDetail: IndicatorDetail = {
    name: 'Bollinger Bands (20, 2)',
    code: 'bb',
    value: `$${lowerBand.toFixed(price < 1 ? 3 : 0)} – $${upperBand.toFixed(price < 1 ? 3 : 0)}`,
    status: price >= upperBand * 0.98 ? 'Menguji Pita Atas' : price <= lowerBand * 1.02 ? 'Menguji Pita Bawah' : 'Di Koridor Tengah',
    explanation: price >= upperBand * 0.98
      ? 'Harga mendekati batas atas pita volatilitas, menandakan ekspansi tren atau potensi penolakan harga.'
      : price <= lowerBand * 1.02
      ? 'Harga berada di dekat batas bawah pita volatilitas, mengindikasikan area potensi pantulan support dinamis.'
      : 'Harga bergerak di koridor tengah pita Bollinger, volatilitas dalam ambang normal.',
    conceptTitle: 'Bollinger Bands — Volatilitas & Koridor Harga',
    conceptSummary: 'Bollinger Bands terdiri dari garis tengah (SMA) dan dua pita deviasi standar yang menunjukkan batas relatif volatilitas harga.'
  };

  const volumeDetail: IndicatorDetail = {
    name: 'Volume Likuiditas 24 Jam',
    code: 'volume',
    value: volumeStr,
    status: volumeContext,
    explanation: volumeContextExplanation,
    conceptTitle: 'Analisis Volume & Minat Pasar',
    conceptSummary: 'Volume mengukur jumlah unit yang diperdagangkan dalam periode tertentu. Volume tinggi memvalidasi kekuatan pergerakan harga.'
  };

  const momentumDetail: IndicatorDetail = {
    name: 'Price Momentum (24h)',
    code: 'momentum',
    value: `${change24h >= 0 ? '+' : ''}${change24h}%`,
    status: advancedMomentum,
    explanation: advancedMomentumExplanation,
    conceptTitle: 'Momentum & Rate of Change',
    conceptSummary: 'Momentum mendeskripsikan kecepatan dan arah pergerakan harga terkini.'
  };

  const indicatorsList: IndicatorDetail[] = [
    rsiDetail,
    macdDetail,
    maDetail,
    bbDetail,
    volumeDetail,
    momentumDetail
  ];

  // 16. Market Condition Score (0-100 Educational Synthesis)
  let rawScore = 50;
  if (advancedCondition === 'BULLISH') rawScore += 20;
  else if (advancedCondition === 'BEARISH') rawScore -= 20;
  else if (advancedCondition === 'MIXED') rawScore -= 4;

  if (calculatedRsi >= 45 && calculatedRsi <= 65) rawScore += 10;
  else if (calculatedRsi > 70) rawScore += 4;
  else if (calculatedRsi < 30) rawScore -= 6;

  if (priceVsAvgPercent > 0) rawScore += 5;
  else if (priceVsAvgPercent < 0) rawScore -= 5;

  if (advancedVolatility === 'MEDIUM') rawScore += 4;
  else if (advancedVolatility === 'HIGH') rawScore -= 4;
  else if (advancedVolatility === 'EXTREME') rawScore -= 8;

  const score = Math.max(12, Math.min(94, Math.round(rawScore)));

  // 17. Why Analysis factors
  const whyFactors = [
    {
      title: 'Struktur Harga & Moving Average',
      detail: price >= sparklineAvg
        ? `Harga ($${price.toLocaleString('en-US')}) bertahan di atas moving average ($${sparklineAvg.toLocaleString('en-US')}), mendukung struktur ${trendContext.toLowerCase()}.`
        : `Harga ($${price.toLocaleString('en-US')}) berada di bawah moving average ($${sparklineAvg.toLocaleString('en-US')}), menandakan resistensi pada struktur ${trendContext.toLowerCase()}.`,
      statusBadge: trendContext
    },
    {
      title: 'Momentum Perubahan 24 Jam',
      detail: advancedMomentumExplanation,
      statusBadge: advancedMomentum
    },
    {
      title: 'Fluktuasi Volatilitas',
      detail: `${volatilityExplanation} ${volatilityEducationalNote}`,
      statusBadge: `Volatilitas ${advancedVolatility}`
    },
    {
      title: 'Konteks Volume Likuiditas',
      detail: volumeContextExplanation,
      statusBadge: volumeContext
    }
  ];

  const whatHappened = advancedCondition === 'BULLISH'
    ? `Harga ${asset.symbol} bergerak dalam kondisi bullish (+${change24h}%) dengan volatilitas ${advancedVolatility.toLowerCase()} dan momentum ${advancedMomentum.toLowerCase()}. Pembeli mempertahankan level di atas Support $${support.toLocaleString('en-US')}.`
    : advancedCondition === 'BEARISH'
    ? `Harga ${asset.symbol} mengalami tekanan turun (${change24h}%) dengan volatilitas ${advancedVolatility.toLowerCase()} dan momentum ${advancedMomentum.toLowerCase()}. Penjual menekan harga mendekati Support $${support.toLocaleString('en-US')}.`
    : advancedCondition === 'MIXED'
    ? `Harga ${asset.symbol} menunjukkan sinyal yang bervariasi (${change24h >= 0 ? '+' : ''}${change24h}%) dengan momentum ${advancedMomentum.toLowerCase()} dan volatilitas ${advancedVolatility.toLowerCase()}.`
    : `Harga ${asset.symbol} berkonsolidasi menyamping (${change24h >= 0 ? '+' : ''}${change24h}%) di antara Support $${support.toLocaleString('en-US')} dan Resistance $${resistance.toLocaleString('en-US')}.`;

  const whatToLearn = `Perhatikan bagaimana indikator momentum (${advancedMomentum}), volatilitas (${advancedVolatility}), dan level Support/Resistance saling mengonfirmasi sebelum menguji strategi di simulator TRDS.`;

  return {
    assetId: asset.id,
    symbol: asset.symbol,
    price,
    change24h,
    changePercent24h,
    trend,
    trendExplanation,
    momentum: legacyMomentum,
    momentumExplanation: advancedMomentumExplanation,
    volatility: legacyVolatility,
    volatilityExplanation,
    marketStrength,
    marketStrengthPercent,
    score,
    support,
    resistance,
    supportExplanation,
    resistanceExplanation,
    hasInsufficientSupportResistance,
    volume: volumeStr,
    volumeEvaluation: volumeContextExplanation,
    indicators: indicatorsList,
    rsi: rsiDetail,
    macd: macdDetail,
    ma: maDetail,
    bollingerBands: bbDetail,
    volumeIndicator: volumeDetail,
    priceMomentum: momentumDetail,
    whyAnalysis: {
      overview: whySummaryText,
      factors: whyFactors,
      dataAvailability: 'real_simulated'
    },
    marketSummary: {
      whatHappened,
      whatToLearn
    },
    riskContext: {
      volatilityNote: `${volatilityExplanation} ${volatilityEducationalNote}`,
      uncertaintyNote: 'Confidence reflects the quality and consistency of the available market data, not a guarantee of future price direction.',
      trendStabilityNote: `Konteks tren saat ini: ${trendContext}. Pergerakan historis tidak menjamin hasil masa depan.`,
      riskFactors: riskPrimaryReasons
    },
    lastUpdated,
    isSimulatedData: quoteStatus !== 'LIVE',
    dataStatus: quoteStatus,
    dataSource: quoteSource,
    timestamp,
    isStale,

    // Advanced Multi-Factor Additions
    advancedCondition,
    conditionReasons,
    advancedMomentum,
    advancedMomentumExplanation,
    advancedVolatility,
    volatilityEducationalNote,
    trendContext,
    trendContextExplanation,
    marketStrengthCategory,
    orderBookPressureAvailable,
    orderBookPressureNote,
    volumeContext,
    volumeContextExplanation,
    dataQuality,
    analysisConfidence,
    analysisConfidenceExplanation,
    riskLevel,
    riskPrimaryReasons,
    marketView,
    scenarios
  };
}
