/**
 * TRDS Live Market Data Provider (Future Provider Integration Point)
 *
 * Designed to connect to an approved real-market-data provider (e.g. via secure server proxy)
 * when configured with valid environment secrets.
 *
 * Strict Compliance Notice:
 * - No fake live data or simulated numbers with a "LIVE" label are ever produced.
 * - If no live provider backend/credentials are configured, this provider reports unavailable,
 *   prompting the MarketDataService to safely fall back to DATA SIMULASI.
 */

import { MarketDataProvider, MarketQuote } from '../../types/marketData';

export interface LiveProviderConfig {
  apiKey?: string;
  apiBaseUrl?: string;
  proxyEndpoint?: string;
}

export class LiveMarketDataProvider implements MarketDataProvider {
  readonly id = 'live_provider';
  readonly name = 'TRDS Live Provider';
  readonly isLive = true;

  private config: LiveProviderConfig;

  constructor(config: LiveProviderConfig = {}) {
    this.config = config;
  }

  /**
   * Evaluates whether a valid live provider configuration is active.
   */
  async isAvailable(): Promise<boolean> {
    // Currently no real provider credentials or server proxy endpoint are configured.
    // In accordance with product rules, we strictly return false rather than fabricating responses.
    if (!this.config.apiKey && !this.config.proxyEndpoint) {
      return false;
    }
    return false;
  }

  async getQuote(symbol: string): Promise<MarketQuote> {
    const available = await this.isAvailable();
    if (!available) {
      throw new Error(
        `Live market data provider is not configured. Instrument "${symbol}" cannot be fetched in live mode. Fallback to DATA SIMULASI is required.`
      );
    }

    throw new Error('Live provider connection not initialized.');
  }

  async getQuotes(symbols: string[]): Promise<Record<string, MarketQuote>> {
    const available = await this.isAvailable();
    if (!available) {
      throw new Error(
        `Live market data provider is not configured for symbols: ${symbols.join(', ')}.`
      );
    }

    return {};
  }
}
