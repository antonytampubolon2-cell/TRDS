/**
 * TRDS Simulation Market Data Provider
 *
 * Provides simulated market quotes based on the established educational demo dataset.
 * Always explicitly labelled as DATA SIMULASI.
 * Never claims to be live market data.
 */

import { MarketDataProvider, MarketQuote } from '../../types/marketData';
import { MOCK_ASSETS } from '../../data/mockData';
import { normalizeInstrumentSymbol } from '../../utils/formatters';

export class SimulationMarketDataProvider implements MarketDataProvider {
  readonly id = 'simulation';
  readonly name = 'TRDS Simulation Provider';
  readonly isLive = false;

  private simQuotes: Map<string, MarketQuote> = new Map();

  constructor() {
    this.refreshFromMockAssets();
  }

  /**
   * Builds normalized MarketQuotes from the existing MOCK_ASSETS collection.
   */
  private refreshFromMockAssets(): void {
    const now = Date.now();
    for (const asset of MOCK_ASSETS) {
      const normalizedSymbol = normalizeInstrumentSymbol(asset.symbol);
      const quote: MarketQuote = {
        id: asset.id,
        symbol: normalizedSymbol,
        rawSymbol: asset.symbol,
        name: asset.name,
        assetType: asset.category,
        price: asset.price,
        change24h: asset.change24h,
        changePercent24h: asset.change24h / 100,
        high24h: asset.high24h,
        low24h: asset.low24h,
        volume: asset.volume,
        sparkline: asset.sparkline,
        timestamp: now,
        dataStatus: 'SIMULATED',
        source: 'simulation',
        isStale: false
      };
      this.simQuotes.set(asset.id.toLowerCase(), quote);
      this.simQuotes.set(normalizedSymbol.toUpperCase(), quote);
    }
  }

  async getQuote(symbolOrId: string): Promise<MarketQuote> {
    if (!symbolOrId) {
      throw new Error('Symbol or Asset ID cannot be empty');
    }

    const key = symbolOrId.trim();
    const normalized = normalizeInstrumentSymbol(key).toUpperCase();

    // Check by exact normalized symbol or by lowercase ID
    let found = this.simQuotes.get(normalized) || this.simQuotes.get(key.toLowerCase());

    if (!found) {
      // Search in MOCK_ASSETS by id or symbol
      const asset = MOCK_ASSETS.find(
        a =>
          a.id.toLowerCase() === key.toLowerCase() ||
          normalizeInstrumentSymbol(a.symbol).toUpperCase() === normalized ||
          a.symbol.toUpperCase() === key.toUpperCase()
      );

      if (asset) {
        found = {
          id: asset.id,
          symbol: normalizeInstrumentSymbol(asset.symbol),
          rawSymbol: asset.symbol,
          name: asset.name,
          assetType: asset.category,
          price: asset.price,
          change24h: asset.change24h,
          changePercent24h: asset.change24h / 100,
          high24h: asset.high24h,
          low24h: asset.low24h,
          volume: asset.volume,
          sparkline: asset.sparkline,
          timestamp: Date.now(),
          dataStatus: 'SIMULATED',
          source: 'simulation',
          isStale: false
        };
        this.simQuotes.set(normalized, found);
      }
    }

    if (!found) {
      throw new Error(`Simulated instrument not found for identifier: ${symbolOrId}`);
    }

    // Return a fresh clone with updated timestamp to reflect fetch time
    return {
      ...found,
      timestamp: Date.now()
    };
  }

  async getQuotes(symbols: string[]): Promise<Record<string, MarketQuote>> {
    const results: Record<string, MarketQuote> = {};
    for (const s of symbols) {
      try {
        const q = await this.getQuote(s);
        results[q.symbol] = q;
        results[q.id] = q;
      } catch {
        // Handled upstream by validation/service layer
      }
    }
    return results;
  }

  async isAvailable(): Promise<boolean> {
    return true;
  }
}
