/**
 * TRDS MarketDataService
 *
 * Centralized service layer coordinating:
 * - Provider selection (Simulation by default, Live when configured)
 * - Data fetching & controlled refresh
 * - Normalization & centralized symbol formatting
 * - Rigorous data validation (preventing fabricated or malformed quotes)
 * - Status assignment (LIVE, SIMULATED, UPDATING, UNAVAILABLE, STALE)
 * - Safe TTL in-memory caching
 * - Stale-data detection
 * - Graceful error handling
 */

import { MarketDataProvider, MarketQuote, MarketDataStatus, MarketDataServiceConfig } from '../types/marketData';
import { SimulationMarketDataProvider } from './marketData/simulationProvider';
import { LiveMarketDataProvider } from './marketData/liveProvider';
import { validateMarketQuote, createUnavailableQuote } from './marketDataValidation';
import { normalizeInstrumentSymbol } from '../utils/formatters';

interface CachedQuoteEntry {
  quote: MarketQuote;
  cachedAt: number;
}

export class MarketDataService {
  private activeProvider: MarketDataProvider;
  private simulationProvider: SimulationMarketDataProvider;
  private liveProvider: LiveMarketDataProvider;

  private quoteCache: Map<string, CachedQuoteEntry> = new Map();
  private inFlightRequests: Map<string, Promise<MarketQuote>> = new Map();
  private testOverrides: Map<string, MarketDataStatus> = new Map();

  // Configurable thresholds
  private config: MarketDataServiceConfig = {
    staleThresholdMs: 5 * 60 * 1000, // 5 minutes: data older than this is STALE
    cacheTtlMs: 15 * 1000             // 15 seconds: cached quote is fresh
  };

  constructor(config?: Partial<MarketDataServiceConfig>) {
    if (config) {
      this.config = { ...this.config, ...config };
    }

    this.simulationProvider = new SimulationMarketDataProvider();
    this.liveProvider = new LiveMarketDataProvider();

    // Default to Simulation Provider because no verified live provider credentials exist
    this.activeProvider = this.simulationProvider;
  }

  /**
   * Sets the active provider (e.g. to switch to a verified live provider in the future).
   */
  setActiveProvider(provider: MarketDataProvider): void {
    this.activeProvider = provider;
    // Clear cache upon provider switch to prevent mixing sources
    this.quoteCache.clear();
    this.inFlightRequests.clear();
  }

  /**
   * Returns the currently active market data provider.
   */
  getActiveProvider(): MarketDataProvider {
    return this.activeProvider;
  }

  /**
   * Indicates whether the service is currently running in live market data mode.
   */
  isLiveMode(): boolean {
    return this.activeProvider.isLive;
  }

  /**
   * Adjusts the stale threshold for testing or environment configuration.
   */
  setStaleThreshold(ms: number): void {
    this.config.staleThresholdMs = ms;
  }

  /**
   * For testing & verification: forces a symbol or all symbols into STALE state.
   */
  simulateStaleStateForTesting(symbol?: string): void {
    if (symbol) {
      this.testOverrides.set(normalizeInstrumentSymbol(symbol).toUpperCase(), 'STALE');
    } else {
      this.testOverrides.set('*', 'STALE');
    }
    this.quoteCache.clear();
  }

  /**
   * For testing & verification: forces a symbol or all symbols into UNAVAILABLE state.
   */
  simulateUnavailableStateForTesting(symbol?: string): void {
    if (symbol) {
      this.testOverrides.set(normalizeInstrumentSymbol(symbol).toUpperCase(), 'UNAVAILABLE');
    } else {
      this.testOverrides.set('*', 'UNAVAILABLE');
    }
    this.quoteCache.clear();
  }

  /**
   * Resets any test overrides and restores standard provider resolution.
   */
  resetTestingOverrides(): void {
    this.testOverrides.clear();
    this.quoteCache.clear();
  }

  /**
   * Fetches a single normalized MarketQuote for an instrument.
   * Prevents duplicate in-flight requests and respects cache TTL.
   *
   * @param symbolOrId The instrument symbol (e.g. "BTC/USD") or asset ID (e.g. "btc").
   * @param options.forceRefresh If true, bypasses the fresh cache check.
   */
  async getQuote(
    symbolOrId: string,
    options: { forceRefresh?: boolean } = {}
  ): Promise<MarketQuote> {
    if (!symbolOrId) {
      return createUnavailableQuote('unknown', 'N/A', 'Unknown', 'Simbol instrumen tidak boleh kosong.');
    }

    const normalizedSymbol = normalizeInstrumentSymbol(symbolOrId);
    const cacheKey = normalizedSymbol.toUpperCase();
    const now = Date.now();

    // Check test overrides
    const overrideStatus = this.testOverrides.get(cacheKey) || this.testOverrides.get('*');
    if (overrideStatus === 'UNAVAILABLE') {
      return createUnavailableQuote(symbolOrId, normalizedSymbol, 'Aset Terpilih', 'Umpan data pasar disimulasikan sebagai UNAVAILABLE untuk pengujian.');
    }

    const cached = this.quoteCache.get(cacheKey);

    // 1. Return fresh cached quote if available and forceRefresh is false
    if (cached && !options.forceRefresh) {
      const age = now - cached.cachedAt;
      if (age < this.config.cacheTtlMs) {
        let evaluated = this.evaluateStaleness(cached.quote);
        if (overrideStatus === 'STALE') {
          evaluated = { ...evaluated, isStale: true, dataStatus: 'STALE' };
        }
        return evaluated;
      }
    }

    // Deduplicate in-flight requests for the same instrument
    const inFlightKey = `${cacheKey}_${Boolean(options.forceRefresh)}`;
    if (this.inFlightRequests.has(inFlightKey)) {
      return this.inFlightRequests.get(inFlightKey)!;
    }

    const fetchPromise = this.fetchAndProcessQuote(symbolOrId, normalizedSymbol, cacheKey, cached, overrideStatus);
    this.inFlightRequests.set(inFlightKey, fetchPromise);

    try {
      const result = await fetchPromise;
      return result;
    } finally {
      this.inFlightRequests.delete(inFlightKey);
    }
  }

  private async fetchAndProcessQuote(
    symbolOrId: string,
    normalizedSymbol: string,
    cacheKey: string,
    cached: CachedQuoteEntry | undefined,
    overrideStatus?: MarketDataStatus
  ): Promise<MarketQuote> {
    const now = Date.now();

    // 2. Fetch from active provider
    try {
      let rawQuote: MarketQuote;

      try {
        rawQuote = await this.activeProvider.getQuote(symbolOrId);
      } catch (err: unknown) {
        // If active provider is live and fails, attempt fallback to simulation provider
        if (this.activeProvider.isLive) {
          rawQuote = await this.simulationProvider.getQuote(symbolOrId);
        } else {
          throw err;
        }
      }

      // 3. Centralized Normalization
      const normalizedQuote: MarketQuote = {
        ...rawQuote,
        symbol: normalizeInstrumentSymbol(rawQuote.symbol),
        timestamp: rawQuote.timestamp || now
      };

      // 4. Strict Data Validation
      const validation = validateMarketQuote(normalizedQuote);
      if (!validation.isValid) {
        // Validation failed: do NOT fabricate live data!
        const unavailableQuote = createUnavailableQuote(
          normalizedQuote.id || symbolOrId,
          normalizedQuote.symbol || normalizedSymbol,
          normalizedQuote.name,
          validation.error || 'Data pasar tidak lolos validasi.'
        );
        return unavailableQuote;
      }

      // 5. Data Status Assignment & Staleness Check
      let finalQuote = this.evaluateStaleness(normalizedQuote);

      if (overrideStatus === 'STALE') {
        finalQuote = { ...finalQuote, isStale: true, dataStatus: 'STALE' };
      }

      // 6. Update cache
      this.quoteCache.set(cacheKey, {
        quote: finalQuote,
        cachedAt: now
      });

      return finalQuote;
    } catch (err: unknown) {
      // 7. Error Handling: if a cached quote exists, return it marked as STALE
      if (cached) {
        const staleQuote: MarketQuote = {
          ...cached.quote,
          isStale: true,
          dataStatus: 'STALE',
          errorMessage: 'Gagal memperbarui data terbaru. Menampilkan data tersimpan terakhir.'
        };
        return staleQuote;
      }

      // No cached data: return DATA_UNAVAILABLE without fabricating values
      const errorMsg = err instanceof Error ? err.message : 'Koneksi ke data feed pasar terputus.';
      return createUnavailableQuote(symbolOrId, normalizedSymbol, 'Aset Terpilih', errorMsg);
    }
  }

  /**
   * Fetches multiple quotes in batch concurrently.
   */
  async getQuotes(
    symbols: string[],
    options: { forceRefresh?: boolean } = {}
  ): Promise<Record<string, MarketQuote>> {
    const quotes = await Promise.all(symbols.map(sym => this.getQuote(sym, options)));
    const results: Record<string, MarketQuote> = {};
    for (const quote of quotes) {
      results[quote.symbol] = quote;
      results[quote.id] = quote;
    }
    return results;
  }

  /**
   * Evaluates the timestamp of a quote and sets isStale and dataStatus appropriately.
   */
  private evaluateStaleness(quote: MarketQuote): MarketQuote {
    const now = Date.now();
    const age = now - quote.timestamp;

    if (age > this.config.staleThresholdMs) {
      return {
        ...quote,
        isStale: true,
        dataStatus: 'STALE'
      };
    }

    // Assign appropriate active status
    const dataStatus: MarketDataStatus = this.activeProvider.isLive ? 'LIVE' : 'SIMULATED';

    return {
      ...quote,
      isStale: false,
      dataStatus
    };
  }

  /**
   * Clears in-memory quote cache.
   */
  clearCache(): void {
    this.quoteCache.clear();
  }
}

// Export singleton instance
export const marketDataService = new MarketDataService();
