/**
 * TRDS Market Data Validation Engine
 *
 * Strict validation rules:
 * - symbol exists
 * - price is numeric and > 0
 * - timestamp exists and is valid
 * - source is known
 * - required fields exist
 *
 * Invalid data must NOT be presented as live market data.
 * If validation fails, status is marked as DATA_UNAVAILABLE without fabricating values.
 */

import { MarketQuote, MarketDataValidationResult } from '../types/marketData';

export function validateMarketQuote(data: unknown): MarketDataValidationResult {
  if (!data || typeof data !== 'object') {
    return {
      isValid: false,
      error: 'Data payload is null or not an object.'
    };
  }

  const quote = data as Partial<MarketQuote>;
  const missing: string[] = [];

  if (!quote.id || typeof quote.id !== 'string') {
    missing.push('id');
  }

  if (!quote.symbol || typeof quote.symbol !== 'string' || quote.symbol.trim().length === 0) {
    missing.push('symbol');
  }

  if (typeof quote.price !== 'number' || isNaN(quote.price) || !isFinite(quote.price)) {
    missing.push('price (must be finite numeric)');
  } else if (quote.price <= 0) {
    return {
      isValid: false,
      error: `Invalid market price (${quote.price}). Price must be greater than zero.`
    };
  }

  if (
    typeof quote.timestamp !== 'number' ||
    isNaN(quote.timestamp) ||
    quote.timestamp <= 0
  ) {
    missing.push('timestamp (must be valid positive epoch)');
  }

  if (!quote.source || typeof quote.source !== 'string' || quote.source.trim().length === 0) {
    missing.push('source');
  }

  const validStatuses = ['LIVE', 'SIMULATED', 'UPDATING', 'UNAVAILABLE', 'STALE'];
  if (quote.dataStatus && !validStatuses.includes(quote.dataStatus)) {
    missing.push('dataStatus (must be LIVE | SIMULATED | UPDATING | UNAVAILABLE | STALE)');
  }

  if (missing.length > 0) {
    return {
      isValid: false,
      error: `Missing or malformed required market data fields: ${missing.join(', ')}`,
      missingFields: missing
    };
  }

  return { isValid: true };
}

/**
 * Creates a safe fallback MarketQuote with DATA_UNAVAILABLE status.
 * Never fabricates numbers or presents fake prices.
 */
export function createUnavailableQuote(
  id: string,
  symbol: string,
  name = 'Unknown Asset',
  errorMessage = 'Data pasar sementara tidak tersedia.'
): MarketQuote {
  return {
    id,
    symbol,
    name,
    assetType: 'crypto',
    price: 0,
    change24h: 0,
    changePercent24h: 0,
    timestamp: Date.now(),
    dataStatus: 'UNAVAILABLE',
    source: 'unknown',
    isStale: true,
    errorMessage
  };
}
