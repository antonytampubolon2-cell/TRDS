import React from 'react';
import { Crown, Sparkles, ChevronRight, Check } from 'lucide-react';
import { PremiumBadge } from './PremiumBadge';

interface PremiumCardProps {
  isPremium: boolean;
  onOpenPremium: () => void;
  className?: string;
}

export const PremiumCard: React.FC<PremiumCardProps> = ({
  isPremium,
  onOpenPremium,
  className = ''
}) => {
  if (isPremium) {
    return (
      <div
        id="premium-active-card"
        onClick={onOpenPremium}
        className={`p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 hover:border-amber-500/50 cursor-pointer transition shadow-lg relative overflow-hidden group ${className}`}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0 group-hover:scale-105 transition-transform">
              <Crown className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-white">TRDS Premium</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
                  Aktif
                </span>
              </div>
              <p className="text-xs text-slate-300 truncate mt-0.5">
                Semua materi lanjutan & analitik simulator terbuka.
              </p>
            </div>
          </div>
          <div className="p-2 rounded-xl bg-slate-800 text-slate-400 group-hover:text-white transition shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      id="premium-promo-card"
      onClick={onOpenPremium}
      className={`p-4 rounded-2xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-slate-900 border border-amber-500/30 hover:border-amber-500/50 cursor-pointer transition shadow-lg relative overflow-hidden group ${className}`}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-slate-950 shadow-md shadow-amber-500/20 shrink-0 group-hover:scale-105 transition-transform">
            <Crown className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-white">Explore TRDS Premium</span>
              <PremiumBadge size="sm" />
            </div>
            <p className="text-xs text-slate-300 truncate mt-0.5">
              Buka kurikulum pro, kuis evaluasi komprehensif, & AI Deep Dive.
            </p>
          </div>
        </div>
        <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400 group-hover:bg-amber-500/25 transition shrink-0">
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
};
