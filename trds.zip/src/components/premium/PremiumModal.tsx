import React, { useState } from 'react';
import {
  X,
  Crown,
  Sparkles,
  Check,
  ShieldCheck,
  RotateCw,
  AlertCircle,
  HelpCircle,
  BookOpen,
  SlidersHorizontal,
  Bot,
  Award,
  Zap,
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PremiumBadge } from './PremiumBadge';
import { DEFAULT_TRDS_OFFERING } from '../../services/revenueCatService';
import { RevenueCatPackage } from '../../types/revenueCat';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  contextFeatureName?: string;
}

export const PremiumModal: React.FC<PremiumModalProps> = ({
  isOpen,
  onClose,
  contextFeatureName
}) => {
  const {
    isPremium,
    customerInfo,
    activePackageId,
    purchasePackage,
    restorePurchases,
    toggleDevelopmentEntitlement,
    isRevenueCatConfigured
  } = useApp();

  const [selectedPackageId, setSelectedPackageId] = useState<string>('$rc_annual');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  if (!isOpen) return null;

  const packages = DEFAULT_TRDS_OFFERING.availablePackages;

  const handlePurchase = async () => {
    setIsProcessing(true);
    setFeedbackMessage(null);

    const result = await purchasePackage(selectedPackageId);
    setIsProcessing(false);

    if (result.success) {
      setFeedbackMessage({
        type: 'success',
        text: 'Selamat! Hak akses TRDS Premium ("trds_premium") telah aktif. Semua fitur pro telah terbuka.'
      });
    } else {
      setFeedbackMessage({
        type: 'error',
        text: result.error?.userMessage || 'Gagal memproses langganan. Silakan coba kembali.'
      });
    }
  };

  const handleRestore = async () => {
    setIsProcessing(true);
    setFeedbackMessage(null);

    const result = await restorePurchases();
    setIsProcessing(false);

    if (result.restored) {
      setFeedbackMessage({
        type: 'success',
        text: 'Hak akses langganan berhasil dipulihkan via RevenueCat. TRDS Premium kini aktif.'
      });
    } else {
      setFeedbackMessage({
        type: 'info',
        text: result.error?.userMessage || 'Tidak ada pembelian langganan aktif yang ditemukan pada akun ini.'
      });
    }
  };

  return (
    <div
      id="trds-premium-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto animate-in fade-in duration-200"
    >
      <div
        id="trds-premium-modal-container"
        className="w-full max-w-md max-h-[92vh] bg-slate-900 border border-amber-500/30 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl relative"
      >
        {/* Top Header Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PremiumBadge size="md" />
            <span className="text-xs text-slate-400 font-mono">Entitlement: trds_premium</span>
          </div>
          <button
            type="button"
            id="close-premium-modal-btn"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Feature Lock Teaser (if opened from a specific locked feature) */}
        {contextFeatureName && !isPremium && (
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2.5 text-xs text-amber-300">
            <Sparkles className="w-4 h-4 shrink-0" />
            <span>
              Buka akses fitur <strong>"{contextFeatureName}"</strong> dengan meningkatkan ke TRDS Premium.
            </span>
          </div>
        )}

        {/* Header Hero Banner */}
        <div className="text-center space-y-1.5 pt-1">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 mx-auto flex items-center justify-center text-slate-950 shadow-xl shadow-amber-500/20">
            <Crown className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">TRDS Premium</h2>
          <p className="text-xs text-slate-300 max-w-xs mx-auto leading-relaxed">
            Kurikulum materi pro, analitik mendalam simulasi pasar, dan asisten AI tutor tanpa batas.
          </p>
        </div>

        {/* Current Entitlement Status Card */}
        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 block">Status Hak Akses Anda</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-xs font-bold text-white">
                {isPremium ? 'TRDS Premium Aktif' : 'TRDS Free (Akses Dasar)'}
              </span>
              <span
                className={`w-2 h-2 rounded-full ${
                  isPremium ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
                }`}
              />
            </div>
          </div>
          {isPremium ? (
            <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Hak Akses Aktif
            </span>
          ) : (
            <span className="text-[10px] font-semibold px-2 py-1 rounded-lg bg-slate-800 text-slate-400">
              Gratis
            </span>
          )}
        </div>

        {/* Free vs Premium Comparison Table */}
        <div className="space-y-2">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Perbandingan Hak Akses
          </span>

          <div className="rounded-2xl border border-slate-800 overflow-hidden text-xs bg-slate-950/50 divide-y divide-slate-800/80">
            <div className="grid grid-cols-3 p-2.5 bg-slate-900/90 text-[11px] font-bold text-slate-400">
              <span>Fitur Platform</span>
              <span className="text-center text-slate-400">Free</span>
              <span className="text-center text-amber-400 font-extrabold">TRDS Premium</span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-slate-300 text-[11px]">Kurikulum Akademi</span>
              <span className="text-center text-slate-400 text-[11px]">Modul Dasar</span>
              <span className="text-center text-amber-300 font-semibold text-[11px]">Semua + Modul Lanjutan</span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-slate-300 text-[11px]">Kuis & Evaluasi</span>
              <span className="text-center text-slate-400 text-[11px]">Kuis Standar</span>
              <span className="text-center text-amber-300 font-semibold text-[11px]">Kuis Standar & Pro Mastery</span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-slate-300 text-[11px]">Simulator Pasar</span>
              <span className="text-center text-slate-400 text-[11px]">Simulasi Pasar Penuh</span>
              <span className="text-center text-amber-300 font-semibold text-[11px]">Simulasi + Analitik Sharpe & Drawdown</span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-slate-300 text-[11px]">TRDS AI Tutor</span>
              <span className="text-center text-slate-400 text-[11px]">Tanya Jawab Dasar</span>
              <span className="text-center text-amber-300 font-semibold text-[11px]">Deep-Dive Portfolio & Evaluasi Risiko</span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-slate-300 text-[11px]">Pencapaian & Badge</span>
              <span className="text-center text-slate-400 text-[11px]">Badge Standar</span>
              <span className="text-center text-amber-300 font-semibold text-[11px]">Koleksi Pro Scholar & Risk Master</span>
            </div>
          </div>
        </div>

        {/* Offering Packages Selector */}
        {!isPremium && (
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Pilihan Paket Langganan
            </span>

            <div className="space-y-2">
              {packages.map(pkg => {
                const isSelected = selectedPackageId === pkg.identifier;
                return (
                  <div
                    key={pkg.identifier}
                    onClick={() => setSelectedPackageId(pkg.identifier)}
                    className={`p-3 rounded-2xl border transition cursor-pointer relative ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-400 shadow-md shadow-amber-500/10'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {pkg.badgeText && (
                      <span className="absolute -top-2 right-3 px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow">
                        {pkg.badgeText}
                      </span>
                    )}

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                            isSelected
                              ? 'border-amber-400 bg-amber-400 text-slate-950'
                              : 'border-slate-600'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <div>
                          <div className="font-bold text-xs text-white">{pkg.product.title}</div>
                          <div className="text-[10px] text-slate-400">{pkg.product.description}</div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="font-bold text-sm text-amber-400 font-mono">
                          {pkg.product.priceString}
                        </span>
                        {pkg.product.introductoryPrice && (
                          <span className="text-[9px] text-emerald-400 block font-semibold">
                            {pkg.product.introductoryPrice.priceString}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Feedback Alert Box */}
        {feedbackMessage && (
          <div
            className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
              feedbackMessage.type === 'success'
                ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                : feedbackMessage.type === 'error'
                ? 'bg-red-500/15 border-red-500/30 text-red-300'
                : 'bg-blue-500/15 border-blue-500/30 text-blue-300'
            }`}
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <p className="leading-relaxed">{feedbackMessage.text}</p>
          </div>
        )}

        {/* Primary Action Buttons */}
        <div className="space-y-2 pt-1">
          {!isPremium ? (
            <button
              type="button"
              id="upgrade-premium-btn"
              disabled={isProcessing}
              onClick={handlePurchase}
              className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/25 transition active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Crown className="w-4 h-4" />
              <span>{isProcessing ? 'Memproses ke Store...' : 'Mulai Akses TRDS Premium'}</span>
            </button>
          ) : (
            <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-center">
              <span className="text-xs font-bold text-emerald-300 block">
                Hak Akses Langganan Anda Telah Aktif
              </span>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Paket: {packages.find(p => p.identifier === activePackageId)?.product.title || 'TRDS Premium'}
              </span>
            </div>
          )}

          <div className="flex gap-2">
            <button
              type="button"
              id="restore-purchases-btn"
              disabled={isProcessing}
              onClick={handleRestore}
              className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
              <span>Pulihkan Pembelian (Restore)</span>
            </button>
          </div>
        </div>

        {/* RevenueCat & Sandbox Status Disclosure */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-[11px] text-slate-400">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 font-bold text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Integrasi RevenueCat</span>
            </div>
            <span
              className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${
                isRevenueCatConfigured
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-amber-500/20 text-amber-300'
              }`}
            >
              {isRevenueCatConfigured ? 'SDK Configured' : 'Dev Sandbox'}
            </span>
          </div>

          <p className="text-[10px] leading-relaxed">
            {isRevenueCatConfigured
              ? 'Terhubung dengan RevenueCat SDK. Transaksi diproses melalui App Store / Google Play In-App Purchases yang sah.'
              : 'RevenueCat product configuration is still required in App Store / Google Play / RevenueCat dashboard. Aplikasi beroperasi dalam mode Sandbox / Development untuk pengujian fungsionalitas.'}
          </p>

          {/* Development Testing Toggle */}
          <div className="pt-1 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-[10px] text-slate-400 font-semibold">
              Mode Uji Coba UI (Testing Toggle):
            </span>
            <button
              type="button"
              id="dev-test-entitlement-toggle"
              onClick={() => {
                const newStatus = !isPremium;
                toggleDevelopmentEntitlement(newStatus);
                setFeedbackMessage({
                  type: 'info',
                  text: newStatus
                    ? 'Mode Uji: Hak akses "trds_premium" disimulasikan AKTIF.'
                    : 'Mode Uji: Hak akses "trds_premium" dinonaktifkan (FREE USER).'
                });
              }}
              className="text-[10px] px-2 py-0.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 font-bold transition"
            >
              {isPremium ? 'Switch to Free User' : 'Simulate Premium Active'}
            </button>
          </div>
        </div>

        {/* Legal & Non-Custodian Disclaimers */}
        <div className="text-[10px] text-slate-500 text-center space-y-1 pt-1">
          <p>
            TRDS adalah platform simulasi edukatif. Langganan membuka konten edukasi & analitik virtual. Tidak menyediakan layanan finansial atau bursa nyata.
          </p>
          <div className="flex justify-center gap-3 text-slate-400">
            <span className="hover:underline cursor-pointer">Syarat & Ketentuan</span>
            <span>•</span>
            <span className="hover:underline cursor-pointer">Kebijakan Privasi</span>
            <span>•</span>
            <span className="hover:underline cursor-pointer">RevenueCat Terms</span>
          </div>
        </div>
      </div>
    </div>
  );
};
