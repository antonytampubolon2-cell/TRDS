import React from 'react';
import { Crown, Sparkles, ArrowRight } from 'lucide-react';

interface UpgradeButtonProps {
  onClick: () => void;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'primary' | 'subtle' | 'outline';
  fullWidth?: boolean;
  className?: string;
}

export const UpgradeButton: React.FC<UpgradeButtonProps> = ({
  onClick,
  label = 'Upgrade ke TRDS Premium',
  size = 'md',
  variant = 'primary',
  fullWidth = false,
  className = ''
}) => {
  const sizeClasses = {
    sm: 'py-1.5 px-3 text-xs gap-1.5 rounded-xl',
    md: 'py-2.5 px-4 text-xs font-bold gap-2 rounded-xl',
    lg: 'py-3.5 px-5 text-sm font-bold gap-2.5 rounded-2xl'
  };

  const variantClasses = {
    primary:
      'bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold shadow-lg shadow-amber-500/20 active:scale-[0.99] border border-amber-300/40',
    subtle:
      'bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 font-semibold',
    outline:
      'bg-transparent hover:bg-slate-800 border border-slate-700 text-slate-200 font-medium'
  };

  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center justify-center transition-all ${sizeClasses[size]} ${variantClasses[variant]} ${
        fullWidth ? 'w-full' : ''
      } ${className}`}
    >
      <Crown className={size === 'sm' ? 'w-3.5 h-3.5 text-slate-950' : 'w-4 h-4 text-slate-950'} />
      <span className="whitespace-nowrap">{label}</span>
      <ArrowRight className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
    </button>
  );
};
