import React from 'react';
import { Crown, Sparkles, ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { PremiumBadge } from './PremiumBadge';
import { CustomerEntitlement } from '../../types/revenueCat';

interface PremiumStatusCardProps {
  isPremium: boolean;
  entitlement: CustomerEntitlement | null;
  activePackageId: string | null;
  onOpenPremium: () => void;
  className?: string;
}

export const PremiumStatusCard: React.FC<PremiumStatusCardProps> = ({
  isPremium,
  entitlement,
  activePackageId,
  onOpenPremium,
  className = ''
}) => {
  if (isPremium) {
    return (
      <div
        id="profile-premium-status-card"
        className={`p-4 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/40 space-y-3 shadow-xl ${className}`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-white">TRDS Premium</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  Premium Active
                </span>
              </div>
              <span className="text-[11px] text-slate-400 block font-mono">
                Entitlement: trds_premium
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenPremium}
            className="px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition flex items-center gap-1"
          >
            <span>Detail Akses</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-300 space-y-1">
          <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Semua Hak Akses Edukasi Pro Terbuka Penuh</span>
          </div>
          <p className="text-slate-400 text-[10px] leading-relaxed">
            Modul materi lanjutan, kuis evaluasi pro, analitik simulator Sharpe/Drawdown, serta deep dive AI tutor dapat diakses tanpa batasan.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      id="profile-premium-status-card"
      className={`p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 space-y-3 shadow-lg ${className}`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400">
            <Crown className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-white">TRDS Free</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-400 font-semibold border border-slate-700">
                Akses Dasar
              </span>
            </div>
            <span className="text-[11px] text-slate-400 block">
              Akademi & Simulator Dasar Aktif
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenPremium}
          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-bold shadow-md shadow-amber-500/20 transition flex items-center gap-1.5"
        >
          <Crown className="w-3.5 h-3.5" />
          <span>Upgrade to Premium</span>
        </button>
      </div>

      <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/80">
        <span>Tersedia kurikulum lanjutan & analitik pro</span>
        <button
          type="button"
          onClick={onOpenPremium}
          className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
        >
          <span>Pelajari Lebih Lanjut</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
