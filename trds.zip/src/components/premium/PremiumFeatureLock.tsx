import React from 'react';
import { Lock, Crown, Sparkles, ArrowRight } from 'lucide-react';
import { PremiumBadge } from './PremiumBadge';

interface PremiumFeatureLockProps {
  title?: string;
  description?: string;
  featureName?: string;
  onUnlock: () => void;
  compact?: boolean;
  className?: string;
}

export const PremiumFeatureLock: React.FC<PremiumFeatureLockProps> = ({
  title = 'Fitur Eksklusif TRDS Premium',
  description = 'Buka akses metrik analisis lanjutan, kurikulum pro, dan eksplorasi mendalam tanpa batas.',
  featureName,
  onUnlock,
  compact = false,
  className = ''
}) => {
  if (compact) {
    return (
      <div
        className={`p-3 rounded-xl bg-slate-900/90 border border-amber-500/25 flex items-center justify-between gap-3 ${className}`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <Lock className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white truncate">{featureName || title}</span>
              <PremiumBadge size="sm" />
            </div>
            <p className="text-[10px] text-slate-400 truncate">{description}</p>
          </div>
        </div>

        <button
          type="button"
          onClick={onUnlock}
          className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-[11px] font-bold transition flex items-center gap-1 shrink-0"
        >
          <span>Buka</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    );
  }

  return (
    <div
      className={`p-5 rounded-2xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-amber-500/30 relative overflow-hidden shadow-xl text-center space-y-3.5 ${className}`}
    >
      {/* Subtle top amber glow accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-1 bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />

      <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 mx-auto flex items-center justify-center text-amber-400 shadow-md shadow-amber-500/10">
        <Lock className="w-5 h-5" />
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-center gap-1.5">
          <h3 className="text-sm font-bold text-white">{title}</h3>
          <PremiumBadge size="sm" />
        </div>
        <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">{description}</p>
      </div>

      <button
        type="button"
        onClick={onUnlock}
        className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2"
      >
        <Crown className="w-3.5 h-3.5" />
        <span>Buka Akses dengan TRDS Premium</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
