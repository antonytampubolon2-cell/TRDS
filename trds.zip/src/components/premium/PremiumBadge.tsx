import React from 'react';
import { Crown, Sparkles } from 'lucide-react';

interface PremiumBadgeProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'amber' | 'purple' | 'subtle';
  showIcon?: boolean;
  text?: string;
  className?: string;
}

export const PremiumBadge: React.FC<PremiumBadgeProps> = ({
  size = 'sm',
  variant = 'amber',
  showIcon = true,
  text = 'PREMIUM',
  className = ''
}) => {
  const sizeClasses = {
    sm: 'text-[9px] px-1.5 py-0.5 gap-1 font-bold',
    md: 'text-[10px] px-2 py-0.5 gap-1.5 font-bold',
    lg: 'text-xs px-2.5 py-1 gap-1.5 font-bold'
  };

  const variantClasses = {
    amber: 'bg-amber-500/15 border-amber-500/40 text-amber-300 shadow-sm shadow-amber-500/10',
    purple: 'bg-purple-500/15 border-purple-500/40 text-purple-300 shadow-sm shadow-purple-500/10',
    subtle: 'bg-slate-800 border-slate-700 text-slate-300'
  };

  const iconSizes = {
    sm: 'w-2.5 h-2.5',
    md: 'w-3 h-3',
    lg: 'w-3.5 h-3.5'
  };

  return (
    <span
      className={`inline-flex items-center rounded-full border tracking-wider uppercase select-none ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
    >
      {showIcon && <Crown className={iconSizes[size]} />}
      <span className="whitespace-nowrap">{text}</span>
    </span>
  );
};
