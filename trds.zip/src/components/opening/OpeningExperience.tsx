import React, { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import { SplashScreen } from './SplashScreen';
import { WelcomeScreen } from './WelcomeScreen';

interface OpeningExperienceProps {
  onComplete: () => void;
}

export const OpeningExperience: React.FC<OpeningExperienceProps> = ({ onComplete }) => {
  const [stage, setStage] = useState<'splash' | 'welcome'>('splash');

  return (
    <div id="trds-opening-experience" className="relative w-full h-full min-h-[580px] sm:min-h-[850px] bg-slate-950 flex flex-col overflow-hidden">
      <AnimatePresence mode="wait">
        {stage === 'splash' ? (
          <SplashScreen key="trds-splash" onComplete={() => setStage('welcome')} />
        ) : (
          <WelcomeScreen key="trds-welcome" onStart={onComplete} />
        )}
      </AnimatePresence>
    </div>
  );
};
