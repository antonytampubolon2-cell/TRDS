import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { TrdsBrandLogo } from '../common/TrdsBrandLogo';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  useEffect(() => {
    // Automatically transition to Welcome Screen after ~1.8 seconds
    const timer = setTimeout(() => {
      onComplete();
    }, 1800);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      id="trds-splash-screen"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
      className="relative w-full h-full min-h-[580px] sm:min-h-[750px] flex flex-col items-center justify-between p-6 select-none bg-slate-950 overflow-hidden"
    >
      {/* Subtle Background Radial Glow */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
        <div className="w-80 h-80 rounded-full bg-cyan-500/15 blur-3xl" />
        <div className="w-56 h-56 rounded-full bg-blue-600/15 blur-2xl" />
      </div>

      {/* Top Spacer */}
      <div className="w-full h-8" />

      {/* Center Logo & Wordmark Area with Shield Emblem */}
      <div className="relative z-10 flex flex-col items-center text-center space-y-3 my-auto">
        <motion.div
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <TrdsBrandLogo size="xl" />
        </motion.div>

        <motion.div
          initial={{ y: 8, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="text-[11px] sm:text-xs font-bold tracking-[0.25em] text-cyan-400 uppercase">
            TRADE - TRUST - TRANSPARENCY
          </p>
        </motion.div>
      </div>

      {/* Bottom Minimal Loading Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="relative z-10 flex flex-col items-center space-y-2 pb-6"
      >
        <div className="w-32 h-1 bg-slate-900 rounded-full overflow-hidden relative shadow-sm shadow-cyan-500/20">
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{
              repeat: Infinity,
              duration: 1.2,
              ease: 'easeInOut'
            }}
            className="w-16 h-full bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
          />
        </div>
        <span className="text-[10px] font-medium tracking-wider text-slate-500 uppercase">
          Memuat Pengalaman Trading...
        </span>
      </motion.div>
    </motion.div>
  );
};
