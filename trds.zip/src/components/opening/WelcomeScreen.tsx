import React from 'react';
import { motion } from 'motion/react';
import { BookOpen, SlidersHorizontal, Bot, ArrowRight, ChevronRight } from 'lucide-react';
import { TrdsBrandLogo } from '../common/TrdsBrandLogo';

interface WelcomeScreenProps {
  onStart: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart }) => {
  const features = [
    {
      id: 'feature-learn',
      title: 'LEARN',
      description: 'Pelajari konsep dan istilah trading.',
      icon: BookOpen,
      iconBg: 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30'
    },
    {
      id: 'feature-simulator',
      title: 'SIMULATOR',
      description: 'Berlatih menggunakan dana virtual.',
      icon: SlidersHorizontal,
      iconBg: 'bg-teal-500/15 text-teal-400 border border-teal-500/30'
    },
    {
      id: 'feature-ai',
      title: 'TRDS AI',
      description: 'Dapatkan bantuan untuk memahami konsep trading.',
      icon: Bot,
      iconBg: 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
    }
  ];

  return (
    <motion.div
      id="trds-welcome-screen"
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
      className="relative w-full h-full min-h-[580px] sm:min-h-[750px] flex flex-col justify-between px-5 py-6 select-none bg-slate-950 overflow-y-auto"
    >
      {/* Subtle Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-24 left-1/2 -translate-x-1/2 w-56 h-56 bg-blue-600/10 rounded-full blur-2xl pointer-events-none" />

      {/* Main Content Area */}
      <div className="relative z-10 space-y-4 pt-1">
        {/* Top Branding: TRDS Shield Emblem with Candlestick & Upward Arrow */}
        <div className="text-center space-y-1.5">
          {/* Logo with Shield Emblem & Typography */}
          <TrdsBrandLogo size="lg" />

          {/* Official Tagline */}
          <p className="text-[11px] sm:text-xs font-bold tracking-[0.25em] text-cyan-400 uppercase pt-0.5">
            TRADE - TRUST - TRANSPARENCY
          </p>
        </div>

        {/* Headline & Description */}
        <div className="text-center space-y-1.5 max-w-sm mx-auto px-1">
          <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-snug">
            Belajar Trading dengan Cara yang Lebih Terarah.
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Pelajari konsep trading, pahami pasar, dan berlatih menggunakan simulator virtual.
          </p>
        </div>

        {/* Feature Highlight Cards */}
        <div className="space-y-2.5 max-w-sm mx-auto pt-1">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.15 + idx * 0.1, ease: 'easeOut' }}
                className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800/80 shadow-md flex items-center justify-between gap-3.5 hover:border-slate-700/80 transition"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 shadow-sm ${feature.iconBg}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs font-extrabold text-white tracking-wider block">
                      {feature.title}
                    </span>
                    <p className="text-xs text-slate-400 leading-relaxed mt-0.5 truncate">
                      {feature.description}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 shrink-0" />
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Bottom CTA Area */}
      <div className="relative z-10 pt-5 pb-2 max-w-sm mx-auto w-full space-y-3">
        <button
          id="btn-welcome-start"
          type="button"
          onClick={onStart}
          className="w-full py-3.5 px-6 rounded-full bg-white hover:bg-slate-100 text-slate-950 font-black text-sm sm:text-base shadow-xl shadow-cyan-500/20 active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer touch-manipulation"
        >
          <span>MULAI</span>
          <ArrowRight className="w-4 h-4 stroke-[2.5]" />
        </button>

        {/* Mandatory Educational Disclaimer Subtext */}
        <p className="text-[11px] font-medium text-slate-500 text-center tracking-wide">
          Virtual Trading • Educational Purpose
        </p>
      </div>
    </motion.div>
  );
};
