import React from 'react';
import {
  Brain,
  ShieldCheck,
  Sparkles,
  AlertTriangle,
  Smile,
  Compass,
  ArrowRight,
  TrendingUp,
  Award
} from 'lucide-react';
import { Trade, TradeJournalEntry } from '../../types';

interface PsychologySummaryCardProps {
  trades: Trade[];
  journals: Record<string, TradeJournalEntry>;
  onOpenJournalForFirstUnjournaled?: () => void;
}

export const PsychologySummaryCard: React.FC<PsychologySummaryCardProps> = ({
  trades,
  journals,
  onOpenJournalForFirstUnjournaled
}) => {
  const journalList: TradeJournalEntry[] = Object.values(journals);
  const totalTrades = trades.length;
  const journaledCount = journalList.length;

  if (totalTrades === 0) {
    return null;
  }

  // If user hasn't journaled any trades yet
  if (journaledCount === 0) {
    return (
      <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-indigo-500/30 shadow-md space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-black text-white">Jurnal & Psikologi Perdagangan</h4>
              <span className="text-[10px] text-slate-400">Belum ada catatan refleksi transaksi</span>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
            0 / {totalTrades} Tercatat
          </span>
        </div>

        <p className="text-[11px] text-slate-300 leading-relaxed">
          Kunci trader konsisten bukan menebak harga, melainkan mencatat dan mengevaluasi keputusan.
          Klik tombol <strong>&ldquo;+ Jurnal&rdquo;</strong> pada riwayat transaksimu untuk mendeteksi kebiasaan emosional tradingmu.
        </p>

        {onOpenJournalForFirstUnjournaled && (
          <button
            type="button"
            onClick={onOpenJournalForFirstUnjournaled}
            className="w-full py-2 px-3 rounded-xl bg-indigo-600/80 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Mulai Catat Jurnal Pertama</span>
          </button>
        )}
      </div>
    );
  }

  // Calculate psychology statistics
  const calmTrades = journalList.filter(
    (j: TradeJournalEntry) => j.psychologyState === 'calm_disciplined' || j.psychologyState === 'confident_measured'
  ).length;
  const fomoTrades = journalList.filter(
    (j: TradeJournalEntry) => j.psychologyState === 'fomo_rushed' || j.psychologyState === 'revenge_emotional'
  ).length;
  const otherTrades = journalList.length - calmTrades - fomoTrades;

  const disciplinedPlanTrades = journalList.filter(
    (j: TradeJournalEntry) => j.planAdherence === 'strict_plan' || j.planAdherence === 'stopped_out_valid'
  ).length;
  const disciplineIndexPercent = Math.round((disciplinedPlanTrades / journalList.length) * 100);

  const avgDisciplineScore = (
    journalList.reduce((acc: number, curr: TradeJournalEntry) => acc + (curr.disciplineScore || 3), 0) /
    journalList.length
  ).toFixed(1);

  // Strategy performance check
  const reasonBreakdown: Record<string, number> = {};
  journalList.forEach((j: TradeJournalEntry) => {
    reasonBreakdown[j.entryReason] = (reasonBreakdown[j.entryReason] || 0) + 1;
  });

  const topReasonKey = Object.entries(reasonBreakdown).sort((a, b) => b[1] - a[1])[0]?.[0];
  const formatReasonLabel = (key?: string) => {
    switch (key) {
      case 'trend_following': return 'Mengikuti Tren';
      case 'support_resistance': return 'Support/Resistance';
      case 'breakout': return 'Breakout Terkonfirmasi';
      case 'reversal_oversold': return 'Reversal Jenuh (RSI)';
      case 'trds_ai_analysis': return 'Saran TRDS AI';
      case 'fomo_impulsive': return 'FOMO / Terburu-buru';
      default: return 'Eksperimen Spontan';
    }
  };

  return (
    <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-md space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
            <Brain className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-black text-white">Analisis Psikologi & Disiplin</h4>
            <span className="text-[10px] text-slate-400">
              {journaledCount} dari {totalTrades} transaksi tercatat di jurnal
            </span>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[9px] text-slate-400 uppercase font-mono block">Indeks Disiplin</span>
          <span
            className={`text-sm font-black font-mono ${
              disciplineIndexPercent >= 70
                ? 'text-emerald-400'
                : disciplineIndexPercent >= 50
                ? 'text-amber-400'
                : 'text-rose-400'
            }`}
          >
            {disciplineIndexPercent}%
          </span>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/80">
          <span className="text-[10px] text-slate-400 block">Emosi Tenang</span>
          <span className="text-xs font-bold text-emerald-400 font-mono mt-0.5 block">
            {calmTrades} <span className="text-[10px] text-slate-500">({Math.round((calmTrades / journalList.length) * 100)}%)</span>
          </span>
        </div>

        <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/80">
          <span className="text-[10px] text-slate-400 block">FOMO / Impulsif</span>
          <span className="text-xs font-bold text-rose-400 font-mono mt-0.5 block">
            {fomoTrades} <span className="text-[10px] text-slate-500">({Math.round((fomoTrades / journalList.length) * 100)}%)</span>
          </span>
        </div>

        <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/80">
          <span className="text-[10px] text-slate-400 block">Skor Disiplin Rata2</span>
          <span className="text-xs font-bold text-amber-400 font-mono mt-0.5 block">
            {avgDisciplineScore} / 5.0
          </span>
        </div>
      </div>

      {/* Progress Bar of Emotions */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
          <span>Keseimbangan Emosional:</span>
          <span>{fomoTrades > 0 ? `${fomoTrades} transaksi emosional terdeteksi` : '100% disiplin!'}</span>
        </div>
        <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden flex">
          <div
            style={{ width: `${(calmTrades / journalList.length) * 100}%` }}
            className="bg-emerald-500 h-full transition-all"
            title="Tenang & Terencana"
          />
          <div
            style={{ width: `${(otherTrades / journalList.length) * 100}%` }}
            className="bg-slate-600 h-full transition-all"
            title="Netral / Cemas"
          />
          <div
            style={{ width: `${(fomoTrades / journalList.length) * 100}%` }}
            className="bg-rose-500 h-full transition-all"
            title="FOMO / Balas Dendam"
          />
        </div>
      </div>

      {/* Insights Tip */}
      <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300 flex items-start gap-2">
        <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-white">Insight TRDS: </span>
          {topReasonKey === 'fomo_impulsive' || fomoTrades > calmTrades ? (
            <span>
              Perhatian: Frekuensi transaksi impulsif masih tinggi. Luangkan jeda 10 menit sebelum mengeksekusi order virtual agar tidak terjebak lonjakan harga sesaat.
            </span>
          ) : (
            <span>
              Strategi paling sering digunakan adalah <strong>{formatReasonLabel(topReasonKey)}</strong>. Pertahankan kedisiplinan eksekusi saat menghadapi volatilitas pasar!
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
