import React from 'react';
import {
  XCircle,
  TrendingUp,
  TrendingDown,
  Lock,
  Layers,
  Info,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { Asset } from '../../types';
import { HoldingMeta } from '../../context/AppContext';

interface ActivePositionPanelProps {
  asset: Asset;
  holdingQty: number;
  holdingMeta?: HoldingMeta;
  onClosePosition: () => void;
  isClosing: boolean;
  otherActiveAssets?: { id: string; symbol: string; qty: number }[];
  onSelectAsset?: (id: string) => void;
}

export const ActivePositionPanel: React.FC<ActivePositionPanelProps> = ({
  asset,
  holdingQty,
  holdingMeta,
  onClosePosition,
  isClosing,
  otherActiveAssets = [],
  onSelectAsset
}) => {
  const hasOpenPosition = holdingQty > 0;
  const avgEntryPrice = holdingMeta?.avgBuyPrice || asset.price;
  const currentValue = holdingQty * asset.price;
  const costBasis = holdingQty * avgEntryPrice;
  const floatingPnL = currentValue - costBasis;
  const floatingPnLPct = costBasis > 0 ? (floatingPnL / costBasis) * 100 : 0;
  const isGain = floatingPnL >= 0;
  const estimatedExitFee = currentValue * 0.001; // 0.10% virtual fee

  if (!hasOpenPosition) {
    return (
      <div
        id="active-position-panel-empty"
        className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 text-xs space-y-2.5 shadow-sm"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-400">
            <Layers className="w-4 h-4 text-slate-500" />
            <span className="font-bold text-slate-300">Status Posisi:</span>
            <span className="text-[11px] font-semibold text-slate-500">
              Tidak Ada Posisi Terbuka untuk {asset.symbol}
            </span>
          </div>

          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-semibold border border-slate-700/60">
            0 {asset.unit}
          </span>
        </div>

        {/* Other active positions switcher if user holds other assets */}
        {otherActiveAssets.length > 0 && (
          <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between gap-2 flex-wrap">
            <span className="text-[10px] text-slate-400 font-medium">
              Posisi Terbuka Lainnya:
            </span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {otherActiveAssets.map(other => (
                <button
                  key={other.id}
                  type="button"
                  onClick={() => onSelectAsset && onSelectAsset(other.id)}
                  className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-cyan-500/50 text-cyan-300 text-[10px] font-bold transition flex items-center gap-1"
                  title={`Lihat posisi ${other.symbol}`}
                >
                  <span>{other.symbol}</span>
                  <span className="text-slate-400 font-mono">({other.qty})</span>
                  <ArrowRight className="w-2.5 h-2.5 text-slate-400" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      id="active-position-panel"
      className="p-4 rounded-2xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-cyan-500/30 space-y-3.5 shadow-xl relative overflow-hidden"
    >
      {/* Subtle background glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />

      {/* 1. Header: Position Information */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-300">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500" />
            </span>
            <span className="text-[10px] font-black uppercase tracking-wider">
              POSISI VIRTUAL AKTIF
            </span>
          </div>

          <span className="text-xs font-black text-white">{asset.symbol}</span>
          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            LONG
          </span>
        </div>

        <div className="text-right">
          <span className="text-[10px] text-slate-400 block font-medium">Ukuran Posisi</span>
          <span className="font-mono font-black text-white text-xs">
            {holdingQty} {asset.unit}
          </span>
        </div>
      </div>

      {/* 2. PnL / Position Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 bg-slate-950/70 p-3 rounded-xl border border-slate-800/90 text-xs">
        <div>
          <span className="text-[10px] text-slate-400 block">Harga Masuk (Avg):</span>
          <span className="font-mono font-bold text-slate-200">
            ${avgEntryPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 block">Harga Pasar (Mark):</span>
          <span className="font-mono font-bold text-white">
            ${asset.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 block">Nilai Posisi:</span>
          <span className="font-mono font-bold text-white">
            ${currentValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </span>
        </div>

        <div className="col-span-2 sm:col-span-2 pt-1 border-t border-slate-800/80">
          <span className="text-[10px] text-slate-400 block">Floating PnL (Unrealized):</span>
          <div className="flex items-baseline gap-1.5">
            <span
              className={`font-black font-mono text-sm inline-flex items-center gap-0.5 ${
                isGain ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {isGain ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              {isGain ? '+' : ''}${floatingPnL.toFixed(2)}
            </span>
            <span
              className={`text-[11px] font-bold font-mono ${
                isGain ? 'text-emerald-300' : 'text-rose-300'
              }`}
            >
              ({isGain ? '+' : ''}{floatingPnLPct.toFixed(2)}%)
            </span>
          </div>
        </div>

        <div className="pt-1 border-t border-slate-800/80">
          <span className="text-[10px] text-slate-400 block">Est. Fee (0.10%):</span>
          <span className="font-mono font-medium text-amber-300/90 text-xs">
            ~${estimatedExitFee.toFixed(2)}
          </span>
        </div>
      </div>

      {/* 3. ONE-TAP CLOSE BUTTON (Section 3, 4, 5, 17) */}
      <div className="space-y-1.5 pt-1">
        <button
          id="btn-one-tap-close"
          type="button"
          onClick={onClosePosition}
          disabled={isClosing}
          aria-label="Tutup transaksi virtual dengan satu ketukan"
          className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-gradient-to-r from-rose-950/70 via-slate-800 to-slate-850 hover:from-rose-900/80 hover:to-slate-800 active:from-rose-950 active:to-slate-900 border border-rose-500/50 hover:border-rose-400 text-white font-black text-xs uppercase tracking-wider transition-all duration-150 active:scale-[0.99] shadow-lg shadow-rose-950/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 group"
        >
          {isClosing ? (
            <>
              <div className="w-4 h-4 border-2 border-rose-400 border-t-transparent rounded-full animate-spin" />
              <span className="text-rose-200">MENUTUP...</span>
            </>
          ) : (
            <>
              <XCircle className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
              <span className="text-white tracking-widest font-black">TUTUP TRANSAKSI</span>
            </>
          )}
        </button>

        {/* Supporting microcopy (Section 3 requirement) */}
        <p className="text-[11px] text-center text-slate-400 font-medium">
          Tap sekali untuk menutup posisi virtual
        </p>
      </div>

      {/* 4. Small Educational Explanation (Section 17 requirement) */}
      <div className="flex items-start gap-1.5 p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/60 text-[10px] text-slate-400 leading-relaxed">
        <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
        <span>
          Simulasi penutupan pasar virtual instan tanpa slippage real-money. Saldo kas, PnL terealisasi, dan riwayat transaksi akan langsung diperbarui.
        </span>
      </div>
    </div>
  );
};
