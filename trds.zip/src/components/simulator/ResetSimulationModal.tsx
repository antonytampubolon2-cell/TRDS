import React from 'react';
import { RotateCcw, AlertTriangle, X, ShieldAlert, Check } from 'lucide-react';

interface ResetSimulationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const ResetSimulationModal: React.FC<ResetSimulationModalProps> = ({
  isOpen,
  onClose,
  onConfirm
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="reset-simulation-modal"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="reset-modal-title"
    >
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl text-slate-200">
        <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1 mb-2 sm:hidden" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h3 id="reset-modal-title" className="text-base font-extrabold text-white">
                Reset Data Simulasi
              </h3>
              <span className="text-[11px] text-slate-400">
                Kembalikan saldo dan portofolio ke kondisi awal
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
            aria-label="Tutup"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Prompt & Warning Banner */}
        <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Reset all virtual trading data?</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Apakah kamu yakin ingin mereset seluruh data simulasi trading? Tindakan ini akan mengembalikan akun demo ke saldo awal.
          </p>
        </div>

        {/* Explicit Warning */}
        <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5 text-amber-300 text-xs">
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
          <div className="space-y-0.5">
            <span className="font-bold text-[11px] block">This only resets virtual simulation data.</span>
            <span className="text-[10px] text-amber-300/80 block">
              Poin XP akun, pencapaian, dan riwayat belajar di TRDS Learn tidak akan terhapus.
            </span>
          </div>
        </div>

        {/* What Will Happen Checklist */}
        <div className="space-y-2 p-3.5 rounded-2xl bg-slate-950/40 border border-slate-800/80 text-xs">
          <span className="text-slate-400 font-semibold block text-[11px]">Yang akan direset:</span>
          <div className="space-y-1.5 text-slate-300">
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Saldo kembali ke <strong>10,000 USDT virtual</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Seluruh kepemilikan aset kembali ke <strong>0</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Open Orders & Order History <strong>dihapus</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Trade History <strong>dihapus</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Realized & Unrealized PnL kembali ke <strong>$0.00</strong></span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            type="button"
            id="cancel-reset-sim-btn"
            onClick={onClose}
            className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-bold text-xs transition border border-slate-700/70"
          >
            Batal
          </button>

          <button
            type="button"
            id="confirm-reset-sim-btn"
            onClick={onConfirm}
            className="py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase tracking-wide transition shadow-lg shadow-rose-600/25 flex items-center justify-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Simulasi</span>
          </button>
        </div>
      </div>
    </div>
  );
};
