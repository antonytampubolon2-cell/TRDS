import React, { useState, useMemo, useRef } from 'react';
import { BarChart2, LineChart, Info, ShieldAlert } from 'lucide-react';
import { Asset, SimulatorTimeframe, CandlestickBar } from '../../types';
import { generateCandlestickData } from '../../utils/candlestickGenerator';

interface TradingChartProps {
  asset: Asset;
  timeframe: SimulatorTimeframe;
  onTimeframeChange: (tf: SimulatorTimeframe) => void;
  chartType: 'candlestick' | 'line';
  onChartTypeChange: (type: 'candlestick' | 'line') => void;
}

const TIMEFRAMES: SimulatorTimeframe[] = ['1m', '5m', '15m', '1H', '4H', '1D'];

export const TradingChart: React.FC<TradingChartProps> = ({
  asset,
  timeframe,
  onTimeframeChange,
  chartType,
  onChartTypeChange
}) => {
  const [hoveredCandle, setHoveredCandle] = useState<CandlestickBar | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Generate 22 realistic candles matching the current asset price and timeframe
  const candles = useMemo(() => {
    return generateCandlestickData(asset.price, asset.change24h, timeframe, 22);
  }, [asset.id, asset.price, asset.change24h, timeframe]);

  // Compute boundaries
  const { minPrice, maxPrice, maxVolume } = useMemo(() => {
    let min = Infinity;
    let max = -Infinity;
    let maxVol = 0;

    for (const c of candles) {
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
      if (c.volume > maxVol) maxVol = c.volume;
    }

    // Add 4% padding for visual headroom
    const span = max - min || 1;
    return {
      minPrice: Math.max(0.0001, min - span * 0.04),
      maxPrice: max + span * 0.04,
      maxVolume: maxVol || 1
    };
  }, [candles]);

  const priceRange = maxPrice - minPrice || 1;
  const decimals = asset.price < 1 ? 4 : asset.price < 10 ? 3 : 2;

  // Active candle to display in header (either hovered or the latest)
  const activeCandle = hoveredCandle || candles[candles.length - 1];

  // SVG dimensions for coordinate calculations
  const svgWidth = 400;
  const svgHeight = 220;
  const chartHeight = 165; // Price chart area
  const volumeHeight = 45; // Volume area at bottom
  const paddingX = 14;

  const getX = (index: number) => {
    const usableWidth = svgWidth - paddingX * 2;
    return paddingX + (index / (candles.length - 1)) * usableWidth;
  };

  const getY = (price: number) => {
    const normalized = (price - minPrice) / priceRange;
    return chartHeight - normalized * (chartHeight - 15);
  };

  const candleWidth = Math.max(5, Math.min(12, (svgWidth - paddingX * 2) / candles.length - 3));

  // Points for Line/Area chart
  const linePoints = useMemo(() => {
    return candles.map((c, i) => [getX(i), getY(c.close)]);
  }, [candles, minPrice, priceRange]);

  const polylineStr = linePoints.map(p => `${p[0]},${p[1]}`).join(' ');
  const areaPath = `M ${linePoints[0][0]},${chartHeight} L ${polylineStr} L ${linePoints[linePoints.length - 1][0]},${chartHeight} Z`;

  // Current price line Y
  const currentPriceY = getY(asset.price);
  const isPositiveTrend = asset.change24h >= 0;

  return (
    <div
      id="simulator-trading-chart"
      className="p-3.5 rounded-2xl bg-slate-900/95 border border-slate-800/90 space-y-2.5 shadow-lg"
    >
      {/* Top Header: Controls & Simulated Badge */}
      <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
        {/* Timeframe Selectors */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
          {TIMEFRAMES.map(tf => {
            const isActive = timeframe === tf;
            return (
              <button
                key={tf}
                id={`chart-tf-${tf}`}
                type="button"
                onClick={() => onTimeframeChange(tf)}
                className={`px-2 py-1 rounded-lg text-xs font-bold transition-all shrink-0 ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 shadow-sm shadow-emerald-500/20'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {tf}
              </button>
            );
          })}
        </div>

        {/* Right Controls: Chart Mode & Demo Badge */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-0.5 bg-slate-800/80 p-0.5 rounded-xl border border-slate-700/80">
            <button
              id="chart-type-candlestick"
              type="button"
              onClick={() => onChartTypeChange('candlestick')}
              className={`p-1.5 rounded-lg transition ${
                chartType === 'candlestick'
                  ? 'bg-slate-700 text-emerald-400 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Candlestick Chart"
              aria-label="Candlestick Chart"
            >
              <BarChart2 className="w-3.5 h-3.5" />
            </button>
            <button
              id="chart-type-line"
              type="button"
              onClick={() => onChartTypeChange('line')}
              className={`p-1.5 rounded-lg transition ${
                chartType === 'line'
                  ? 'bg-slate-700 text-emerald-400 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Line Chart"
              aria-label="Line Chart"
            >
              <LineChart className="w-3.5 h-3.5" />
            </button>
          </div>

          <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/15 text-amber-300 border border-amber-500/30 whitespace-nowrap">
            SIMULATED DATA
          </span>
        </div>
      </div>

      {/* Interactive OHLCV Readout Banner */}
      {activeCandle && (
        <div className="flex items-center justify-between text-[11px] font-mono bg-slate-950/60 px-2.5 py-1.5 rounded-xl border border-slate-800/60 overflow-x-auto no-scrollbar gap-2">
          <span className="text-slate-400 shrink-0">{activeCandle.time}</span>
          <div className="flex items-center gap-2.5 shrink-0">
            <span>
              <span className="text-slate-500 mr-0.5">O:</span>
              <span className="text-slate-300">${activeCandle.open.toFixed(decimals)}</span>
            </span>
            <span>
              <span className="text-slate-500 mr-0.5">H:</span>
              <span className="text-slate-300">${activeCandle.high.toFixed(decimals)}</span>
            </span>
            <span>
              <span className="text-slate-500 mr-0.5">L:</span>
              <span className="text-slate-300">${activeCandle.low.toFixed(decimals)}</span>
            </span>
            <span>
              <span className="text-slate-500 mr-0.5">C:</span>
              <span className={activeCandle.isUp ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                ${activeCandle.close.toFixed(decimals)}
              </span>
            </span>
          </div>
        </div>
      )}

      {/* SVG Canvas Area */}
      <div
        ref={containerRef}
        className="h-48 w-full relative bg-slate-950/70 rounded-xl overflow-hidden border border-slate-800/70 cursor-crosshair select-none"
        onMouseLeave={() => setHoveredCandle(null)}
      >
        {/* Subtle Horizontal Price Grid Lines */}
        <div className="absolute inset-0 flex flex-col justify-between p-2 pointer-events-none opacity-20">
          <div className="w-full border-b border-dashed border-slate-600" />
          <div className="w-full border-b border-dashed border-slate-600" />
          <div className="w-full border-b border-dashed border-slate-600" />
          <div className="w-full border-b border-dashed border-slate-600" />
        </div>

        {/* High & Low Price Tags */}
        <div className="absolute top-1.5 right-2 text-[10px] font-mono text-slate-500 pointer-events-none">
          Max: ${maxPrice.toFixed(decimals)}
        </div>
        <div className="absolute bottom-8 right-2 text-[10px] font-mono text-slate-500 pointer-events-none">
          Min: ${minPrice.toFixed(decimals)}
        </div>

        {/* Main SVG Render */}
        <svg
          className="w-full h-full"
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="tradingLineGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={isPositiveTrend ? '#10B981' : '#F43F5E'} stopOpacity="0.3" />
              <stop offset="100%" stopColor={isPositiveTrend ? '#10B981' : '#F43F5E'} stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Volume bars at bottom */}
          {candles.map((c, i) => {
            const x = getX(i);
            const volRatio = c.volume / maxVolume;
            const barH = Math.max(3, volRatio * (volumeHeight - 8));
            const y = svgHeight - barH;
            return (
              <rect
                key={`vol-${i}`}
                x={x - candleWidth / 2}
                y={y}
                width={candleWidth}
                height={barH}
                fill={c.isUp ? '#10B981' : '#F43F5E'}
                opacity={0.35}
                rx={1}
              />
            );
          })}

          {/* Candlesticks or Line */}
          {chartType === 'candlestick' ? (
            candles.map((c, i) => {
              const x = getX(i);
              const yHigh = getY(c.high);
              const yLow = getY(c.low);
              const yOpen = getY(c.open);
              const yClose = getY(c.close);

              const bodyY = Math.min(yOpen, yClose);
              const bodyHeight = Math.max(2.5, Math.abs(yOpen - yClose));
              const color = c.isUp ? '#10B981' : '#F43F5E';

              return (
                <g
                  key={`candle-${i}`}
                  className="transition-opacity hover:opacity-80"
                  onMouseEnter={() => setHoveredCandle(c)}
                  onTouchStart={() => setHoveredCandle(c)}
                >
                  {/* High - Low Wick */}
                  <line
                    x1={x}
                    y1={yHigh}
                    x2={x}
                    y2={yLow}
                    stroke={color}
                    strokeWidth={1.2}
                    strokeLinecap="round"
                  />
                  {/* Real Body */}
                  <rect
                    x={x - candleWidth / 2}
                    y={bodyY}
                    width={candleWidth}
                    height={bodyHeight}
                    fill={color}
                    stroke={color}
                    strokeWidth={0.5}
                    rx={1}
                  />
                </g>
              );
            })
          ) : (
            <>
              {/* Filled Area */}
              <path d={areaPath} fill="url(#tradingLineGrad)" />
              {/* Continuous Stroke */}
              <path
                d={`M ${polylineStr}`}
                fill="none"
                stroke={isPositiveTrend ? '#10B981' : '#F43F5E'}
                strokeWidth={2.4}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </>
          )}

          {/* Current Live Price Line */}
          <line
            x1={0}
            y1={currentPriceY}
            x2={svgWidth}
            y2={currentPriceY}
            stroke={isPositiveTrend ? '#10B981' : '#F43F5E'}
            strokeWidth={1}
            strokeDasharray="3 3"
            opacity={0.85}
          />
        </svg>

        {/* Live Price Tag Floating on Right */}
        <div
          className="absolute right-0 -translate-y-1/2 px-1.5 py-0.5 rounded-l text-[10px] font-mono font-bold text-slate-950 shadow-md"
          style={{
            top: `${Math.min(chartHeight - 10, Math.max(12, (currentPriceY / svgHeight) * 100))}%`,
            backgroundColor: isPositiveTrend ? '#10B981' : '#F43F5E'
          }}
        >
          ${asset.price.toFixed(decimals)}
        </div>

        {/* Watermark in background */}
        <div className="absolute bottom-2 left-2.5 text-[9px] font-mono text-slate-600 pointer-events-none flex items-center gap-1">
          <span>{asset.symbol}</span>
          <span>•</span>
          <span>{timeframe}</span>
          <span>•</span>
          <span>DEMO MARKET</span>
        </div>
      </div>

      {/* Safety Notice Footer */}
      <div className="flex items-center gap-1.5 text-[10px] text-slate-400 bg-slate-950/40 p-2 rounded-xl border border-slate-800/50">
        <Info className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
        <span className="leading-tight">
          TRDS Simulator menggunakan data dan saldo virtual. Tidak ada uang nyata yang digunakan.
        </span>
      </div>
    </div>
  );
};
