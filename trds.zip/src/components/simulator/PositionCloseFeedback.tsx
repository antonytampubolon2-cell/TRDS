import React from 'react';
import { CheckCircle2, AlertCircle, X, DollarSign, ArrowUpRight, ArrowDownRight, ShieldCheck, BookOpen, Sparkles } from 'lucide-react';
import { PositionCloseDetails } from '../../context/AppContext';
import { Trade } from '../../types';

export interface CloseFeedbackState {
  type: 'success' | 'error';
  title: string;
  message?: string;
  closeDetails?: PositionCloseDetails;
  trade?: Trade;
}

interface PositionCloseFeedbackProps {
  feedback: CloseFeedbackState | null;
  onDismiss: () => void;
  onOpenJournal?: (trade?: Trade) => void;
}

export const PositionCloseFeedback: React.FC<PositionCloseFeedbackProps> = ({
  feedback,
  onDismiss,
  onOpenJournal
}) => {
  if (!feedback) return null;

  const isSuccess = feedback.type === 'success';
  const details = feedback.closeDetails;
  const isGain = (details?.realizedPnL || 0) >= 0;

  return (
    <div
      id="position-close-feedback-banner"
      className={`rounded-2xl border p-3.5 shadow-xl transition-all duration-200 animate-in fade-in slide-in-from-top-2 ${
        isSuccess
          ? isGain
            ? 'bg-gradient-to-r from-emerald-950/90 via-slate-900 to-slate-950 border-emerald-500/40 shadow-emerald-950/30'
            : 'bg-gradient-to-r from-rose-950/90 via-slate-900 to-slate-950 border-rose-500/40 shadow-rose-950/30'
          : 'bg-gradient-to-r from-rose-950/90 via-slate-900 to-slate-950 border-rose-500/40 shadow-rose-950/30'
      }`}
      role="status"
      aria-live="polite"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
              isSuccess
                ? isGain
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
            }`}
          >
            {isSuccess ? (
              isGain ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )
            ) : (
              <AlertCircle className="w-4 h-4" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span
                className={`text-[11px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md ${
                  isSuccess
                    ? isGain
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {feedback.title}
              </span>
              {details && (
                <span className="text-xs font-black text-white">
                  {details.symbol}
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-300 font-medium mt-0.5">
              {isSuccess
                ? 'Virtual Position Closed • Saldo & Portofolio Diperbarui'
                : feedback.message || 'Gagal mengeksekusi penutupan posisi.'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onDismiss}
          className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          aria-label="Tutup notifikasi"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Success Metrics Breakdown */}
      {isSuccess && details && (
        <div className="mt-3 pt-2.5 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/70">
            <span className="text-[10px] text-slate-400 block">Realized PnL:</span>
            <span
              className={`font-black font-mono text-sm inline-flex items-center gap-0.5 ${
                isGain ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {isGain ? '+' : ''}${details.realizedPnL.toFixed(2)}
              <span className="text-[10px] font-semibold">
                ({isGain ? '+' : ''}{details.pnlPercent.toFixed(2)}%)
              </span>
            </span>
          </div>

          <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/70">
            <span className="text-[10px] text-slate-400 block">Simulated Fee (0.10%):</span>
            <span className="font-bold font-mono text-amber-300 text-xs">
              ${details.fee.toFixed(2)}
            </span>
          </div>

          <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/70">
            <span className="text-[10px] text-slate-400 block">Nilai Penutupan:</span>
            <span className="font-bold font-mono text-white text-xs">
              ${details.closeValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </span>
          </div>

          <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/70">
            <span className="text-[10px] text-slate-400 block">Kas Virtual Diterima:</span>
            <span className="font-bold font-mono text-emerald-400 text-xs">
              +${details.netProceeds.toLocaleString('en-US', { minimumFractionDigits: 2 })} USDT
            </span>
          </div>
        </div>
      )}

      {/* Journal Reflection Prompt */}
      {isSuccess && onOpenJournal && (
        <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>Refleksikan keputusan trading ini: Emosi tenang atau FOMO?</span>
          </div>

          <button
            id="btn-open-journal-from-close-banner"
            type="button"
            onClick={() => onOpenJournal(feedback.trade)}
            className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md shadow-indigo-900/40 transition active:scale-95"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Tulis Jurnal Refleksi (+20 XP)</span>
          </button>
        </div>
      )}
    </div>
  );
};
