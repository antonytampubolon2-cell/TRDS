import React from 'react';
import {
  X,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  AlertCircle,
  Clock,
  DollarSign,
  Wallet
} from 'lucide-react';
import { Asset, OrderSide, OrderType } from '../../types';

interface OrderConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  asset: Asset;
  side: OrderSide;
  type: OrderType;
  price: number;
  amount: number;
  totalValue: number;
  fee: number;
  currentBalance: number;
  assetHolding: number;
  remainingCash: number;
  remainingAsset: number;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  asset,
  side,
  type,
  price,
  amount,
  totalValue,
  fee,
  currentBalance,
  assetHolding,
  remainingCash,
  remainingAsset
}) => {
  if (!isOpen) return null;

  const isBuy = side === 'buy';
  const isMarket = type === 'market';
  const decimals = price < 1 ? 4 : price < 10 ? 3 : 2;

  return (
    <div
      id="order-confirmation-modal"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-order-title"
    >
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl text-slate-200">
        {/* Mobile handle */}
        <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1 mb-2 sm:hidden" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
                isBuy ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
              }`}
            >
              {isBuy ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
            </div>
            <div>
              <h3 id="confirm-order-title" className="text-base font-extrabold text-white">
                Confirm Virtual Order
              </h3>
              <span className="text-[11px] text-slate-400">
                Konfirmasi transaksi simulasi trading
              </span>
            </div>
          </div>

          <button
            id="close-confirm-order-btn"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
            aria-label="Batalkan"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Badge & Asset Summary */}
        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span
                className={`px-2.5 py-0.5 rounded-lg text-xs font-black uppercase ${
                  isBuy
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-rose-500 text-white'
                }`}
              >
                {isBuy ? 'Virtual BUY' : 'Virtual SELL'}
              </span>
              <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-slate-800 text-slate-300 uppercase">
                {isMarket ? 'Market Order' : 'Limit Order'}
              </span>
            </div>
            <div className="text-lg font-black text-white mt-1.5">
              {asset.symbol} • <span className="text-sm font-semibold text-slate-400">{asset.name}</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-400 block font-medium">Harga Eksekusi</span>
            <span className="text-base font-black text-white font-mono">
              ${price.toLocaleString('en-US', { minimumFractionDigits: decimals })}
            </span>
          </div>
        </div>

        {/* Transaction Details Breakdown */}
        <div className="space-y-2.5 p-3.5 rounded-2xl bg-slate-950/50 border border-slate-800/80 text-xs">
          <div className="flex justify-between items-center text-slate-300">
            <span className="text-slate-400">Jumlah Aset:</span>
            <span className="font-mono font-bold text-white">
              {amount} {asset.unit}
            </span>
          </div>

          <div className="flex justify-between items-center text-slate-300">
            <span className="text-slate-400">Tipe Pesanan:</span>
            <span className="font-semibold text-slate-200">
              {isMarket ? 'Market (Instan)' : `Limit (@ $${price.toFixed(decimals)})`}
            </span>
          </div>

          <div className="flex justify-between items-center text-slate-300 border-t border-slate-800/80 pt-2">
            <span className="text-slate-400">Total Nilai Virtual:</span>
            <span className="font-mono font-extrabold text-white text-sm">
              ${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>

          <div className="flex justify-between items-center text-slate-300">
            <span className="text-slate-400">Simulated Fee:</span>
            <span className="font-mono text-emerald-400 font-medium">
              ${fee.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (0.10% Virtual)
            </span>
          </div>

          <div className="border-t border-slate-800/80 pt-2 space-y-1.5">
            <div className="flex justify-between items-center text-slate-400 text-[11px]">
              <span>Saldo USDT Sekarang:</span>
              <span className="font-mono text-slate-300">
                ${currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex justify-between items-center text-slate-400 text-[11px]">
              <span>Estimasi Sisa Saldo USDT:</span>
              <span className="font-mono font-bold text-emerald-400">
                ${remainingCash.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
            {!isBuy && (
              <div className="flex justify-between items-center text-slate-400 text-[11px]">
                <span>Estimasi Sisa {asset.unit}:</span>
                <span className="font-mono font-bold text-slate-200">
                  {remainingAsset.toFixed(4)} {asset.unit}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Mandatory Safety Notice */}
        <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-amber-300 text-xs">
          <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
          <div className="space-y-0.5">
            <span className="font-bold block text-[11px]">Virtual transaction — no real money involved.</span>
            <p className="text-[10px] text-amber-300/80 leading-snug">
              Order ini 100% simulasi. Saldo yang dipotong adalah saldo demo virtual untuk melatih kemampuan analisismu.
            </p>
          </div>
        </div>

        {/* Action Buttons: Cancel & Confirm */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            id="cancel-confirm-order-btn"
            type="button"
            onClick={onClose}
            className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-bold text-xs transition border border-slate-700/70"
          >
            Batal
          </button>

          <button
            id="submit-confirm-order-btn"
            type="button"
            onClick={onConfirm}
            className={`py-3 px-4 rounded-xl font-black text-xs uppercase tracking-wide transition shadow-lg flex items-center justify-center gap-1.5 ${
              isBuy
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/25'
                : 'bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/25'
            }`}
          >
            <span>Konfirmasi {isBuy ? 'Beli' : 'Jual'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
