import React, { useState } from 'react';
import { X, Search, TrendingUp, TrendingDown, Check } from 'lucide-react';
import { Asset, AssetCategory } from '../../types';

interface AssetSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  assets: Asset[];
  selectedAssetId: string;
  onSelectAsset: (assetId: string) => void;
}

export const AssetSelectorModal: React.FC<AssetSelectorModalProps> = ({
  isOpen,
  onClose,
  assets,
  selectedAssetId,
  onSelectAsset
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');

  if (!isOpen) return null;

  const categories = [
    { id: 'all', label: 'Semua' },
    { id: 'crypto', label: 'Crypto' },
    { id: 'stocks', label: 'Stocks' },
    { id: 'forex', label: 'Forex' },
    { id: 'commodities', label: 'Komoditas' }
  ];

  const filteredAssets = assets.filter(asset => {
    const matchesCategory = activeCategory === 'all' || asset.category === activeCategory;
    const matchesSearch =
      asset.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div
      id="asset-selector-modal"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="asset-selector-title"
    >
      <div className="w-full max-w-md max-h-[85vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 overflow-hidden flex flex-col shadow-2xl text-slate-200">
        <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1 mb-2 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 shrink-0">
          <div>
            <h3 id="asset-selector-title" className="text-base font-extrabold text-white">
              Pilih Pasangan Aset
            </h3>
            <span className="text-[11px] text-slate-400">
              Pilih instrumen pasar untuk simulasi trading
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
            aria-label="Tutup"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Input */}
        <div className="mt-3 relative shrink-0">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="asset-selector-search"
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari simbol atau nama aset..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Category Pills */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-2.5 shrink-0">
          {categories.map(cat => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                activeCategory === cat.id
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'bg-slate-800/70 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Assets List */}
        <div className="overflow-y-auto space-y-1.5 pr-1 flex-1 py-1">
          {filteredAssets.length === 0 ? (
            <p className="text-xs text-slate-500 text-center py-8">
              Tidak ada instrumen yang cocok dengan pencarianmu.
            </p>
          ) : (
            filteredAssets.map(asset => {
              const isSelected = asset.id === selectedAssetId;
              const isPositive = asset.change24h >= 0;

              return (
                <button
                  key={asset.id}
                  id={`select-asset-${asset.id}`}
                  type="button"
                  onClick={() => {
                    onSelectAsset(asset.id);
                    onClose();
                  }}
                  className={`w-full p-3 rounded-2xl border text-left transition flex items-center justify-between ${
                    isSelected
                      ? 'bg-emerald-500/10 border-emerald-500/50 shadow-sm'
                      : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700/80 flex items-center justify-center font-bold text-xs text-white">
                      {asset.symbol.split('/')[0].slice(0, 3)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-white">{asset.symbol}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                      </div>
                      <span className="text-[11px] text-slate-400">{asset.name}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-mono font-bold text-white text-xs">
                      ${asset.price.toLocaleString('en-US', {
                        minimumFractionDigits: asset.price < 1 ? 4 : 2,
                        maximumFractionDigits: asset.price < 1 ? 4 : 2
                      })}
                    </div>
                    <div
                      className={`text-[10px] font-semibold inline-flex items-center gap-0.5 ${
                        isPositive ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isPositive ? '+' : ''}{asset.change24h}%
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
