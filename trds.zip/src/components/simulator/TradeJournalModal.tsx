import React, { useState, useEffect } from 'react';
import {
  X,
  BookOpen,
  Brain,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Smile,
  AlertCircle,
  Zap,
  CheckCircle2,
  Trash2,
  Save,
  HelpCircle,
  Compass
} from 'lucide-react';
import {
  Trade,
  TradeJournalEntry,
  EntryReasonCategory,
  TradingPsychologyState,
  PlanAdherence
} from '../../types';

interface TradeJournalModalProps {
  isOpen: boolean;
  onClose: () => void;
  trade: Trade | null;
  existingJournal?: TradeJournalEntry;
  onSaveJournal: (tradeId: string, entry: Omit<TradeJournalEntry, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onDeleteJournal?: (tradeId: string) => void;
}

const ENTRY_REASONS: { id: EntryReasonCategory; label: string; desc: string; icon: string }[] = [
  { id: 'trend_following', label: 'Mengikuti Tren', desc: 'Sesuai arah tren utama (MA / Higher High)', icon: '📈' },
  { id: 'support_resistance', label: 'Support / Resistance', desc: 'Reaksi pemantulan atau batas zona harga', icon: '🧱' },
  { id: 'breakout', label: 'Breakout Terkonfirmasi', desc: 'Menembus konsolidasi dengan volume kuat', icon: '🚀' },
  { id: 'reversal_oversold', label: 'Reversal Jenuh (RSI)', desc: 'Indikator momentum menunjukkan titik jenuh', icon: '🔄' },
  { id: 'trds_ai_analysis', label: 'Saran TRDS AI', desc: 'Berdasarkan sintesis data edukasi AI TRDS', icon: '🤖' },
  { id: 'fomo_impulsive', label: 'FOMO / Terburu-buru', desc: 'Takut ketinggalan reli harga yang melonjak', icon: '⚡' },
  { id: 'unplanned', label: 'Tanpa Rencana', desc: 'Spontan atau sekadar menguji simulator', icon: '🎲' }
];

const PSYCHOLOGY_STATES: { id: TradingPsychologyState; label: string; desc: string; mood: 'good' | 'neutral' | 'warning' }[] = [
  { id: 'calm_disciplined', label: 'Tenang & Disiplin', desc: 'Kondisi emosi stabil tanpa dorongan panik', mood: 'good' },
  { id: 'confident_measured', label: 'Percaya Diri Terukur', desc: 'Analisis matang dan risiko terkontrol', mood: 'good' },
  { id: 'fomo_rushed', label: 'FOMO / Cemas', desc: 'Merasa harus segera masuk agar tidak tertinggal', mood: 'warning' },
  { id: 'greedy_aggressive', label: 'Serakah / Agresif', desc: 'Ingin keuntungan besar dalam tempo kilat', mood: 'warning' },
  { id: 'hesitant_fearful', label: 'Ragu-ragu / Takut', desc: 'Cemas kehilangan modal virtual saat klik eksekusi', mood: 'neutral' },
  { id: 'revenge_emotional', label: 'Balas Dendam Pasar', desc: 'Ingin buru-buru membalas kekalahan transaksi lalu', mood: 'warning' }
];

const PLAN_ADHERENCES: { id: PlanAdherence; label: string; desc: string }[] = [
  { id: 'strict_plan', label: 'Patuh Rencana Penuh', desc: 'Entry dan exit konsisten sesuai skenario awal' },
  { id: 'stopped_out_valid', label: 'Stop Loss Terencana', desc: 'Menutup posisi karena batas risiko tercapai' },
  { id: 'early_exit_fear', label: 'Keluar Lebih Awal (Cemas)', desc: 'Menutup posisi sebelum target karena takut balik arah' },
  { id: 'greed_delayed_exit', label: 'Menahan Terlalu Lama (Serakah)', desc: 'Tidak merealisasikan target karena ingin lebih banyak' },
  { id: 'no_plan', label: 'Tanpa Rencana Awal', desc: 'Membuka posisi tanpa menentukan batas risiko/target' }
];

export const TradeJournalModal: React.FC<TradeJournalModalProps> = ({
  isOpen,
  onClose,
  trade,
  existingJournal,
  onSaveJournal,
  onDeleteJournal
}) => {
  const [entryReason, setEntryReason] = useState<EntryReasonCategory>('trend_following');
  const [psychologyState, setPsychologyState] = useState<TradingPsychologyState>('calm_disciplined');
  const [planAdherence, setPlanAdherence] = useState<PlanAdherence>('strict_plan');
  const [disciplineScore, setDisciplineScore] = useState<number>(4);
  const [userReflectionNotes, setUserReflectionNotes] = useState<string>('');

  useEffect(() => {
    if (existingJournal) {
      setEntryReason(existingJournal.entryReason);
      setPsychologyState(existingJournal.psychologyState);
      setPlanAdherence(existingJournal.planAdherence);
      setDisciplineScore(existingJournal.disciplineScore || 4);
      setUserReflectionNotes(existingJournal.userReflectionNotes || '');
    } else {
      // Default initial state
      setEntryReason('trend_following');
      setPsychologyState('calm_disciplined');
      setPlanAdherence('strict_plan');
      setDisciplineScore(4);
      setUserReflectionNotes('');
    }
  }, [existingJournal, trade]);

  if (!isOpen || !trade) return null;

  const isSell = trade.side === 'sell';
  const hasPnL = trade.simulatedPnL !== undefined;
  const pnl = trade.simulatedPnL || 0;
  const isProfit = pnl >= 0;

  // Calculate dynamic educational feedback
  const getEducationalInsight = (): { feedback: string; isGoodRisk: boolean; badge: string; color: string } => {
    const isImpulsiveEmotion = psychologyState === 'fomo_rushed' || psychologyState === 'revenge_emotional';
    const isImpulsiveReason = entryReason === 'fomo_impulsive' || entryReason === 'unplanned';

    if (isImpulsiveEmotion || isImpulsiveReason) {
      if (isSell && hasPnL && isProfit) {
        return {
          feedback:
            "⚠️ Peringatan 'Lucky Trade': Transaksi ini menghasilkan profit virtual, namun didorong oleh emosi FOMO atau tanpa rencana matang. Di pasar riil, profit kebetulan ini berbahaya karena dapat menumbuhkan rasa percaya diri semu (overconfidence bias).",
          isGoodRisk: false,
          badge: 'Lucky Trade • Perlu Waspada',
          color: 'amber'
        };
      }
      return {
        feedback:
          "❌ 'Impulsive Execution': Transaksi ini didorong emosi atau ketiadaan skenario awal. Evaluasi apa pemicunya: apakah sedang lelah, tergiur lonjakan candle cepat, atau ingin membalas kekalahan sebelumnya?",
        isGoodRisk: false,
        badge: 'Emosional • Evaluasi Diri',
        color: 'rose'
      };
    }

    if (planAdherence === 'strict_plan' || planAdherence === 'stopped_out_valid') {
      if (isSell && hasPnL && !isProfit) {
        return {
          feedback:
            "🛡️ 'Good Risk Management Loss': Mengalami kerugian dengan batas Stop Loss terencana adalah kemenangan disiplin. Kerugian terkontrol adalah biaya wajar dalam probabilitas pasar. Kamu melindungi 98%+ modalmu!",
          isGoodRisk: true,
          badge: 'Disiplin Tinggi • Good Risk Loss',
          color: 'emerald'
        };
      }
      return {
        feedback:
          "✅ 'High Discipline Trade': Transaksi dieksekusi dengan kepala dingin dan rencana terstruktur. Kemenangan sejati seorang trader bukanlah profit sesaat, melainkan kemampuan mengeksekusi rencana tanpa dipengaruhi emosi.",
        isGoodRisk: true,
        badge: 'Disiplin Sempurna • Good Execution',
        color: 'emerald'
      };
    }

    if (planAdherence === 'early_exit_fear') {
      return {
        feedback:
          "⚠️ 'Fear-Based Exit': Kamu keluar lebih cepat dari rencana karena cemas. Cobalah melatih toleransi fluktuasi normal dengan mengecilkan ukuran posisi (position sizing) agar lebih nyaman.",
        isGoodRisk: false,
        badge: 'Kecemasan Keluar Lebih Awal',
        color: 'amber'
      };
    }

    return {
      feedback:
        "💡 'Pembelajaran Berharga': Setiap transaksi simulasi memberikan data tentang kebiasaan psikologis pribadimu. Catat apa yang bisa diperbaiki pada transaksi berikutnya.",
      isGoodRisk: disciplineScore >= 3,
      badge: 'Evaluasi Pembelajaran',
      color: 'blue'
    };
  };

  const insight = getEducationalInsight();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveJournal(trade.id, {
      tradeId: trade.id,
      symbol: trade.symbol,
      side: trade.side,
      entryReason,
      psychologyState,
      planAdherence,
      disciplineScore,
      userReflectionNotes,
      educationalFeedback: insight.feedback,
      isGoodRiskTrade: insight.isGoodRisk
    });
    onClose();
  };

  return (
    <div
      id="trade-journal-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="trade-journal-modal"
        className="w-full max-w-lg max-h-[92vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden text-slate-100"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-white">Jurnal & Psikologi Trading</h3>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                  {trade.symbol}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Refleksi edukatif untuk membangun disiplin trader</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 space-y-4 text-xs no-scrollbar">
          {/* Trade Snapshot Card */}
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span
                  className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                    trade.side === 'buy'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {trade.side.toUpperCase()}
                </span>
                <span className="font-mono font-bold text-white text-xs">{trade.symbol}</span>
                <span className="text-slate-400 font-mono text-[11px]">
                  {trade.amount} @ ${trade.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <span className="text-[10px] text-slate-500 block">
                {new Date(trade.timestamp).toLocaleString('id-ID', {
                  day: 'numeric',
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-mono">Total Nilai</span>
              <span className="font-bold text-white font-mono text-xs">
                ${trade.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              {trade.simulatedPnL !== undefined && trade.side === 'sell' && (
                <span
                  className={`text-[11px] font-black font-mono block ${
                    trade.simulatedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {trade.simulatedPnL >= 0 ? '+' : ''}${trade.simulatedPnL.toFixed(2)}
                </span>
              )}
            </div>
          </div>

          {/* Section 1: Alasan Entry */}
          <div className="space-y-2">
            <label className="font-bold text-slate-200 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-emerald-400" />
                1. Apa alasanmu membuka posisi ini?
              </span>
              <span className="text-[10px] text-slate-400 font-normal">Pilih satu alasan utama</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {ENTRY_REASONS.map(r => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setEntryReason(r.id)}
                  className={`p-2.5 rounded-xl border text-left transition flex items-start gap-2 ${
                    entryReason === r.id
                      ? 'bg-emerald-950/40 border-emerald-500/60 text-white shadow-sm ring-1 ring-emerald-500/30'
                      : 'bg-slate-950/50 border-slate-800/80 text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  <span className="text-base shrink-0 mt-0.5">{r.icon}</span>
                  <div className="min-w-0">
                    <span className="font-bold block text-xs leading-tight">{r.label}</span>
                    <span className="text-[10px] text-slate-400 block leading-snug mt-0.5 truncate">
                      {r.desc}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Section 2: Kondisi Psikologi & Emosi */}
          <div className="space-y-2">
            <label className="font-bold text-slate-200 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Brain className="w-3.5 h-3.5 text-purple-400" />
                2. Bagaimana kondisi emosimu saat eksekusi?
              </span>
              <span className="text-[10px] text-slate-400 font-normal">Jujur pada diri sendiri</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
              {PSYCHOLOGY_STATES.map(p => {
                const isSelected = psychologyState === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPsychologyState(p.id)}
                    className={`p-2 rounded-xl border text-left transition space-y-1 ${
                      isSelected
                        ? p.mood === 'good'
                          ? 'bg-emerald-950/40 border-emerald-500/60 text-white shadow-sm ring-1 ring-emerald-500/30'
                          : p.mood === 'warning'
                          ? 'bg-amber-950/40 border-amber-500/60 text-white shadow-sm ring-1 ring-amber-500/30'
                          : 'bg-slate-800 border-slate-600 text-white'
                        : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:bg-slate-800/50'
                    }`}
                  >
                    <span className="font-bold text-[11px] block leading-tight">{p.label}</span>
                    <span className="text-[9px] text-slate-400 block leading-tight">{p.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 3: Kepatuhan Rencana (Plan Adherence) */}
          <div className="space-y-2">
            <label className="font-bold text-slate-200 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                3. Seberapa patuh terhadap rencana trading?
              </span>
            </label>
            <div className="space-y-1">
              {PLAN_ADHERENCES.map(pl => (
                <button
                  key={pl.id}
                  type="button"
                  onClick={() => setPlanAdherence(pl.id)}
                  className={`w-full p-2 rounded-xl border text-left transition flex items-center justify-between gap-2 ${
                    planAdherence === pl.id
                      ? 'bg-blue-950/40 border-blue-500/60 text-white ring-1 ring-blue-500/30'
                      : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  <div>
                    <span className="font-bold block text-xs">{pl.label}</span>
                    <span className="text-[10px] text-slate-400 block">{pl.desc}</span>
                  </div>
                  {planAdherence === pl.id && <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* Section 4: Skor Disiplin Mandiri (1 - 5 Bintang) */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 text-xs">Skor Disiplin Diri:</span>
              <span className="font-mono font-bold text-amber-400 text-xs">{disciplineScore} / 5 Bintang</span>
            </div>
            <div className="flex items-center justify-between gap-1">
              {[1, 2, 3, 4, 5].map(score => (
                <button
                  key={score}
                  type="button"
                  onClick={() => setDisciplineScore(score)}
                  className={`flex-1 py-1.5 rounded-lg border text-xs font-bold transition flex items-center justify-center gap-1 ${
                    disciplineScore >= score
                      ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                      : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
                  }`}
                >
                  <span>★</span>
                  <span>{score}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Section 5: Dynamic TRDS Educational Feedback */}
          <div
            className={`p-3 rounded-xl border space-y-1.5 ${
              insight.color === 'emerald'
                ? 'bg-emerald-950/25 border-emerald-500/30'
                : insight.color === 'amber'
                ? 'bg-amber-950/25 border-amber-500/30'
                : insight.color === 'rose'
                ? 'bg-rose-950/25 border-rose-500/30'
                : 'bg-blue-950/25 border-blue-500/30'
            }`}
          >
            <div className="flex items-center justify-between">
              <span
                className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded ${
                  insight.color === 'emerald'
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : insight.color === 'amber'
                    ? 'bg-amber-500/20 text-amber-400'
                    : insight.color === 'rose'
                    ? 'bg-rose-500/20 text-rose-400'
                    : 'bg-blue-500/20 text-blue-400'
                }`}
              >
                {insight.badge}
              </span>
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                Analisis TRDS AI
              </span>
            </div>
            <p className="text-[11px] text-slate-200 leading-relaxed">{insight.feedback}</p>
          </div>

          {/* Section 6: Catatan Refleksi Bebas */}
          <div className="space-y-1.5">
            <label htmlFor="user-reflection-notes" className="font-bold text-slate-200 block text-xs">
              Catatan Refleksi Pribadi (Opsional):
            </label>
            <textarea
              id="user-reflection-notes"
              value={userReflectionNotes}
              onChange={e => setUserReflectionNotes(e.target.value)}
              placeholder="Contoh: 'Saya tergiur candle hijau 5 menit terakhir tanpa menunggu konfirmasi MA. Lain kali saya akan pasang limit order di zona support...'"
              rows={3}
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 transition resize-none leading-relaxed"
            />
          </div>
        </form>

        {/* Footer Actions */}
        <div className="p-3.5 border-t border-slate-800 flex items-center justify-between gap-2 bg-slate-950/60 shrink-0">
          {existingJournal && onDeleteJournal ? (
            <button
              type="button"
              onClick={() => {
                onDeleteJournal(trade.id);
                onClose();
              }}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-rose-400 hover:text-rose-300 font-bold text-xs flex items-center gap-1.5 transition border border-slate-700 hover:border-rose-500/40"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus</span>
            </button>
          ) : (
            <div className="text-[10px] text-slate-500 flex items-center gap-1">
              <HelpCircle className="w-3 h-3 text-slate-400" />
              <span>Tersimpan di browser lokal</span>
            </div>
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold text-xs transition"
            >
              Batal
            </button>

            <button
              type="button"
              onClick={handleSubmit}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 transition"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Simpan Jurnal</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
