import React from 'react';
import {
  BookOpen,
  Activity,
  BarChart2,
  TrendingUp,
  ShieldCheck,
  Brain,
  SlidersHorizontal,
  Layers
} from 'lucide-react';
import { LearningCategoryId, Lesson } from '../../types';
import { LEARNING_CATEGORIES } from '../../data/learningData';

interface CategoryFilterProps {
  selectedCategory: LearningCategoryId | 'all';
  onSelectCategory: (category: LearningCategoryId | 'all') => void;
  lessons: Lesson[];
  completedLessonIds: string[];
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  selectedCategory,
  onSelectCategory,
  lessons,
  completedLessonIds
}) => {
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'BookOpen':
        return <BookOpen className="w-3.5 h-3.5 shrink-0" />;
      case 'Activity':
        return <Activity className="w-3.5 h-3.5 shrink-0" />;
      case 'BarChart2':
        return <BarChart2 className="w-3.5 h-3.5 shrink-0" />;
      case 'TrendingUp':
        return <TrendingUp className="w-3.5 h-3.5 shrink-0" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-3.5 h-3.5 shrink-0" />;
      case 'Brain':
        return <Brain className="w-3.5 h-3.5 shrink-0" />;
      case 'SlidersHorizontal':
        return <SlidersHorizontal className="w-3.5 h-3.5 shrink-0" />;
      default:
        return <BookOpen className="w-3.5 h-3.5 shrink-0" />;
    }
  };

  const allCompletedCount = completedLessonIds.length;
  const allTotalCount = lessons.length;

  return (
    <div id="learning-category-filter" className="space-y-2">
      <div className="flex items-center justify-between text-xs px-1">
        <span className="font-semibold text-slate-300">Kategori Pelajaran</span>
        <span className="text-slate-400 text-[11px]">
          {selectedCategory === 'all'
            ? `${allTotalCount} Modul Total`
            : `${lessons.filter(l => l.categoryId === selectedCategory).length} Modul`}
        </span>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1.5 scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
        {/* All Categories Option */}
        <button
          onClick={() => onSelectCategory('all')}
          className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 shrink-0 border ${
            selectedCategory === 'all'
              ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm'
              : 'bg-slate-900/80 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
          }`}
        >
          <Layers className="w-3.5 h-3.5 shrink-0" />
          <span>Semua ({allCompletedCount}/{allTotalCount})</span>
        </button>

        {/* Categories from LEARNING_CATEGORIES */}
        {LEARNING_CATEGORIES.map(cat => {
          const catLessons = lessons.filter(l => l.categoryId === cat.id);
          const catCompleted = catLessons.filter(l => completedLessonIds.includes(l.id)).length;
          const isSelected = selectedCategory === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 shrink-0 border ${
                isSelected
                  ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm'
                  : 'bg-slate-900/80 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              {getCategoryIcon(cat.iconName)}
              <span>{cat.title}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  isSelected
                    ? 'bg-slate-950/20 text-slate-900 font-bold'
                    : 'bg-slate-800 text-slate-400 font-medium'
                }`}
              >
                {catCompleted}/{catLessons.length}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
