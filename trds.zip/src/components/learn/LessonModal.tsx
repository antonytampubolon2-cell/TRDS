import React from 'react';
import {
  X,
  Clock,
  Sparkles,
  CheckCircle2,
  HelpCircle,
  BookOpen,
  TrendingUp,
  Lightbulb,
  ArrowRight,
  Bot
} from 'lucide-react';
import { Lesson } from '../../types';
import { useApp } from '../../context/AppContext';
import { PremiumBadge } from '../premium/PremiumBadge';
import { PremiumFeatureLock } from '../premium/PremiumFeatureLock';

interface LessonModalProps {
  lesson: Lesson | null;
  onClose: () => void;
  onStartQuiz: (lesson: Lesson) => void;
}

export const LessonModal: React.FC<LessonModalProps> = ({
  lesson,
  onClose,
  onStartQuiz
}) => {
  const {
    completedLessonIds,
    markLessonCompleted,
    askAiAboutLesson,
    isPremium,
    openPremiumModal
  } = useApp();

  if (!lesson) return null;

  const isCompleted = completedLessonIds.includes(lesson.id);
  const isLocked = Boolean(lesson.isPremium && !isPremium);

  const handleMarkComplete = () => {
    markLessonCompleted(lesson.id);
  };

  return (
    <div
      id="lesson-reader-modal"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="w-full max-w-lg max-h-[90vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-2xl p-5 overflow-y-auto space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-emerald-400">
                {lesson.track === 'beginner' ? 'Pemula (Beginner)' : lesson.track === 'advanced' ? 'Lanjutan (Pro)' : 'Menengah (Intermediate)'}
              </span>
              {lesson.isPremium && <PremiumBadge size="sm" />}
              <span className="flex items-center gap-1 text-[11px] text-slate-400">
                <Clock className="w-3 h-3" />
                {lesson.durationMinutes || 5} Menit Baca
              </span>
            </div>
            <h2 className="text-base font-bold text-white mt-1 leading-snug">{lesson.title}</h2>
            <p className="text-xs text-slate-400 leading-relaxed">{lesson.subtitle}</p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition shrink-0 ml-2"
            aria-label="Tutup modul pelajaran"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* If locked, show PremiumFeatureLock */}
        {isLocked ? (
          <div className="space-y-4 py-2">
            <PremiumFeatureLock
              featureName={`Modul Pembelajaran: ${lesson.title}`}
              description="Materi lanjutan ini memuat formula kuantitatif institusional, kalkulasi Sharpe Ratio, drawdown mitigation, dan kuis evaluasi khusus pelanggan TRDS Premium."
              onUpgrade={() => {
                onClose();
                openPremiumModal(lesson.title);
              }}
            />
            {/* Sneak peek paragraph */}
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5 opacity-60">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Preview Ringkasan:</span>
              <p className="text-xs text-slate-300 italic">{lesson.content[0]}</p>
            </div>
          </div>
        ) : (
          <>
            {/* Content Paragraphs */}
            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              {lesson.content.map((paragraph, index) => (
                <p key={index} className="text-slate-300 leading-relaxed">
                  {paragraph}
                </p>
              ))}
            </div>

        {/* Real Simulation Example Scenario (if available) */}
        {lesson.exampleScenario && (
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-blue-500/30 space-y-2">
            <div className="flex items-center gap-1.5 text-blue-400 text-xs font-bold">
              <TrendingUp className="w-4 h-4" />
              <span>Simulasi Nyata: {lesson.exampleScenario.title}</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              <strong className="text-slate-200">Konteks Pasar:</strong> {lesson.exampleScenario.context}
            </p>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              <strong className="text-slate-200">Tindakan Trader:</strong> {lesson.exampleScenario.action}
            </p>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              <strong className="text-slate-200">Hasil & Dampak:</strong> {lesson.exampleScenario.outcome}
            </p>
            <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/20 text-[11px] text-blue-300 flex items-start gap-1.5 mt-1">
              <Lightbulb className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span>{lesson.exampleScenario.educationalInsight}</span>
            </div>
          </div>
        )}

        {/* Key Takeaways */}
        <div className="p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
          <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
            <BookOpen className="w-4 h-4" />
            <span>Poin Kunci Edukatif:</span>
          </div>
          <ul className="space-y-1.5 text-xs text-slate-300">
            {lesson.keyTakeaways.map((point, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0 mt-1.5" />
                <span className="leading-snug">{point}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Actions */}
        <div className="pt-2 border-t border-slate-800 flex flex-col gap-2">
          {/* Complete Lesson Button */}
          {!isCompleted ? (
            <button
              onClick={handleMarkComplete}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Tandai Selesai Dibaca (+{lesson.xpReward || 20} XP)</span>
            </button>
          ) : (
            <div className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-center flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              <span>Modul Telah Diselesaikan (XP Tersimpan)</span>
            </div>
          )}

          {/* Ask TRDS AI about this lesson (Requirement 7) */}
          <button
            id="ask-ai-lesson-btn"
            onClick={() => askAiAboutLesson(lesson)}
            className="w-full py-2.5 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/30 text-purple-200 font-semibold text-xs transition flex items-center justify-center gap-2 group"
          >
            <Bot className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
            <span>Ask TRDS AI about this lesson</span>
          </button>

          {/* Start Quiz Button (if available) */}
          {lesson.quiz && (
            <button
              onClick={() => onStartQuiz(lesson)}
              className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/20"
            >
              <HelpCircle className="w-4 h-4" />
              <span>Mulai Kuis Modul Ini (+{lesson.quiz.rewardXp} XP)</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </button>
          )}
        </div>
        </>
        )}
      </div>
    </div>
  );
};
