import React from 'react';
import { Target, CheckCircle2, Sparkles, ChevronRight, Clock } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface DailyChallengesCardProps {
  onOpenModal?: () => void;
}

export const DailyChallengesCard: React.FC<DailyChallengesCardProps> = ({ onOpenModal }) => {
  const { dailyChallenges, claimDailyChallenge } = useApp();

  const completedCount = dailyChallenges.filter(dc => dc.isCompleted).length;
  const totalCount = dailyChallenges.length;

  return (
    <div
      id="daily-challenges-card"
      className="p-4 rounded-2xl bg-gradient-to-br from-slate-900/90 to-slate-950 border border-slate-800 space-y-3 shadow-md"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Target className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Tantangan Harian</h3>
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
              <Clock className="w-2.5 h-2.5" />
              <span>Reset tiap 24 jam</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
            {completedCount}/{totalCount} Selesai
          </span>
          {onOpenModal && (
            <button
              onClick={onOpenModal}
              className="text-slate-400 hover:text-white p-1 transition"
              aria-label="Buka tantangan harian detail"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Challenge items */}
      <div className="space-y-2">
        {dailyChallenges.map(challenge => {
          const progressPercent = Math.min(
            100,
            Math.round(((challenge.currentCount || 0) / challenge.targetCount) * 100)
          );

          return (
            <div
              key={challenge.id}
              className={`p-2.5 rounded-xl border transition flex items-center justify-between gap-2.5 ${
                challenge.isCompleted
                  ? 'bg-emerald-950/15 border-emerald-500/30 text-emerald-300'
                  : 'bg-slate-950/40 border-slate-800/80 text-slate-300'
              }`}
            >
              <div className="space-y-1 flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-semibold text-white truncate">
                    {challenge.title}
                  </span>
                  {challenge.isCompleted && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-1 leading-tight">
                  {challenge.description}
                </p>

                {/* Micro progress bar */}
                <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      challenge.isCompleted ? 'bg-emerald-400' : 'bg-blue-400'
                    }`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              {/* XP Badge / Claim Button */}
              <div className="shrink-0 text-right">
                {challenge.isCompleted && !challenge.isClaimed ? (
                  <button
                    onClick={() => claimDailyChallenge(challenge.id)}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] font-bold transition flex items-center gap-1 shadow-sm"
                  >
                    <Sparkles className="w-3 h-3" />
                    +{challenge.xpReward} XP
                  </button>
                ) : (
                  <span className="text-[11px] font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-md flex items-center gap-0.5">
                    <Sparkles className="w-2.5 h-2.5" />
                    +{challenge.xpReward} XP
                  </span>
                )}
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  {challenge.currentCount || 0}/{challenge.targetCount}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
