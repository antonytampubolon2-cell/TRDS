import React from 'react';
import { Target, X, CheckCircle2, Sparkles, Clock, Calendar } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const DailyChallengesModal: React.FC = () => {
  const {
    isDailyChallengesModalOpen,
    closeDailyChallengesModal,
    dailyChallenges,
    claimDailyChallenge
  } = useApp();

  if (!isDailyChallengesModalOpen) return null;

  const completedCount = dailyChallenges.filter(dc => dc.isCompleted).length;
  const totalXp = dailyChallenges.reduce((acc, dc) => acc + (dc.xpReward || 0), 0);

  return (
    <div
      id="daily-challenges-modal"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="w-full max-w-md max-h-[85vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-2xl p-5 overflow-y-auto space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Tantangan Harian TRDS</h2>
              <p className="text-xs text-slate-400">Bangun rutinitas belajar & latihan trading</p>
            </div>
          </div>
          <button
            onClick={closeDailyChallengesModal}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition"
            aria-label="Tutup modal tantangan harian"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Info Banner */}
        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <Clock className="w-3.5 h-3.5 text-blue-400" />
            <span>Pembaruan otomatis tiap hari</span>
          </div>
          <span className="text-amber-400 font-bold flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            +{totalXp} XP Potensial
          </span>
        </div>

        {/* Progress Stats */}
        <div className="space-y-1.5 p-3 rounded-xl bg-slate-950/40 border border-slate-800/80">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Progres Tantangan Hari Ini</span>
            <span className="font-bold text-emerald-400">
              {completedCount} dari {dailyChallenges.length} Selesai
            </span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
              style={{
                width: `${(completedCount / Math.max(1, dailyChallenges.length)) * 100}%`
              }}
            />
          </div>
        </div>

        {/* Challenges List */}
        <div className="space-y-2.5">
          {dailyChallenges.map(dc => {
            const percent = Math.min(
              100,
              Math.round(((dc.currentCount || 0) / dc.targetCount) * 100)
            );

            return (
              <div
                key={dc.id}
                className={`p-3.5 rounded-2xl border transition space-y-2 ${
                  dc.isCompleted
                    ? 'bg-emerald-950/20 border-emerald-500/30'
                    : 'bg-slate-950/60 border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-white">{dc.title}</h4>
                      {dc.isCompleted && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 leading-snug">{dc.description}</p>
                  </div>

                  <div className="shrink-0 text-right">
                    {dc.isCompleted && !dc.isClaimed ? (
                      <button
                        onClick={() => claimDailyChallenge(dc.id)}
                        className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition flex items-center gap-1 shadow-sm"
                      >
                        <Sparkles className="w-3 h-3" />
                        Klaim +{dc.xpReward} XP
                      </button>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30 inline-flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5" />+{dc.xpReward} XP
                      </span>
                    )}
                  </div>
                </div>

                <div className="space-y-1 pt-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Target Harian</span>
                    <span className="font-semibold text-slate-300">
                      {dc.currentCount || 0} / {dc.targetCount}
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-1.5 rounded-full transition-all duration-300 ${
                        dc.isCompleted ? 'bg-emerald-400' : 'bg-blue-400'
                      }`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Close Button */}
        <button
          onClick={closeDailyChallengesModal}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition"
        >
          Tutup
        </button>
      </div>
    </div>
  );
};
