import React, { useState } from 'react';
import { Award, Sparkles, X, CheckCircle2, Lock, Trophy } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AchievementsModal: React.FC = () => {
  const { isAchievementsModalOpen, closeAchievementsModal, achievements } = useApp();
  const [filter, setFilter] = useState<'all' | 'unlocked' | 'locked'>('all');

  if (!isAchievementsModalOpen) return null;

  const unlockedCount = achievements.filter(a => a.isUnlocked).length;
  const totalXpEarned = achievements
    .filter(a => a.isUnlocked)
    .reduce((acc, a) => acc + (a.xpReward || 0), 0);

  const filtered = achievements.filter(a => {
    if (filter === 'unlocked') return a.isUnlocked;
    if (filter === 'locked') return !a.isUnlocked;
    return true;
  });

  return (
    <div
      id="achievements-modal"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="w-full max-w-md max-h-[85vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-2xl p-5 overflow-y-auto space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Prestasi TRDS</h2>
              <p className="text-xs text-slate-400">Pencapaian edukasi & simulasi trading</p>
            </div>
          </div>
          <button
            onClick={closeAchievementsModal}
            className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            aria-label="Tutup modal prestasi"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 block mb-0.5">Total Terbuka</span>
            <span className="text-base font-bold text-white">
              {unlockedCount} / {achievements.length}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 block mb-0.5">XP Diraih</span>
            <span className="text-base font-bold text-amber-400 flex items-center justify-center gap-1">
              <Sparkles className="w-4 h-4" />
              +{totalXpEarned} XP
            </span>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-1.5 p-1 rounded-xl bg-slate-950 border border-slate-800 text-xs">
          {(
            [
              { id: 'all', label: 'Semua' },
              { id: 'unlocked', label: `Terbuka (${unlockedCount})` },
              { id: 'locked', label: `Terkunci (${achievements.length - unlockedCount})` }
            ] as const
          ).map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={`flex-1 py-1.5 rounded-lg font-semibold transition text-[11px] ${
                filter === tab.id
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Achievement List */}
        <div className="space-y-2.5">
          {filtered.map(ach => {
            const percent = Math.min(
              100,
              Math.round(((ach.progress || 0) / ach.maxProgress) * 100)
            );

            return (
              <div
                key={ach.id}
                className={`p-3.5 rounded-2xl border transition space-y-2 ${
                  ach.isUnlocked
                    ? 'bg-amber-500/5 border-amber-500/30'
                    : 'bg-slate-950/40 border-slate-800/80 opacity-80'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                        ach.isUnlocked
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                          : 'bg-slate-800/80 text-slate-500 border border-slate-700'
                      }`}
                    >
                      {ach.isUnlocked ? (
                        <Award className="w-5 h-5" />
                      ) : (
                        <Lock className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-white">{ach.title}</h4>
                        {ach.isUnlocked && (
                          <span className="flex items-center gap-0.5 text-[10px] font-bold text-emerald-400">
                            <CheckCircle2 className="w-3 h-3" />
                            Selesai
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 leading-snug mt-0.5">
                        {ach.description}
                      </p>
                    </div>
                  </div>

                  <div className="shrink-0 text-right">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30 inline-flex items-center gap-0.5">
                      <Sparkles className="w-2.5 h-2.5" />+{ach.xpReward} XP
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="space-y-1 pt-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Progres Syarat</span>
                    <span className="font-semibold text-slate-300">
                      {ach.progress || 0} / {ach.maxProgress}
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-1.5 rounded-full transition-all duration-300 ${
                        ach.isUnlocked
                          ? 'bg-gradient-to-r from-amber-500 to-emerald-400'
                          : 'bg-slate-600'
                      }`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Close Button */}
        <button
          onClick={closeAchievementsModal}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition"
        >
          Tutup
        </button>
      </div>
    </div>
  );
};
