import React from 'react';
import { Sparkles, Award, BookOpen, CheckCircle2, Trophy } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface LearningProgressCardProps {
  onOpenAchievements?: () => void;
  compact?: boolean;
}

export const LearningProgressCard: React.FC<LearningProgressCardProps> = ({
  onOpenAchievements,
  compact = false
}) => {
  const { userProfile, lessons, completedLessonIds, achievements } = useApp();

  const totalLessons = lessons.length;
  const completedCount = completedLessonIds.length;
  const progressPercent = totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0;

  const currentLevelXp = userProfile.currentXp || 0;
  const nextLevelXp = userProfile.nextLevelXp || 100;
  const levelXpPercent = Math.min(100, Math.round((currentLevelXp / nextLevelXp) * 100));

  const unlockedAchievementsCount = achievements.filter(a => a.isUnlocked).length;

  if (compact) {
    return (
      <div
        id="learning-progress-compact"
        className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 space-y-3 shadow-md"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white">Akademi TRDS</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
                  Lvl {userProfile.level}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">{userProfile.levelTitle}</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-bold text-emerald-400">{progressPercent}% Selesai</span>
            <p className="text-[10px] text-slate-400">{completedCount}/{totalLessons} Modul</p>
          </div>
        </div>

        <div className="w-full bg-slate-800/80 rounded-full h-2 overflow-hidden">
          <div
            className="bg-gradient-to-r from-emerald-500 to-teal-400 h-2 rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div
      id="learning-progress-card"
      className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 space-y-4 shadow-xl"
    >
      {/* Header with Level & Total XP */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center gap-1">
              <Trophy className="w-3 h-3" />
              Level {userProfile.level}
            </span>
            <span className="text-xs font-semibold text-slate-300">
              {userProfile.levelTitle}
            </span>
          </div>
          <h2 className="text-base font-bold text-white mt-1">Kurikulum Edukasi TRDS</h2>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-400 text-xs font-bold shadow-sm">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{userProfile.totalXp ?? (userProfile.level > 1 ? 250 : userProfile.currentXp)} XP Total</span>
        </div>
      </div>

      {/* Level XP Progress Bar */}
      <div className="space-y-1.5 p-3 rounded-xl bg-slate-950/60 border border-slate-800/70">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 text-[11px] flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            Progres Menuju Level {userProfile.level + 1}
          </span>
          <span className="text-[11px] font-semibold text-slate-200">
            {currentLevelXp} / {nextLevelXp} XP ({levelXpPercent}%)
          </span>
        </div>
        <div className="w-full bg-slate-800/80 rounded-full h-2 overflow-hidden">
          <div
            className="bg-gradient-to-r from-amber-500 to-amber-400 h-2 rounded-full transition-all duration-500 shadow-sm"
            style={{ width: `${levelXpPercent}%` }}
          />
        </div>
      </div>

      {/* Stats Grid: Lessons, Quizzes, Achievements */}
      <div className="grid grid-cols-3 gap-2 text-center pt-1 border-t border-slate-800/80">
        <div className="p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/50">
          <div className="flex items-center justify-center gap-1 text-emerald-400 text-xs mb-0.5">
            <BookOpen className="w-3.5 h-3.5" />
            <span className="font-bold">{completedCount}/{totalLessons}</span>
          </div>
          <span className="text-[10px] text-slate-400">Modul Selesai</span>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/50">
          <div className="flex items-center justify-center gap-1 text-blue-400 text-xs mb-0.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span className="font-bold">{userProfile.quizzesPassedCount || 0}</span>
          </div>
          <span className="text-[10px] text-slate-400">Kuis Lulus</span>
        </div>

        <button
          onClick={onOpenAchievements}
          className="p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/50 hover:border-amber-500/40 transition group cursor-pointer"
        >
          <div className="flex items-center justify-center gap-1 text-amber-400 text-xs mb-0.5 group-hover:scale-105 transition-transform">
            <Award className="w-3.5 h-3.5" />
            <span className="font-bold">{unlockedAchievementsCount}/{achievements.length}</span>
          </div>
          <span className="text-[10px] text-slate-400 group-hover:text-slate-300">Achievement</span>
        </button>
      </div>
    </div>
  );
};
