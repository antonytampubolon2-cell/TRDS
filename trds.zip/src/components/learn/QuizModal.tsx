import React, { useState } from 'react';
import {
  X,
  Check,
  Award,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Bot
} from 'lucide-react';
import { Lesson, Quiz } from '../../types';
import { useApp } from '../../context/AppContext';

interface QuizModalProps {
  quizData: { lesson: Lesson; quiz: Quiz } | null;
  onClose: () => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({ quizData, onClose }) => {
  const { submitQuizResult, quizResults, askAiAboutQuiz } = useApp();

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [earnedXpReport, setEarnedXpReport] = useState<{
    isFirstTime: boolean;
    earnedXp: number;
    passed: boolean;
  } | null>(null);

  if (!quizData) return null;

  const { lesson, quiz } = quizData;
  const questions = quiz.questions || [];
  const currentQuestion = questions[currentIndex];
  const previousResult = quizResults[quiz.id];

  const handleSelectOption = (idx: number) => {
    if (isAnswerSubmitted) return;
    setSelectedOption(idx);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null || !currentQuestion) return;
    setIsAnswerSubmitted(true);
    if (selectedOption === currentQuestion.correctIndex) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswerSubmitted(false);
    } else {
      // Quiz finished
      const finalScore = selectedOption === currentQuestion.correctIndex ? score + 1 : score;
      const res = submitQuizResult(quiz.id, lesson.id, finalScore, questions.length);
      setEarnedXpReport(res);
      setIsCompleted(true);
    }
  };

  const handleRetry = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setScore(0);
    setIsCompleted(false);
    setEarnedXpReport(null);
  };

  return (
    <div
      id="quiz-modal"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-2xl p-5 space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                Kuis Interaktif
              </span>
              <h3 className="text-xs font-bold text-white truncate max-w-[220px]">
                {quiz.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition"
            aria-label="Tutup kuis"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Question View */}
        {!isCompleted && currentQuestion && (
          <div className="space-y-3.5">
            {/* Question Counter & Score Tracker */}
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">
                Pertanyaan <strong className="text-white">{currentIndex + 1}</strong> dari{' '}
                {questions.length}
              </span>
              <span className="text-amber-400 font-bold bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full text-[11px]">
                Skor Saat Ini: {score}
              </span>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-emerald-500 h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
              />
            </div>

            {/* Question Text */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-semibold text-white leading-relaxed">
              {currentQuestion.question}
            </div>

            {/* Options */}
            <div className="space-y-2">
              {currentQuestion.options.map((option, optIdx) => {
                const isSelected = selectedOption === optIdx;
                const isCorrect = optIdx === currentQuestion.correctIndex;
                let optionStyle =
                  'bg-slate-950/60 border-slate-800 text-slate-200 hover:border-slate-700';

                if (isAnswerSubmitted) {
                  if (isCorrect) {
                    optionStyle =
                      'bg-emerald-500/15 border-emerald-500/60 text-emerald-300 font-bold';
                  } else if (isSelected && !isCorrect) {
                    optionStyle = 'bg-rose-500/15 border-rose-500/60 text-rose-300';
                  } else {
                    optionStyle = 'bg-slate-950/40 border-slate-800/60 text-slate-500 opacity-60';
                  }
                } else if (isSelected) {
                  optionStyle =
                    'bg-emerald-500/10 border-emerald-500 text-emerald-300 font-semibold';
                }

                return (
                  <button
                    key={optIdx}
                    disabled={isAnswerSubmitted}
                    onClick={() => handleSelectOption(optIdx)}
                    className={`w-full p-3 rounded-xl border text-xs text-left transition flex items-center justify-between gap-2 cursor-pointer ${optionStyle}`}
                  >
                    <span>{option}</span>
                    {isAnswerSubmitted && isCorrect && (
                      <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation box */}
            {isAnswerSubmitted && (
              <div className="space-y-2 animate-in fade-in duration-200">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300 space-y-1">
                  <span className="font-bold text-emerald-400 block">Penjelasan Edukatif:</span>
                  <p className="leading-relaxed">{currentQuestion.explanation}</p>
                </div>
                {/* Ask TRDS AI to explain this answer (Requirement 8) */}
                <button
                  id="ask-ai-quiz-answer-btn"
                  onClick={() => {
                    if (selectedOption !== null) {
                      askAiAboutQuiz(quiz.title, currentQuestion, selectedOption);
                    }
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/30 text-purple-200 font-medium text-[11px] transition flex items-center justify-center gap-1.5 group"
                >
                  <Bot className="w-3.5 h-3.5 text-purple-400 group-hover:scale-110 transition-transform" />
                  <span>Ask TRDS AI to explain this answer</span>
                </button>
              </div>
            )}

            {/* Action Button */}
            {!isAnswerSubmitted ? (
              <button
                disabled={selectedOption === null}
                onClick={handleSubmitAnswer}
                className="w-full py-2.5 rounded-xl bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-emerald-400 text-slate-950 font-bold text-xs transition shadow-md"
              >
                Kunci Jawaban
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md"
              >
                <span>
                  {currentIndex + 1 < questions.length
                    ? 'Pertanyaan Berikutnya'
                    : 'Lihat Hasil Kuis'}
                </span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}

        {/* Completion Result Screen */}
        {isCompleted && (
          <div className="text-center py-4 space-y-4 animate-in fade-in duration-300">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/10">
              <Award className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h4 className="text-base font-bold text-white">Kuis Selesai!</h4>
              <p className="text-xs text-slate-400">
                Kamu menjawab <strong className="text-emerald-400">{score}</strong> dari{' '}
                <strong className="text-white">{questions.length}</strong> pertanyaan dengan benar.
              </p>
            </div>

            {/* XP and status notification */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              {earnedXpReport?.isFirstTime ? (
                <div className="space-y-1">
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 text-xs font-bold">
                    <Sparkles className="w-3.5 h-3.5" />
                    +{earnedXpReport.earnedXp} XP Ditambahkan ke Akun!
                  </span>
                  {earnedXpReport.passed && (
                    <p className="text-[11px] text-emerald-400 font-semibold">
                      Bonus kelulusan kuis berhasil diraih!
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-[11px] text-slate-400">
                  XP untuk kuis ini sudah pernah diklaim sebelumnya. Latihan ini membantu memperkuat
                  pemahaman pasarmu!
                </p>
              )}
            </div>

            {/* Ask TRDS AI about this quiz (Requirement 8) */}
            <button
              id="ask-ai-quiz-summary-btn"
              onClick={() => {
                if (questions.length > 0) {
                  askAiAboutQuiz(quiz.title, questions[0], questions[0].correctIndex);
                }
              }}
              className="w-full py-2.5 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/30 text-purple-200 font-semibold text-xs transition flex items-center justify-center gap-2 group"
            >
              <Bot className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
              <span>Ask TRDS AI to explain this quiz</span>
            </button>

            {/* Buttons */}
            <div className="flex gap-2 pt-2">
              <button
                onClick={handleRetry}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Ulangi Kuis</span>
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition shadow-lg shadow-emerald-500/20"
              >
                Selesai
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
