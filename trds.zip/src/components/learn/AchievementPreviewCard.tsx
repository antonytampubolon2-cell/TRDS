import React from 'react';
import { Award, ChevronRight, Lock, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AchievementPreviewCard: React.FC = () => {
  const { achievements, openAchievementsModal } = useApp();

  const unlocked = achievements.filter(a => a.isUnlocked);
  const nextTarget = achievements.find(a => !a.isUnlocked);

  return (
    <div
      id="achievement-preview-card"
      onClick={openAchievementsModal}
      className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-slate-900 to-slate-900 border border-amber-500/30 hover:border-amber-500/50 transition cursor-pointer group shadow-md"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <Award className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-bold text-white group-hover:text-amber-300 transition">
                Sistem Prestasi (Achievements)
              </h3>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2 py-0.2 rounded-full">
                {unlocked.length}/{achievements.length} Terbuka
              </span>
            </div>
            <p className="text-[11px] text-slate-400 line-clamp-1">
              {nextTarget
                ? `Target berikutnya: ${nextTarget.title}`
                : 'Selamat! Semua achievement telah berhasil dibuka!'}
            </p>
          </div>
        </div>

        <div className="flex items-center text-slate-400 group-hover:text-amber-400 transition">
          <span className="text-[11px] font-medium mr-1 hidden sm:inline">Lihat Semua</span>
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>

      {/* Mini badge row */}
      <div className="flex gap-2 mt-3 pt-3 border-t border-slate-800/80 overflow-x-auto scrollbar-none pb-0.5">
        {achievements.slice(0, 5).map(ach => (
          <div
            key={ach.id}
            className={`px-2.5 py-1.5 rounded-lg border text-[10px] flex items-center gap-1.5 shrink-0 ${
              ach.isUnlocked
                ? 'bg-amber-500/15 border-amber-500/30 text-amber-300 font-bold'
                : 'bg-slate-950/60 border-slate-800 text-slate-400'
            }`}
          >
            {ach.isUnlocked ? (
              <CheckCircle2 className="w-3 h-3 text-amber-400 shrink-0" />
            ) : (
              <Lock className="w-3 h-3 text-slate-500 shrink-0" />
            )}
            <span className="truncate max-w-[110px]">{ach.title}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
