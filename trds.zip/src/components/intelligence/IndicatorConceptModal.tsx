import React from 'react';
import { X, BookOpen, SlidersHorizontal, ShieldAlert, Sparkles, CheckCircle2 } from 'lucide-react';
import { IndicatorDetail } from '../../types';

interface IndicatorConceptModalProps {
  indicator: IndicatorDetail | null;
  onClose: () => void;
  onOpenLesson?: (lessonId: string) => void;
  onOpenSimulator?: () => void;
}

export const IndicatorConceptModal: React.FC<IndicatorConceptModalProps> = ({
  indicator,
  onClose,
  onOpenLesson,
  onOpenSimulator
}) => {
  if (!indicator) return null;

  return (
    <div
      id="indicator-concept-modal"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md max-h-[85vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl text-slate-200 relative">
        {/* Mobile handle */}
        <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1 mb-2 sm:hidden" />

        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800/80 pb-3">
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-purple-500/15 text-purple-300 border border-purple-500/30">
              Konsep Edukatif TRDS
            </span>
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
              <span>{indicator.conceptTitle || indicator.name}</span>
            </h3>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white transition"
            aria-label="Tutup"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current reading summary */}
        <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[11px] text-slate-400 block">Status Pembacaan Saat Ini:</span>
            <span className="text-xs font-bold text-emerald-400 font-mono">{indicator.status}</span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-400 block">Nilai Nilai:</span>
            <span className="text-xs font-bold text-white font-mono">{indicator.value}</span>
          </div>
        </div>

        {/* Concept Description */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Apa yang Diukur oleh Indikator Ini?
          </h4>
          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3 rounded-2xl border border-slate-800/80">
            {indicator.conceptSummary}
          </p>
        </div>

        {/* Key rules for virtual practice */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Prinsip Membaca & Menghindari Bias
          </h4>
          <div className="space-y-2 text-xs">
            <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/60">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span className="text-slate-300">
                <strong>Gunakan Konfirmasi Multi-Indikator:</strong> Jangan pernah mengambil keputusan hanya dari satu garis atau angka osilator.
              </span>
            </div>

            <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/60">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span className="text-slate-300">
                <strong>Waspadai Tren Kuat:</strong> Dalam tren yang sangat impulsif, indikator seperti RSI dapat bertahan di area ekstrem dalam waktu lama tanpa berbalik.
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 space-y-2">
          {indicator.lessonId && onOpenLesson && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenLesson(indicator.lessonId!);
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition"
            >
              <BookOpen className="w-4 h-4" />
              <span>Buka Modul Pembelajaran Lengkap</span>
            </button>
          )}

          {onOpenSimulator && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenSimulator();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition"
            >
              <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
              <span>Latih Membaca Indikator di Simulator</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
