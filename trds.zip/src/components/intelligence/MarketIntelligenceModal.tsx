import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  Sparkles,
  Bot,
  SlidersHorizontal,
  BookOpen,
  TrendingUp,
  TrendingDown,
  Activity,
  ShieldAlert,
  HelpCircle,
  RefreshCw,
  Info,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Crown,
  Lock,
  Compass,
  Layers,
  Clock,
  BarChart2,
  AlertTriangle
} from 'lucide-react';
import { Asset, IndicatorDetail } from '../../types';
import { calculateMarketIntelligence } from '../../services/marketIntelligenceService';
import { marketDataService } from '../../services/marketDataService';
import { MarketQuote, MarketDataStatus } from '../../types/marketData';
import { MarketDataStatusBadge } from './MarketDataStatusBadge';
import { IndicatorConceptModal } from './IndicatorConceptModal';
import { formatMarketPairSymbol } from '../../utils/formatters';

interface MarketIntelligenceModalProps {
  isOpen: boolean;
  asset: Asset | null;
  allAssets: Asset[];
  isPremium?: boolean;
  onClose: () => void;
  onSelectAsset?: (asset: Asset) => void;
  onOpenSimulator: (assetId: string) => void;
  onAskAi: (asset: Asset, intelligence: any) => void;
  onOpenLesson?: (lessonId: string) => void;
  onOpenPremiumPaywall?: (featureName: string) => void;
}

export const MarketIntelligenceModal: React.FC<MarketIntelligenceModalProps> = ({
  isOpen,
  asset,
  allAssets,
  isPremium = false,
  onClose,
  onSelectAsset,
  onOpenSimulator,
  onAskAi,
  onOpenLesson,
  onOpenPremiumPaywall
}) => {
  // Current active asset state (allows switching assets inside the modal)
  const [activeAssetId, setActiveAssetId] = useState<string>(asset?.id || (allAssets[0]?.id ?? 'btc'));
  const [selectedConceptIndicator, setSelectedConceptIndicator] = useState<IndicatorDetail | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [showFullAnalysis, setShowFullAnalysis] = useState<boolean>(false);
  const [quote, setQuote] = useState<MarketQuote | null>(null);
  const [isLoadingQuote, setIsLoadingQuote] = useState<boolean>(false);

  // Sync activeAssetId when prop asset changes
  React.useEffect(() => {
    if (asset?.id) {
      setActiveAssetId(asset.id);
    }
  }, [asset?.id]);

  const activeAsset = useMemo(() => {
    return allAssets.find(a => a.id === activeAssetId) || asset || allAssets[0];
  }, [allAssets, activeAssetId, asset]);

  // Load quote from MarketDataService
  useEffect(() => {
    let isMounted = true;
    const loadMarketQuote = async () => {
      if (!activeAsset) return;
      setIsLoadingQuote(true);
      try {
        const q = await marketDataService.getQuote(activeAsset.symbol);
        if (isMounted) {
          setQuote(q);
        }
      } catch {
        // Handled within marketDataService
      } finally {
        if (isMounted) {
          setIsLoadingQuote(false);
        }
      }
    };
    loadMarketQuote();
    return () => {
      isMounted = false;
    };
  }, [activeAsset?.symbol, refreshKey]);

  // Compute market intelligence data using quote if available or activeAsset
  const intelligence = useMemo(() => {
    const source = quote || activeAsset;
    if (!source) return null;
    return calculateMarketIntelligence(source);
  }, [quote, activeAsset]);

  if (!isOpen || !activeAsset || !intelligence) return null;

  const currentStatus: MarketDataStatus = isRefreshing || isLoadingQuote
    ? 'UPDATING'
    : (quote?.dataStatus || 'SIMULATED');

  const displayPrice = quote && quote.price > 0 ? quote.price : activeAsset.price;
  const displayChange = quote ? quote.change24h : activeAsset.change24h;
  const isPositive = displayChange >= 0;

  const marketCondition = intelligence.advancedCondition || (intelligence.trend === 'Bullish' ? 'BULLISH' : intelligence.trend === 'Bearish' ? 'BEARISH' : 'NEUTRAL');

  const handleRefreshData = async () => {
    if (!activeAsset) return;
    setIsRefreshing(true);
    try {
      const freshQuote = await marketDataService.getQuote(activeAsset.symbol, { forceRefresh: true });
      setQuote(freshQuote);
      setRefreshKey(prev => prev + 1);
    } catch {
      // Fallback
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleSelectAsset = (newAsset: Asset) => {
    setActiveAssetId(newAsset.id);
    if (onSelectAsset) {
      onSelectAsset(newAsset);
    }
  };

  // Helper styling for condition badges
  const getConditionColor = (cond: string) => {
    switch (cond) {
      case 'BULLISH':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'BEARISH':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
      case 'MIXED':
        return 'bg-purple-500/15 text-purple-400 border-purple-500/30';
      case 'NEUTRAL':
      default:
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
    }
  };

  // Helper styling for risk badges
  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'VERY HIGH':
        return 'bg-rose-600/20 text-rose-400 border-rose-500/40';
      case 'HIGH':
        return 'bg-rose-500/15 text-rose-300 border-rose-500/30';
      case 'MODERATE':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      case 'LOW':
      default:
        return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
    }
  };

  // Helper styling for momentum
  const getMomentumColor = (mom: string) => {
    if (mom.includes('Positive')) return 'text-emerald-400';
    if (mom.includes('Negative')) return 'text-rose-400';
    return 'text-slate-300';
  };

  return (
    <>
      <div
        id="trds-market-intelligence-modal"
        className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="market-intelligence-title"
      >
        <div className="w-full max-w-md max-h-[92vh] bg-slate-900 border border-slate-800 rounded-t-[32px] sm:rounded-3xl p-5 overflow-y-auto overflow-x-hidden space-y-4 shadow-2xl text-slate-100 relative">
          {/* Top handle bar */}
          <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1 mb-2 sm:hidden" />

          {/* Ambient subtle atmospheric glow behind hero */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 w-72 sm:w-84 h-28 bg-gradient-to-b from-cyan-500/15 via-sky-600/10 to-transparent blur-3xl pointer-events-none rounded-full" />

          {/* Top Bar Navigation: Badge + Controls */}
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 flex items-center gap-1.5 shadow-sm">
                <Compass className="w-3 h-3 text-cyan-400" />
                <span>TRDS Intelligence</span>
              </span>
              <MarketDataStatusBadge status={currentStatus} isStale={quote?.isStale} />
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={handleRefreshData}
                disabled={isRefreshing}
                className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition"
                aria-label="Perbarui Analisis"
                title="Perbarui Analisis"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
              </button>

              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white transition"
                aria-label="Tutup Market Pulse"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* HERO HEADER: MARKET PULSE */}
          <div className="relative pt-1 pb-1 space-y-1.5 animate-in fade-in slide-in-from-bottom-2 duration-300 ease-out">
            <div className="absolute -inset-x-2 top-1 h-12 bg-gradient-to-r from-cyan-500/20 via-sky-500/15 to-blue-700/15 blur-xl rounded-full pointer-events-none -z-10" />

            <h1
              id="market-pulse-hero-title"
              className="text-[32px] xs:text-[35px] sm:text-[38px] font-[800] leading-[1.05] tracking-[0.02em] uppercase bg-gradient-to-r from-[#00F0FF] via-[#0284c7] to-[#1e3a8a] bg-clip-text text-transparent select-none drop-shadow-[0_2px_14px_rgba(0,240,255,0.22)]"
            >
              MARKET PULSE
            </h1>

            <p className="text-[14px] sm:text-[15px] font-medium text-slate-300/90 leading-tight">
              Apa yang sedang terjadi di pasar?
            </p>

            <div className="flex items-center gap-1.5 pt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400/80 animate-pulse" />
              <span className="text-[11px] sm:text-[12px] font-mono tracking-wider text-cyan-400/80 font-medium">
                Powered by TRDS Analysis
              </span>
            </div>
          </div>

          {/* Horizontal Instrument Selector */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between px-0.5">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block">
                Pilih Instrumen Pasar:
              </span>
              <span className="text-[10px] text-slate-500 font-mono flex items-center gap-0.5">
                <span>Geser</span>
                <ChevronRight className="w-3 h-3 text-cyan-400/60" />
              </span>
            </div>
            <div className="relative -mx-1">
              <div
                id="market-pulse-asset-selector"
                className="flex items-center gap-2 overflow-x-auto pb-1.5 pt-0.5 px-1 scrollbar-none overscroll-x-contain touch-pan-x"
              >
                {allAssets.map(a => {
                  const isCurrent = a.id === activeAsset.id;
                  const displaySymbol = formatMarketPairSymbol(a.symbol);
                  return (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => handleSelectAsset(a)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 whitespace-nowrap transition-all duration-150 flex items-center gap-1.5 border active:scale-95 ${
                        isCurrent
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-sm shadow-cyan-500/15'
                          : 'bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-800/80'
                      }`}
                    >
                      <span className="font-mono tracking-tight">{displaySymbol}</span>
                      <span
                        className={`text-[10px] font-semibold ${
                          a.change24h >= 0 ? 'text-emerald-400' : 'text-red-400'
                        }`}
                      >
                        {a.change24h >= 0 ? '+' : ''}{a.change24h}%
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* MARKET SNAPSHOT - Curiosity Trigger */}
          <div
            id="market-pulse-snapshot-card"
            className="p-4 rounded-2xl bg-gradient-to-br from-slate-950/95 via-slate-900 to-cyan-950/25 border border-cyan-500/30 shadow-lg space-y-3 relative overflow-hidden"
          >
            {/* Instrument Price Line */}
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-base font-black text-white tracking-tight">
                    {formatMarketPairSymbol(activeAsset.symbol)}
                  </span>
                  <span className="text-xs text-slate-400">({activeAsset.name})</span>
                </div>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span className="text-2xl font-black text-white font-mono tracking-tight">
                    ${displayPrice.toLocaleString('en-US', {
                      minimumFractionDigits: displayPrice < 1 ? 4 : 2,
                      maximumFractionDigits: displayPrice < 1 ? 4 : 2
                    })}
                  </span>
                  <span
                    className={`text-xs font-bold inline-flex items-center gap-0.5 ${
                      isPositive ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {isPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                    {isPositive ? '+' : ''}{displayChange}%
                  </span>
                </div>
              </div>

              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700/60 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Snapshot
              </span>
            </div>

            {/* Timestamp & Data Status Bar */}
            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono px-2.5 py-1.5 rounded-xl bg-slate-900/70 border border-slate-800/80">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Clock className="w-3 h-3 text-cyan-400" />
                <span>Last Updated: {intelligence.lastUpdated}</span>
              </span>
              <span className="font-bold text-[10px]">
                {currentStatus === 'LIVE' ? (
                  <span className="text-emerald-400 font-black">LIVE MARKET DATA</span>
                ) : currentStatus === 'STALE' ? (
                  <span className="text-amber-400 font-black">STALE DATA</span>
                ) : currentStatus === 'UNAVAILABLE' ? (
                  <span className="text-rose-400 font-black">DATA UNAVAILABLE</span>
                ) : currentStatus === 'UPDATING' ? (
                  <span className="text-sky-400 font-black">UPDATING...</span>
                ) : (
                  <span className="text-slate-300 font-bold">DATA SIMULASI</span>
                )}
              </span>
            </div>

            {/* Stale or Unavailable Data Warning */}
            {quote?.isStale && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs animate-in fade-in duration-200">
                <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
                <span className="leading-snug">
                  <strong>Peringatan Stale Data:</strong> Umpan data belum diperbarui dari penyedia feed. Informasi harga mungkin tidak mutakhir.
                </span>
              </div>
            )}
            {currentStatus === 'UNAVAILABLE' && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs animate-in fade-in duration-200">
                <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
                <span className="leading-snug">
                  <strong>Data Unavailable:</strong> Umpan data untuk {formatMarketPairSymbol(activeAsset.symbol)} sementara tidak dapat diakses.
                </span>
              </div>
            )}

            {/* Market Condition Row */}
            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
                  MARKET CONDITION
                </span>
                <div
                  className={`px-3 py-1 rounded-lg border text-xs font-black uppercase tracking-wider flex items-center gap-1.5 ${getConditionColor(
                    marketCondition
                  )}`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>{marketCondition}</span>
                </div>
              </div>

              {/* Curiosity trigger: "Kenapa?" */}
              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-bold text-cyan-300 block">
                    &ldquo;Kenapa?&rdquo;
                  </span>
                  <span className="text-[11px] text-slate-400 block leading-tight">
                    Mengapa {formatMarketPairSymbol(activeAsset.symbol)} dinilai {marketCondition}?
                  </span>
                </div>

                <button
                  type="button"
                  id="btn-lihat-analisis"
                  onClick={() => setShowFullAnalysis(prev => !prev)}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 hover:from-cyan-400 hover:to-sky-500 text-slate-950 font-black text-xs transition flex items-center gap-1.5 shadow-md shadow-cyan-500/20 active:scale-95 shrink-0"
                >
                  <span>{showFullAnalysis ? 'TUTUP DETAIL' : 'LIHAT ANALISIS'}</span>
                  {showFullAnalysis ? (
                    <ChevronUp className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Full Detailed Analysis Section - Controlled by Curiosity Toggle */}
          {showFullAnalysis ? (
            <div id="full-analysis-section" className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
              {/* 1. TRDS MARKET VIEW (Multi-Factor Overview) */}
              <div
                id="trds-market-view-card"
                className="p-4 rounded-2xl bg-gradient-to-br from-slate-950/95 via-slate-900 to-cyan-950/30 border border-cyan-500/40 space-y-3 shadow-lg"
              >
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                      <Compass className="w-4 h-4" />
                    </div>
                    <div>
                      <h2 className="text-xs font-black uppercase tracking-wider text-white">
                        TRDS Market View
                      </h2>
                      <span className="text-[10px] text-slate-400 block">
                        Sintesis Multi-Faktor Objektif
                      </span>
                    </div>
                  </div>

                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${getConditionColor(
                      marketCondition
                    )}`}
                  >
                    {marketCondition}
                  </span>
                </div>

                {/* 6-Grid Multi-Factor Metrics */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {/* Condition */}
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90">
                    <span className="text-[10px] text-slate-400 block uppercase font-mono mb-0.5">
                      1. Market Condition
                    </span>
                    <span className={`font-black text-xs ${getConditionColor(marketCondition)} px-1.5 py-0.5 rounded inline-block`}>
                      {marketCondition}
                    </span>
                  </div>

                  {/* Momentum */}
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90">
                    <span className="text-[10px] text-slate-400 block uppercase font-mono mb-0.5">
                      2. Momentum (24h)
                    </span>
                    <span className={`font-bold text-xs ${getMomentumColor(intelligence.advancedMomentum)}`}>
                      {intelligence.advancedMomentum}
                    </span>
                    <span className="text-[10px] text-slate-400 block font-mono">
                      {isPositive ? '+' : ''}{displayChange}%
                    </span>
                  </div>

                  {/* Volatility */}
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90">
                    <span className="text-[10px] text-slate-400 block uppercase font-mono mb-0.5">
                      3. Volatilitas
                    </span>
                    <span
                      className={`font-bold text-xs ${
                        intelligence.advancedVolatility === 'EXTREME' || intelligence.advancedVolatility === 'HIGH'
                          ? 'text-rose-400'
                          : intelligence.advancedVolatility === 'MEDIUM'
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {intelligence.advancedVolatility}
                    </span>
                    <span className="text-[10px] text-slate-500 block truncate">
                      {intelligence.volatilityExplanation}
                    </span>
                  </div>

                  {/* Trend Context */}
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90">
                    <span className="text-[10px] text-slate-400 block uppercase font-mono mb-0.5">
                      4. Konteks Tren
                    </span>
                    <span className="font-bold text-xs text-cyan-300 block truncate">
                      {intelligence.trendContext}
                    </span>
                    <span className="text-[10px] text-slate-500 block truncate">
                      Relatif thd Moving Average
                    </span>
                  </div>

                  {/* Market Strength */}
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90">
                    <span className="text-[10px] text-slate-400 block uppercase font-mono mb-0.5">
                      5. Market Strength
                    </span>
                    <span className="font-bold text-xs text-slate-200 block">
                      {intelligence.marketStrengthCategory}
                    </span>
                    <span className="text-[9px] text-slate-500 block">
                      Skor teknikal {intelligence.score}/100
                    </span>
                  </div>

                  {/* Risk Level */}
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90">
                    <span className="text-[10px] text-slate-400 block uppercase font-mono mb-0.5">
                      6. Risk Context
                    </span>
                    <span className={`font-black text-xs px-1.5 py-0.5 rounded border inline-block ${getRiskColor(intelligence.riskLevel)}`}>
                      {intelligence.riskLevel}
                    </span>
                  </div>
                </div>

                {/* Honest Order Book note */}
                <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800/80 text-[10px] text-slate-400 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>
                    <strong>Catatan Likuiditas:</strong> {intelligence.orderBookPressureNote}.
                  </span>
                </div>

                {/* Synthesis summary text */}
                <p className="text-[11px] text-slate-300 leading-relaxed bg-slate-900/70 p-2.5 rounded-xl border border-slate-800">
                  {intelligence.marketView.whyExplanation}
                </p>
              </div>

              {/* 2. WHY THIS CONDITION? (Alasan Edukatif Spesifik) */}
              <div
                id="why-this-condition-section"
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3"
              >
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-xl bg-blue-500/15 text-blue-400 border border-blue-500/30">
                    <HelpCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                      Mengapa Kondisi &ldquo;{marketCondition}&rdquo; Muncul?
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      Rincian faktor data yang mendasari kesimpulan
                    </span>
                  </div>
                </div>

                {/* Bullet-point reasons */}
                <div className="space-y-2">
                  {intelligence.conditionReasons.map((reason, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-slate-900/50 border border-slate-800/80 flex items-start gap-2 text-xs"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0 mt-1.5" />
                      <span className="text-slate-200 text-[11px] leading-relaxed">
                        {reason}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Factor details */}
                <div className="space-y-2 text-xs pt-1 border-t border-slate-800/60">
                  {intelligence.whyAnalysis.factors.map((factor, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded-xl bg-slate-900/30 border border-slate-850 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-300 text-[11px]">{factor.title}</span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                          {factor.statusBadge}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-relaxed">{factor.detail}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* 3. SUPPORT & RESISTANCE (Estimasi Teknikal Bukan Jaminan) */}
              <div
                id="support-resistance-section"
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
                      <Layers className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                        Support & Resistance
                      </h3>
                      <span className="text-[10px] text-slate-400">
                        Area minat teknikal berbasis data historis
                      </span>
                    </div>
                  </div>

                  <span className="text-[9px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                    Estimasi
                  </span>
                </div>

                {intelligence.hasInsufficientSupportResistance ? (
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center space-y-1">
                    <span className="text-xs font-bold text-amber-400">Insufficient Data</span>
                    <p className="text-[11px] text-slate-400">
                      Histori data harga belum mencukupi untuk menghitung level support dan resistance yang reliabel.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 text-xs">
                    <div className="grid grid-cols-2 gap-2">
                      {/* Immediate Support */}
                      <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-emerald-400 uppercase font-bold tracking-wider">
                            Support Terdekat (Immediate)
                          </span>
                        </div>
                        <span className="text-base font-black text-white font-mono block">
                          ${intelligence.support.toLocaleString('en-US', {
                            minimumFractionDigits: intelligence.support < 1 ? 4 : 2,
                            maximumFractionDigits: intelligence.support < 1 ? 4 : 2
                          })}
                        </span>
                        <p className="text-[10px] text-slate-300 leading-snug">
                          {intelligence.supportExplanation}
                        </p>
                      </div>

                      {/* Immediate Resistance */}
                      <div className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/30 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-rose-400 uppercase font-bold tracking-wider">
                            Resistance Terdekat (Immediate)
                          </span>
                        </div>
                        <span className="text-base font-black text-white font-mono block">
                          ${intelligence.resistance.toLocaleString('en-US', {
                            minimumFractionDigits: intelligence.resistance < 1 ? 4 : 2,
                            maximumFractionDigits: intelligence.resistance < 1 ? 4 : 2
                          })}
                        </span>
                        <p className="text-[10px] text-slate-300 leading-snug">
                          {intelligence.resistanceExplanation}
                        </p>
                      </div>
                    </div>

                    {/* Strong Support & Strong Resistance (Secondary Levels) */}
                    <div className="grid grid-cols-2 gap-2">
                      <div className="p-2.5 rounded-xl bg-slate-900/60 border border-emerald-900/30 space-y-1">
                        <span className="text-[9px] text-emerald-300/80 uppercase font-bold tracking-wider block">
                          Support Kuat (Mayor)
                        </span>
                        <span className="text-xs font-mono font-bold text-slate-200 block">
                          ${(intelligence.support * 0.982).toLocaleString('en-US', {
                            minimumFractionDigits: intelligence.support < 1 ? 4 : 2,
                            maximumFractionDigits: intelligence.support < 1 ? 4 : 2
                          })}
                        </span>
                        <p className="text-[9px] text-slate-400">
                          Batas psikologis & swing bawah historis lebih luas.
                        </p>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-900/60 border border-rose-900/30 space-y-1">
                        <span className="text-[9px] text-rose-300/80 uppercase font-bold tracking-wider block">
                          Resistance Kuat (Mayor)
                        </span>
                        <span className="text-xs font-mono font-bold text-slate-200 block">
                          ${(intelligence.resistance * 1.018).toLocaleString('en-US', {
                            minimumFractionDigits: intelligence.resistance < 1 ? 4 : 2,
                            maximumFractionDigits: intelligence.resistance < 1 ? 4 : 2
                          })}
                        </span>
                        <p className="text-[9px] text-slate-400">
                          Zona pasokan atas historis jika breakout terjadi.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Crucial Educational Disclaimer */}
                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-[10px] text-slate-400 leading-relaxed flex items-start gap-2">
                  <Info className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Penting & Edukatif:</strong> Level Support dan Resistance bersifat dinamis berbasis riwayat harga. <em>BUKAN level pembalikan arah yang dijamin pasti (not guaranteed reversal levels)</em>. Pelajari reaksi harga saat mendekati level ini di simulator.
                  </span>
                </div>
              </div>

              {/* 4. VOLUME CONTEXT (Transparan: Tanpa Rekayasa Volume) */}
              <div
                id="volume-context-section"
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
                      <BarChart2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                        Konteks Volume Likuiditas
                      </h3>
                      <span className="text-[10px] text-slate-400">
                        Partisipasi transaksi dalam 24 jam terakhir
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                      intelligence.volumeContext === 'Increasing'
                        ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                        : intelligence.volumeContext === 'Decreasing'
                        ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                        : intelligence.volumeContext === 'Average'
                        ? 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}
                  >
                    {intelligence.volumeContext === 'Unavailable' ? 'Unavailable' : intelligence.volumeContext}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-2 text-xs">
                  {/* Volume Metrics Grid */}
                  <div className="grid grid-cols-3 gap-2 pb-2 border-b border-slate-800/60 text-center">
                    <div className="p-1.5 rounded-lg bg-slate-950/60 border border-slate-850">
                      <span className="text-[9px] text-slate-400 block uppercase font-mono">Status Volume</span>
                      <span className="text-[11px] font-bold text-white block mt-0.5">
                        {intelligence.volumeContext === 'Unavailable' ? 'Unavailable' : intelligence.volumeContext}
                      </span>
                    </div>

                    <div className="p-1.5 rounded-lg bg-slate-950/60 border border-slate-850">
                      <span className="text-[9px] text-slate-400 block uppercase font-mono">Volume vs Avg</span>
                      <span className="text-[11px] font-bold text-slate-200 block mt-0.5">
                        {intelligence.volumeContext === 'Unavailable'
                          ? 'Not enough data'
                          : intelligence.volumeContext === 'Increasing'
                          ? 'Di Atas Rata-rata'
                          : intelligence.volumeContext === 'Decreasing'
                          ? 'Di Bawah Rata-rata'
                          : 'Normal (Rata-rata)'}
                      </span>
                    </div>

                    <div className="p-1.5 rounded-lg bg-slate-950/60 border border-slate-850">
                      <span className="text-[9px] text-slate-400 block uppercase font-mono">Konfirmasi</span>
                      <span className="text-[11px] font-bold text-slate-200 block mt-0.5">
                        {intelligence.volumeContext === 'Unavailable'
                          ? 'Not enough data'
                          : intelligence.volumeContext === 'Increasing'
                          ? 'Konfirmasi Tinggi'
                          : intelligence.volumeContext === 'Decreasing'
                          ? 'Konfirmasi Lemah'
                          : 'Cukup'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Volume Perdagangan 24j:</span>
                    <span className="font-mono font-bold text-white">
                      {intelligence.volumeContext === 'Unavailable' ? 'Unavailable' : intelligence.volume}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    {intelligence.volumeContextExplanation}
                  </p>
                </div>

                {intelligence.volumeContext === 'Unavailable' && (
                  <p className="text-[10px] text-slate-500 italic">
                    *TRDS tidak merekayasa volume pasar semu ketika data umpan tidak tersedia (menampilkan &ldquo;Unavailable&rdquo; / &ldquo;Not enough data&rdquo; secara transparan).
                  </p>
                )}
              </div>

              {/* 5. DATA QUALITY & ANALYSIS CONFIDENCE */}
              <div
                id="data-quality-confidence-section"
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-sky-500/15 text-sky-400 border border-sky-500/30">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                        Kualitas Data & Confidence
                      </h3>
                      <span className="text-[10px] text-slate-400">
                        Integritas umpan data pasar yang dianalisis
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                      intelligence.analysisConfidence === 'HIGH DATA CONFIDENCE'
                        ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                        : intelligence.analysisConfidence === 'MEDIUM DATA CONFIDENCE'
                        ? 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30'
                        : 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                    }`}
                  >
                    {intelligence.analysisConfidence}
                  </span>
                </div>

                {/* Data Quality Report Grid */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded-xl bg-slate-900/50 border border-slate-800">
                    <span className="text-[9px] text-slate-400 uppercase font-mono block">Status Feed:</span>
                    <span className="font-bold text-white text-[11px] block mt-0.5">
                      {intelligence.dataQuality.statusLabel}
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/50 border border-slate-800">
                    <span className="text-[9px] text-slate-400 uppercase font-mono block">Sumber Feed:</span>
                    <span className="font-mono text-slate-200 text-[11px] block mt-0.5 capitalize">
                      {intelligence.dataQuality.source}
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/50 border border-slate-800">
                    <span className="text-[9px] text-slate-400 uppercase font-mono block">Pembaruan Terakhir:</span>
                    <span className="font-mono text-slate-200 text-[11px] block mt-0.5">
                      {intelligence.dataQuality.lastUpdated}
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/50 border border-slate-800">
                    <span className="text-[9px] text-slate-400 uppercase font-mono block">Freshness:</span>
                    <span
                      className={`text-[11px] font-bold block mt-0.5 ${
                        intelligence.dataQuality.isStale ? 'text-amber-400' : 'text-emerald-400'
                      }`}
                    >
                      {intelligence.dataQuality.freshness}
                    </span>
                  </div>
                </div>

                {/* Analysis Confidence Meaning Disclaimer */}
                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-[10px] text-slate-400 leading-relaxed flex items-start gap-2">
                  <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Definisi Confidence:</strong> Tingkat keyakinan (Confidence) merefleksikan kualitas, kelengkapan, dan konsistensi data pasar yang tersedia — <em>BUKAN probabilitas atau kepastian pergerakan arah harga di masa depan</em>.
                  </span>
                </div>
              </div>

              {/* 6. EDUCATIONAL SCENARIOS ANALYSIS (Analisis Skenario Bersyarat) */}
              <div
                id="educational-scenarios-section"
                className="p-4 rounded-2xl bg-gradient-to-br from-slate-950/95 via-slate-900 to-indigo-950/30 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-purple-500/15 text-purple-400 border border-purple-500/30">
                      <Compass className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                        Analisis Skenario Pasar
                      </h3>
                      <span className="text-[10px] text-slate-400">
                        Pemodelan bersyarat (If-Then Educational Framework)
                      </span>
                    </div>
                  </div>

                  <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/30">
                    Kemungkinan Edukasi
                  </span>
                </div>

                {/* 3 Scenario Cards */}
                <div className="space-y-2.5">
                  {intelligence.scenarios.map((sc, idx) => {
                    const isBull = sc.type === 'Bullish Scenario';
                    const isBear = sc.type === 'Bearish Scenario';
                    return (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl border space-y-1.5 text-xs ${
                          isBull
                            ? 'bg-emerald-950/15 border-emerald-500/30'
                            : isBear
                            ? 'bg-rose-950/15 border-rose-500/30'
                            : 'bg-amber-950/15 border-amber-500/30'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className={`font-bold text-[11px] uppercase tracking-wide ${
                              isBull ? 'text-emerald-400' : isBear ? 'text-rose-400' : 'text-amber-400'
                            }`}
                          >
                            {sc.title}
                          </span>
                        </div>

                        <p className="text-[11px] text-slate-200 leading-relaxed">
                          <strong>Kondisi Pendukung:</strong> {sc.supportingConditions}
                        </p>

                        <div className="p-2 rounded-lg bg-slate-900/70 border border-slate-800/80 text-[10px] text-slate-300 flex items-start gap-1.5">
                          <span className="text-cyan-400 font-bold shrink-0">Amati:</span>
                          <span>{sc.keyEducationalWatchpoint}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-[10px] text-slate-400 leading-relaxed">
                  <strong>Catatan Edukatif:</strong> Skenario di atas merupakan kemungkinan berbasis kondisi teknikal, <em>BUKAN ramalan masa depan</em>. Selalu miliki rencana skenario alternatif dan manajemen risiko sebelum mengambil keputusan simulasi.
                </div>
              </div>

              {/* 7. RISK CONTEXT & NO DIRECT BUY/SELL INSTRUCTION */}
              <div
                id="risk-context-section"
                className="p-4 rounded-2xl bg-slate-950/80 border border-rose-500/30 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-rose-500/15 text-rose-400 border border-rose-500/30">
                      <ShieldAlert className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                        Konteks Risiko (Risk Context)
                      </h3>
                      <span className="text-[10px] text-slate-400">
                        Evaluasi tingkat risiko edukasi
                      </span>
                    </div>
                  </div>

                  <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border ${getRiskColor(intelligence.riskLevel)}`}>
                    Level: {intelligence.riskLevel}
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-rose-950/20 border border-rose-900/40 text-rose-200/90 leading-relaxed text-[11px]">
                    <strong>Catatan Volatilitas:</strong> {intelligence.riskContext.volatilityNote}
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-slate-400 text-[11px] leading-relaxed">
                    <strong>Ketidakpastian Pasar:</strong> {intelligence.riskContext.uncertaintyNote}
                  </div>

                  <div className="space-y-1 pt-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      Faktor Risiko Terdeteksi:
                    </span>
                    {intelligence.riskPrimaryReasons.map((rf, i) => (
                      <div key={i} className="flex items-start gap-1.5 text-[11px] text-slate-300">
                        <span className="text-rose-400 shrink-0">•</span>
                        <span>{rf}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Explicit Guarantee Prohibition */}
                <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-[10px] text-slate-400 leading-relaxed flex items-start gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Tidak Ada Jaminan Keuntungan:</strong> TRDS tidak memberikan jaminan profit dan tidak mengeluarkan instruksi beli (BUY) atau jual (SELL) langsung. Setiap analisis ditujukan murni untuk melatih disiplin dan literasi teknikal.
                  </span>
                </div>
              </div>

              {/* 8. TECHNICAL INDICATORS BREAKDOWN (With STATUS + PENJELASAN + PELAJARI KONSEP INI) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Rincian Indikator Teknikal</span>
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      Nilai matematis dan posisi harga
                    </span>
                  </div>
                </div>

                <div className="space-y-2.5">
                  {intelligence.indicators.map(ind => (
                    <div
                      key={ind.code}
                      className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-slate-200">{ind.name}</span>
                          </div>
                          <span className="text-[11px] font-bold text-cyan-400 font-mono block mt-0.5">
                            {ind.status}
                          </span>
                        </div>

                        <div className="text-right">
                          <span className="text-xs font-bold text-white font-mono px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-800">
                            {ind.value}
                          </span>
                        </div>
                      </div>

                      <p className="text-[11px] text-slate-300 leading-relaxed bg-slate-900/40 p-2.5 rounded-xl border border-slate-850">
                        {ind.explanation}
                      </p>

                      <div className="flex items-center justify-end pt-0.5">
                        <button
                          type="button"
                          onClick={() => setSelectedConceptIndicator(ind)}
                          className="text-[11px] font-bold text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-cyan-500/10 transition"
                        >
                          <BookOpen className="w-3 h-3" />
                          <span>Pelajari Konsep Ini</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 9. MARKET CONDITION SCORE */}
              <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2 relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white uppercase tracking-wider">
                          Market Condition Score
                        </span>
                        <span className="text-[9px] font-black uppercase px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                          Educational Analysis
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">Sintesis matematis indikator teknikal</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xl font-black text-amber-300 font-mono">
                      {intelligence.score}
                    </span>
                    <span className="text-xs text-slate-500 font-mono"> / 100</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-[11px] text-slate-400 leading-relaxed flex items-start gap-2">
                  <Info className="w-4 h-4 text-amber-400/90 shrink-0 mt-0.5" />
                  <span>
                    <strong>Bukan prediksi keuntungan:</strong> Skor ini adalah hasil komputasi matematis indikator (RSI, Moving Average, rentang volatilitas). Angka ini mengukur keselarasan teknikal saat ini, bukan jaminan arah naik/turun harga.
                  </span>
                </div>
              </div>

              {/* 10. NO BLIND SIGNAL BANNER (Prominent & Visible) */}
              <div
                id="no-blind-signal-banner"
                className="p-3.5 rounded-2xl bg-slate-950/90 border border-emerald-500/40 text-xs space-y-1.5 shadow-sm"
              >
                <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span className="uppercase text-[11px] tracking-wider">
                    Prinsip TRDS: No Blind Signal
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  TRDS tidak pernah menampilkan sinyal beli/jual buta. Format edukasi kami adalah:
                  <strong className="text-white block mt-0.5">
                    Kondisi Pasar + Bukti Data + Ketidakpastian + Konteks Risiko + Konsep Edukasi
                  </strong>
                </p>
              </div>

              {/* Phase 6: RevenueCat Premium Deep Technical Insights Card */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-purple-950/30 border border-amber-500/30 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                      <Crown className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <span className="font-bold text-white block text-xs">TRDS Pro Intelligence</span>
                      <span className="text-[10px] text-amber-300/80">
                        {isPremium ? 'Status: Pro Aktif' : 'Akses Eksklusif RevenueCat'}
                      </span>
                    </div>
                  </div>

                  {!isPremium && onOpenPremiumPaywall && (
                    <button
                      type="button"
                      onClick={() => onOpenPremiumPaywall('TRDS Market Intelligence Pro')}
                      className="px-2.5 py-1 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] transition flex items-center gap-1 shadow-sm"
                    >
                      <Lock className="w-3 h-3" />
                      <span>Buka Pro</span>
                    </button>
                  )}
                </div>

                {isPremium ? (
                  <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-200">
                    ⭐ <strong>Analisis Mendalam:</strong> Volume profile intraday menunjukkan area Value Area High (VAH) berada di sekitar ${Math.round(intelligence.resistance * 0.99)}, menandakan konsentrasi likuiditas institusi pada pasar demo.
                  </div>
                ) : (
                  <p className="text-[10px] text-slate-400 leading-relaxed">
                    Pengguna gratis mendapatkan seluruh modul dasar dan analisis indikator lengkap. TRDS Pro membuka simulasi multi-timeframe correlation matrix.
                  </p>
                )}
              </div>

              {/* Last Updated Timestamp Footer */}
              <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800">
                <span>Terakhir diperbarui: {intelligence.lastUpdated}</span>
                <span className="font-mono">100% Saldo Virtual</span>
              </div>
            </div>
          ) : (
            /* Collapsed Curiosity Teaser Card */
            <div
              id="curiosity-preview-teaser-card"
              onClick={() => setShowFullAnalysis(true)}
              className="p-4 rounded-2xl bg-gradient-to-r from-slate-950/80 via-slate-900 to-indigo-950/30 border border-slate-800/80 hover:border-cyan-500/40 cursor-pointer transition text-center space-y-2 group shadow-sm"
              role="button"
              tabIndex={0}
            >
              <div className="flex items-center justify-center gap-1.5 text-cyan-400">
                <Sparkles className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">
                  Penasaran dengan data di balik {formatMarketPairSymbol(activeAsset.symbol)}?
                </span>
              </div>
              <p className="text-xs text-slate-400 group-hover:text-slate-300 leading-relaxed max-w-xs mx-auto">
                Pasar saat ini berstatus <strong className="text-white font-semibold">{marketCondition}</strong>. Buka analisis lengkap untuk melihat multi-faktor (Momentum, Volatilitas, Support/Resist, Skenario) dan konteks risiko.
              </p>
              <div className="pt-1">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-500/10 text-cyan-300 font-bold text-xs border border-cyan-500/30 group-hover:bg-cyan-500/20 group-hover:border-cyan-500/50 transition">
                  <span>Buka Analisis Lengkap</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          )}

          {/* INTEGRATION ACTION BUTTONS: TRDS AI & SIMULATOR */}
          <div className="space-y-2 pt-1 sticky bottom-0 bg-slate-900/95 backdrop-blur-md pb-1">
            <button
              id="btn-intelligence-ask-ai"
              type="button"
              onClick={() => {
                onClose();
                onAskAi(activeAsset, {
                  ...intelligence,
                  quote,
                  isStale: quote?.isStale,
                  dataStatus: currentStatus,
                  timestamp: quote?.timestamp || intelligence.timestamp,
                  changePercent24h: quote?.changePercent24h ?? intelligence.changePercent24h
                });
              }}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20 transition active:scale-98"
            >
              <Bot className="w-4 h-4" />
              <span>Jelaskan dengan TRDS AI</span>
            </button>

            <button
              id="btn-intelligence-open-simulator"
              type="button"
              onClick={() => {
                onClose();
                onOpenSimulator(activeAsset.id);
              }}
              className="w-full py-3 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition active:scale-98"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Uji di Simulator ({formatMarketPairSymbol(activeAsset.symbol)})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Concept Drawer/Modal for Learn Integration */}
      <IndicatorConceptModal
        indicator={selectedConceptIndicator}
        onClose={() => setSelectedConceptIndicator(null)}
        onOpenLesson={lessonId => {
          setSelectedConceptIndicator(null);
          onClose();
          if (onOpenLesson) {
            onOpenLesson(lessonId);
          }
        }}
        onOpenSimulator={() => {
          setSelectedConceptIndicator(null);
          onClose();
          onOpenSimulator(activeAsset.id);
        }}
      />
    </>
  );
};
