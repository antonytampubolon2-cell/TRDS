import React from 'react';
import { MarketDataStatus } from '../../types/marketData';
import { formatDataStatusLabel } from '../../utils/formatters';
import { RefreshCw, AlertTriangle, ShieldCheck, Database, Radio } from 'lucide-react';

interface MarketDataStatusBadgeProps {
  status: MarketDataStatus;
  isStale?: boolean;
  className?: string;
  size?: 'sm' | 'md';
}

export const MarketDataStatusBadge: React.FC<MarketDataStatusBadgeProps> = ({
  status,
  isStale = false,
  className = '',
  size = 'sm'
}) => {
  const effectiveStatus: MarketDataStatus = isStale ? 'STALE' : status;
  const label = formatDataStatusLabel(effectiveStatus);

  const sizeClasses = size === 'sm' ? 'text-[10px] px-2 py-0.5' : 'text-xs px-2.5 py-1';

  switch (effectiveStatus) {
    case 'LIVE':
      return (
        <span
          id="badge-market-status-live"
          className={`font-black tracking-wider uppercase rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/40 inline-flex items-center gap-1.5 shadow-sm shadow-emerald-500/10 ${sizeClasses} ${className}`}
          title="Umpan data langsung dari penyedia pasar terverifikasi"
        >
          <span className="relative flex h-1.5 w-1.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500" />
          </span>
          <Radio className="w-3 h-3 text-emerald-400" />
          <span>{label}</span>
        </span>
      );

    case 'UPDATING':
      return (
        <span
          id="badge-market-status-updating"
          className={`font-black tracking-wider uppercase rounded-full bg-sky-500/15 text-sky-300 border border-sky-500/30 inline-flex items-center gap-1.5 ${sizeClasses} ${className}`}
          title="Sedang menyinkronkan data pasar terbaru..."
        >
          <RefreshCw className="w-3 h-3 text-sky-400 animate-spin" />
          <span>{label}</span>
        </span>
      );

    case 'STALE':
      return (
        <span
          id="badge-market-status-stale"
          className={`font-black tracking-wider uppercase rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 inline-flex items-center gap-1.5 ${sizeClasses} ${className}`}
          title="Data belum diperbarui melampaui batas toleransi waktu"
        >
          <AlertTriangle className="w-3 h-3 text-amber-400" />
          <span>{label}</span>
        </span>
      );

    case 'UNAVAILABLE':
      return (
        <span
          id="badge-market-status-unavailable"
          className={`font-black tracking-wider uppercase rounded-full bg-rose-500/15 text-rose-300 border border-rose-500/30 inline-flex items-center gap-1.5 ${sizeClasses} ${className}`}
          title="Umpan data pasar untuk instrumen ini sementara tidak dapat diakses"
        >
          <AlertTriangle className="w-3 h-3 text-rose-400" />
          <span>{label}</span>
        </span>
      );

    case 'SIMULATED':
    default:
      return (
        <span
          id="badge-market-status-simulated"
          className={`font-bold tracking-wide uppercase rounded-full bg-slate-800/90 text-slate-300 border border-slate-700/80 inline-flex items-center gap-1.5 ${sizeClasses} ${className}`}
          title="Data simulasi edukatif untuk latihan virtual tanpa risiko modal nyata"
        >
          <Database className="w-3 h-3 text-cyan-400/80" />
          <span>{label}</span>
        </span>
      );
  }
};
