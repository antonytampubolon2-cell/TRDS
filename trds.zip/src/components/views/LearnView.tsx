import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  Award,
  CheckCircle2,
  Clock,
  ChevronRight,
  HelpCircle,
  Filter,
  Check,
  Search,
  Layers
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { LearningCategoryId, Lesson } from '../../types';
import { VirtualNoticeBanner } from '../common/VirtualNoticeBanner';
import { LearningProgressCard } from '../learn/LearningProgressCard';
import { CategoryFilter } from '../learn/CategoryFilter';
import { DailyChallengesCard } from '../learn/DailyChallengesCard';
import { AchievementPreviewCard } from '../learn/AchievementPreviewCard';
import { LessonModal } from '../learn/LessonModal';
import { QuizModal } from '../learn/QuizModal';
import { PremiumBadge } from '../premium/PremiumBadge';

export const LearnView: React.FC = () => {
  const {
    lessons,
    completedLessonIds,
    quizResults,
    openAchievementsModal,
    openDailyChallengesModal,
    filterCategory,
    setFilterCategory,
    activeLessonForModal,
    openLessonModal,
    closeLessonModal,
    activeQuizForModal,
    openQuizModal,
    closeQuizModal
  } = useApp();

  const [activeTrack, setActiveTrack] = useState<'all' | 'beginner' | 'intermediate' | 'advanced'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredLessons = lessons.filter(lesson => {
    // Category match
    if (filterCategory !== 'all' && lesson.categoryId !== filterCategory) {
      return false;
    }
    // Track match
    if (activeTrack !== 'all' && lesson.track !== activeTrack) {
      return false;
    }
    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = lesson.title.toLowerCase().includes(q);
      const matchSubtitle = lesson.subtitle.toLowerCase().includes(q);
      if (!matchTitle && !matchSubtitle) return false;
    }
    return true;
  });

  const handleStartQuizFromLesson = (lesson: Lesson) => {
    if (lesson.quiz) {
      closeLessonModal();
      openQuizModal(lesson, lesson.quiz);
    }
  };

  return (
    <div id="learn-view" className="space-y-4 pb-28 pt-1 px-4 max-w-md mx-auto">
      {/* 100% Virtual Notice Banner */}
      <VirtualNoticeBanner compact />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">Akademi TRDS</h1>
          <p className="text-xs text-slate-400">Pondasi edukasi trading & analisis finansial</p>
        </div>
        <button
          onClick={openAchievementsModal}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 text-xs font-bold hover:bg-amber-500/20 transition cursor-pointer"
        >
          <Award className="w-3.5 h-3.5" />
          <span>Prestasi</span>
        </button>
      </div>

      {/* Main Learning Progress & Stats Card */}
      <LearningProgressCard onOpenAchievements={openAchievementsModal} />

      {/* Daily Challenges Section */}
      <DailyChallengesCard onOpenModal={openDailyChallengesModal} />

      {/* Achievements Banner Preview */}
      <AchievementPreviewCard />

      {/* Category Horizontal Pills Filter */}
      <CategoryFilter
        selectedCategory={filterCategory}
        onSelectCategory={setFilterCategory}
        lessons={lessons}
        completedLessonIds={completedLessonIds}
      />

      {/* Track Filters and Search */}
      <div className="space-y-2 pt-1">
        <div className="flex gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs">
          {(
            [
              { id: 'all', label: 'Semua Track' },
              { id: 'beginner', label: 'Pemula' },
              { id: 'intermediate', label: 'Menengah' },
              { id: 'advanced', label: 'Lanjutan ★' }
            ] as const
          ).map(track => (
            <button
              key={track.id}
              onClick={() => setActiveTrack(track.id)}
              className={`flex-1 py-1.5 rounded-lg font-semibold transition text-[11px] ${
                activeTrack === track.id
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {track.label}
            </button>
          ))}
        </div>

        {/* Quick Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari topik modul (e.g. candlestick, risk, MA)..."
            className="w-full pl-8.5 pr-3 py-2 bg-slate-900/90 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white text-xs font-bold"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Lesson List Header */}
      <div className="flex items-center justify-between text-xs px-1 pt-1">
        <span className="font-semibold text-slate-300">Daftar Modul Pembelajaran</span>
        <span className="text-[11px] text-slate-400">{filteredLessons.length} Modul Ditampilkan</span>
      </div>

      {/* Lessons List */}
      <div className="space-y-3">
        {filteredLessons.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
            <BookOpen className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-xs font-semibold text-slate-300">Tidak ada modul yang cocok</p>
            <p className="text-[11px] text-slate-500">Coba ganti kata kunci pencarian atau filter kategori.</p>
            <button
              onClick={() => {
                setFilterCategory('all');
                setActiveTrack('all');
                setSearchQuery('');
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 text-emerald-400 text-xs font-medium hover:bg-slate-700 transition"
            >
              Reset Filter
            </button>
          </div>
        ) : (
          filteredLessons.map((lesson, idx) => {
            const isCompleted = completedLessonIds.includes(lesson.id);
            const quiz = lesson.quiz;
            const quizPassed = quiz ? quizResults[quiz.id]?.passed : false;

            return (
              <div
                key={lesson.id}
                id={`lesson-card-${lesson.id}`}
                onClick={() => openLessonModal(lesson)}
                className={`p-4 rounded-2xl border transition space-y-2.5 group cursor-pointer shadow-sm ${
                  isCompleted
                    ? 'bg-slate-900/60 border-emerald-500/25 hover:border-emerald-500/40'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Badges Row */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                      {lesson.track === 'beginner' ? 'Pemula' : lesson.track === 'advanced' ? 'Lanjutan' : 'Menengah'}
                    </span>
                    {lesson.isPremium && <PremiumBadge size="sm" />}
                    {isCompleted && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Selesai
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1 text-amber-400 text-xs font-bold shrink-0">
                    <Sparkles className="w-3 h-3" />
                    <span>+{lesson.xpReward} XP</span>
                  </div>
                </div>

                {/* Title & Subtitle */}
                <div>
                  <h3 className="text-sm font-bold text-white group-hover:text-emerald-400 transition leading-snug">
                    {idx + 1}. {lesson.title}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-0.5 leading-relaxed">
                    {lesson.subtitle}
                  </p>
                </div>

                {/* Footer: Read time, Quiz Indicator, Button */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                  <div className="flex items-center gap-3 text-slate-400 text-[11px]">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {lesson.durationMinutes || 5} min
                    </span>

                    {quiz && (
                      <span
                        className={`flex items-center gap-1 text-[11px] ${
                          quizPassed ? 'text-emerald-400 font-semibold' : 'text-blue-400'
                        }`}
                      >
                        <HelpCircle className="w-3 h-3" />
                        {quizPassed ? 'Kuis Lulus' : 'Ada Kuis'}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1 text-xs font-medium text-slate-400 group-hover:text-white transition">
                    <span>Baca Modul</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modals */}
      <LessonModal
        lesson={activeLessonForModal}
        onClose={closeLessonModal}
        onStartQuiz={handleStartQuizFromLesson}
      />

      <QuizModal
        quizData={activeQuizForModal}
        onClose={closeQuizModal}
      />
    </div>
  );
};
