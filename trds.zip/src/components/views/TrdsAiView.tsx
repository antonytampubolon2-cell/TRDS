import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  RotateCcw,
  Trash2,
  Copy,
  Check,
  Info,
  X,
  BookOpen,
  HelpCircle,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { QUICK_QUESTIONS } from '../../services/aiService';

export const TrdsAiView: React.FC = () => {
  const {
    chatMessages,
    sendChatMessage,
    retryLastChatMessage,
    clearChatMessages,
    isAiTyping,
    aiError,
    activeAiContext,
    clearActiveAiContext,
    userProfile,
    totalSimulatedPnL,
    simulatedPnLPercent
  } = useApp();

  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isAiTyping]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isAiTyping) return;
    sendChatMessage(inputText);
    setInputText('');
  };

  const handleQuickQuestion = (prompt: string) => {
    if (isAiTyping) return;
    sendChatMessage(prompt);
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Helper to format text with bolding and bullet list styling
  const renderFormattedMessage = (text: string) => {
    const lines = text.split('\n');
    return (
      <div className="space-y-1.5 leading-relaxed">
        {lines.map((line, idx) => {
          if (!line.trim()) {
            return <div key={idx} className="h-1" />;
          }

          // Format bullet points
          const isBullet = line.trim().startsWith('•') || line.trim().startsWith('-');
          const isNumbered = /^\d+\.\s/.test(line.trim());

          // Replace markdown bold **text** with <strong>
          const parts = line.split(/(\*\*.*?\*\*)/g);
          const renderedLine = parts.map((part, pIdx) => {
            if (part.startsWith('**') && part.endsWith('**')) {
              return (
                <strong key={pIdx} className="font-semibold text-purple-200">
                  {part.slice(2, -2)}
                </strong>
              );
            }
            return part;
          });

          if (isBullet || isNumbered) {
            return (
              <div key={idx} className="flex items-start gap-2 pl-1 text-[12px]">
                <span className="text-purple-400 font-bold shrink-0 mt-0.5">
                  {isBullet ? '•' : line.trim().split(' ')[0]}
                </span>
                <span className="flex-1">
                  {isNumbered ? line.replace(/^\d+\.\s/, '') : line.replace(/^[•\-]\s*/, '')}
                </span>
              </div>
            );
          }

          return (
            <p key={idx} className="text-[12px]">
              {renderedLine}
            </p>
          );
        })}
      </div>
    );
  };

  return (
    <div id="trds-ai-view" className="flex flex-col h-[calc(100vh-125px)] max-w-lg mx-auto px-4 pb-20">
      {/* 1. Header with description & controls */}
      <div className="pt-2 pb-2 space-y-2 shrink-0 border-b border-slate-800/80">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-slate-900 flex items-center justify-center text-white shadow-md shadow-purple-500/20">
              <Bot className="w-5 h-5 text-purple-200" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-sm font-bold text-white tracking-wide">TRDS AI</h1>
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-[9px] font-semibold text-purple-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Edukasi Virtual
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-1">
                Your AI learning companion for virtual market education.
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5">
            {showClearConfirm ? (
              <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 px-2 py-1 rounded-xl shadow-lg">
                <span className="text-[10px] text-slate-300">Reset?</span>
                <button
                  id="confirm-clear-chat"
                  onClick={() => {
                    clearChatMessages();
                    setShowClearConfirm(false);
                  }}
                  className="text-[10px] px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-medium transition"
                >
                  Ya
                </button>
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 hover:text-white transition"
                >
                  Batal
                </button>
              </div>
            ) : (
              <button
                id="clear-chat-history-btn"
                onClick={() => setShowClearConfirm(true)}
                title="Hapus riwayat chat"
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 transition"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Active Context Banner (When launched from Lesson, Quiz, or Simulator) */}
        {activeAiContext?.activeTarget && (
          <div
            id="ai-active-context-banner"
            className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-purple-950/40 border border-purple-500/30 text-[11px] text-purple-200 animate-in fade-in duration-200"
          >
            <div className="flex items-center gap-2 overflow-hidden">
              {activeAiContext.activeTarget.type === 'lesson' && <BookOpen className="w-3.5 h-3.5 text-purple-400 shrink-0" />}
              {activeAiContext.activeTarget.type === 'quiz' && <HelpCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
              {activeAiContext.activeTarget.type === 'simulator' && <TrendingUp className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
              <div className="truncate">
                <span className="font-semibold text-white uppercase tracking-wider text-[9px] mr-1 px-1.5 py-0.5 rounded bg-purple-500/20">
                  {activeAiContext.activeTarget.type}
                </span>
                <span className="font-medium text-slate-300 truncate">
                  {activeAiContext.activeTarget.title}
                </span>
              </div>
            </div>
            <button
              onClick={clearActiveAiContext}
              className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-purple-900/50 transition ml-2"
              title="Tutup konteks aktif"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Safety & Educational Guidance Notice */}
        <div className="flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[10px] text-amber-300">
          <div className="flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>100% Edukasi Virtual. Tidak mengeksekusi transaksi nyata.</span>
          </div>
          <div className="text-[10px] font-mono text-slate-400">
            PnL: <span className={totalSimulatedPnL >= 0 ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
              {totalSimulatedPnL >= 0 ? '+' : ''}{simulatedPnLPercent.toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* 2. Messages Stream */}
      <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 py-3 scrollbar-none">
        {/* Empty State when only 1 or no messages */}
        {chatMessages.length <= 1 && (
          <div id="ai-empty-state" className="p-4 my-2 rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-900/40 border border-slate-800 text-center space-y-3">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-purple-500/10 border border-purple-500/25 flex items-center justify-center text-purple-400 shadow-inner">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Selamat Datang di TRDS AI</h2>
              <p className="text-xs text-slate-400 max-w-xs mx-auto mt-1 leading-relaxed">
                Tanyakan apa saja seputar terminologi pasar, membaca candlestick, manajemen risiko, atau cara kerja simulasi trading.
              </p>
            </div>
            <div className="pt-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                Rekomendasi Topik Awal:
              </span>
              <div className="flex flex-wrap justify-center gap-1.5 mt-2">
                {QUICK_QUESTIONS.slice(0, 3).map(q => (
                  <button
                    key={q.id}
                    onClick={() => handleQuickQuestion(q.prompt)}
                    className="text-[11px] px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-purple-900/30 border border-slate-700/80 hover:border-purple-500/40 text-slate-300 hover:text-purple-200 transition text-left"
                  >
                    {q.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Message Bubbles */}
        {chatMessages.map(msg => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1`}
            >
              {/* Context Tag if specified */}
              {msg.contextTag && (
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-slate-800/90 text-purple-300 border border-purple-500/20 max-w-[85%] truncate">
                  📌 {msg.contextTag}
                </span>
              )}

              <div className="flex items-start gap-2 max-w-[90%]">
                {!isUser && (
                  <div className="w-6 h-6 rounded-lg bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300 shrink-0 mt-1">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}

                <div
                  className={`p-3.5 rounded-2xl text-xs ${
                    isUser
                      ? 'bg-purple-600 text-white rounded-tr-xs shadow-md shadow-purple-600/10'
                      : msg.isError
                      ? 'bg-rose-950/40 border border-rose-500/30 text-rose-200 rounded-tl-xs'
                      : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-xs shadow-sm'
                  }`}
                >
                  {isUser ? (
                    <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                  ) : (
                    renderFormattedMessage(msg.text)
                  )}

                  {/* Bubble Footer: Timestamp & Copy Button */}
                  <div className={`flex items-center justify-between gap-3 pt-2 mt-2 border-t text-[10px] ${
                    isUser ? 'border-purple-500/40 text-purple-200' : 'border-slate-800 text-slate-400'
                  }`}>
                    <span>{formatTime(msg.timestamp)}</span>
                    {!isUser && (
                      <button
                        onClick={() => handleCopyText(msg.id, msg.text)}
                        className="hover:text-purple-300 transition flex items-center gap-1"
                        title="Salin penjelasan"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">Tersalin</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Salin</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Suggestions chips from assistant */}
              {!isUser && msg.promptSuggestions && msg.promptSuggestions.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1 pl-8 max-w-[92%]">
                  {msg.promptSuggestions.map((sugg, idx) => (
                    <button
                      key={idx}
                      disabled={isAiTyping}
                      onClick={() => handleQuickQuestion(sugg)}
                      className="text-[11px] text-left px-2.5 py-1 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-purple-500/40 text-slate-300 hover:text-white transition flex items-center gap-1.5 disabled:opacity-50"
                    >
                      <span>{sugg}</span>
                      <ArrowRight className="w-2.5 h-2.5 text-purple-400 shrink-0" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isAiTyping && (
          <div className="flex items-center gap-2 p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-400 w-fit animate-pulse">
            <div className="w-5 h-5 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400">
              <Bot className="w-3 h-3 animate-spin" />
            </div>
            <div className="flex items-center gap-1">
              <span className="text-[11px] text-purple-300 font-medium">TRDS AI sedang berpikir</span>
              <span className="inline-flex gap-0.5">
                <span className="w-1 h-1 bg-purple-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-1 h-1 bg-purple-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-1 h-1 bg-purple-400 rounded-full animate-bounce" />
              </span>
            </div>
          </div>
        )}

        {/* Error State with Retry Button */}
        {aiError && (
          <div className="p-3 rounded-2xl bg-rose-950/40 border border-rose-500/40 flex items-center justify-between text-xs text-rose-200">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>Gagal memuat respon. Silakan coba lagi.</span>
            </div>
            <button
              onClick={retryLastChatMessage}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium text-[11px] transition"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Coba Lagi</span>
            </button>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 3. Quick Questions Bar (Section 4) */}
      <div className="pt-2 pb-1 shrink-0">
        <div className="text-[10px] text-slate-400 font-semibold mb-1 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-purple-400" />
          <span>Quick Questions</span>
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none no-scrollbar">
          {QUICK_QUESTIONS.map(q => (
            <button
              key={q.id}
              disabled={isAiTyping}
              onClick={() => handleQuickQuestion(q.prompt)}
              className="text-[11px] whitespace-nowrap px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 active:bg-purple-950/40 border border-slate-800 hover:border-purple-500/40 text-slate-300 hover:text-white transition-all duration-150 active:scale-95 shrink-0 disabled:opacity-50 touch-manipulation"
            >
              {q.label}
            </button>
          ))}
        </div>
      </div>

      {/* 4. Text Input & Send Button */}
      <form onSubmit={handleSend} className="pt-1 shrink-0 space-y-1">
        <div className="relative flex items-center">
          <input
            id="trds-ai-input"
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            disabled={isAiTyping}
            placeholder={
              isAiTyping
                ? 'TRDS AI sedang merespon...'
                : 'Tanyakan konsep trading (misal: apa itu Stop Loss?)...'
            }
            className="w-full pl-3.5 pr-20 py-3 rounded-2xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-purple-500 transition shadow-lg disabled:opacity-60"
          />
          <div className="absolute right-1.5 flex items-center gap-1">
            {inputText && !isAiTyping && (
              <button
                type="button"
                onClick={() => setInputText('')}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                aria-label="Hapus teks pertanyaan"
                title="Hapus teks"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              id="trds-ai-send-btn"
              type="submit"
              disabled={!inputText.trim() || isAiTyping}
              className="p-2 rounded-xl bg-purple-600 disabled:opacity-40 text-white hover:bg-purple-500 active:scale-95 transition touch-manipulation"
              aria-label="Kirim Pertanyaan"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        <p className="text-[10px] text-center text-slate-400">
          TRDS AI dirancang untuk edukasi pasar virtual dan tidak mengeksekusi transaksi keuangan riil.
        </p>
      </form>
    </div>
  );
};
