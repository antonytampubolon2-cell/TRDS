import React from 'react';
import {
  SlidersHorizontal,
  BookOpen,
  Bot,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  Sparkles,
  ShieldCheck,
  Star,
  CheckCircle2,
  Clock,
  Flame,
  ChevronRight,
  Activity,
  History,
  Award,
  Compass
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SectionHeader } from '../common/SectionHeader';
import { PortfolioCard } from '../common/PortfolioCard';
import { QuickActionCard } from '../common/QuickActionCard';
import { AssetCard } from '../common/AssetCard';
import { Sparkline } from '../common/Sparkline';
import { PremiumCard } from '../premium/PremiumCard';
import { SignatureFeaturesSection } from '../signature/SignatureFeaturesSection';

export const HomeView: React.FC = () => {
  const {
    userProfile,
    totalPortfolioValue,
    totalSimulatedPnL,
    simulatedPnLPercent,
    assets,
    favoriteAssetIds,
    toggleFavorite,
    openAssetDetail,
    openMarketIntelligence,
    openPortfolioModal,
    setActiveTab,
    navigateToTrade,
    dailyChallenges,
    claimDailyChallenge,
    lessons,
    completedLessonIds,
    achievements,
    openAchievementsModal,
    openDailyChallengesModal,
    trades,
    isPremium,
    openPremiumModal
  } = useApp();

  // Assets to highlight in Market Summary: BTC, ETH, SOL, BNB, XRP, ADA
  const summaryAssetIds = ['btc', 'eth', 'sol', 'bnb', 'xrp', 'ada'];
  const marketSummaryAssets = summaryAssetIds
    .map(id => assets.find(a => a.id === id))
    .filter((a): a is NonNullable<typeof a> => a !== undefined);

  // Favorites
  const favoriteAssets = assets.filter(a => favoriteAssetIds.includes(a.id));

  // Learning calculations
  const completedLessonsCount = completedLessonIds.length;
  const learnProgressPercent = Math.round((completedLessonsCount / lessons.length) * 100);

  // Recent 3 trades
  const recentTrades = trades.slice(0, 3);

  return (
    <div id="home-view" className="space-y-4 pb-28 pt-2 px-4 max-w-md mx-auto">
      {/* 2. Virtual Balance Banner */}
      <div
        id="virtual-balance-banner"
        className="flex items-center justify-between px-3.5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-950 border border-emerald-500/30 shadow-sm"
      >
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-3.5 h-3.5" />
          </div>
          <div>
            <span className="text-xs font-black text-emerald-300 tracking-tight block">
              100% Saldo Virtual • Tanpa Uang Nyata
            </span>
            <span className="text-[10px] text-slate-400 block">
              Simulasi edukasi bebas risiko finansial
            </span>
          </div>
        </div>

        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
          Demo V1
        </span>
      </div>

      {/* 3. Welcome Section */}
      <div id="home-welcome-section" className="flex items-center justify-between pt-1">
        <div>
          <span className="text-xs text-slate-400 font-medium block">
            Selamat datang kembali,
          </span>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-black text-white tracking-tight">
              {userProfile.name}
            </h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Lv.{userProfile.level} {userProfile.levelTitle}</span>
            </span>
          </div>
        </div>

        <div className="text-right shrink-0">
          <span className="text-[10px] text-slate-400 block uppercase font-medium">
            Learning Streak
          </span>
          <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-orange-500/15 text-orange-400 text-xs font-black border border-orange-500/30 shadow-sm">
            <Flame className="w-3.5 h-3.5 text-orange-400 fill-orange-400" />
            <span>{userProfile.streakDays} Hari</span>
          </div>
        </div>
      </div>

      {/* 4. Portfolio Card */}
      <PortfolioCard
        totalValue={totalPortfolioValue}
        simulatedPnL={totalSimulatedPnL}
        pnlPercent={simulatedPnLPercent}
        cashBalance={userProfile.virtualBalance}
        onViewPortfolio={openPortfolioModal}
        onGoToSimulator={() => setActiveTab('simulator')}
      />

      {/* 5. Quick Actions */}
      <div id="home-quick-actions" className="space-y-2">
        <SectionHeader title="Quick Actions" subtitle="Navigasi cepat ke fitur utama" />
        <div className="grid grid-cols-3 gap-2">
          <QuickActionCard
            id="quick-action-simulator"
            title="Simulator"
            subtitle="Trade Demo"
            icon={<SlidersHorizontal className="w-5 h-5 text-emerald-400" />}
            iconBgColor="bg-emerald-500/15 text-emerald-400"
            badge="Live"
            onClick={() => setActiveTab('simulator')}
          />
          <QuickActionCard
            id="quick-action-learn"
            title="Learn"
            subtitle="Modul & Kuis"
            icon={<BookOpen className="w-5 h-5 text-blue-400" />}
            iconBgColor="bg-blue-500/15 text-blue-400"
            onClick={() => setActiveTab('learn')}
          />
          <QuickActionCard
            id="quick-action-ai"
            title="TRDS AI"
            subtitle="Tutor Pintar"
            icon={<Bot className="w-5 h-5 text-purple-400" />}
            iconBgColor="bg-purple-500/15 text-purple-400"
            badge="AI"
            onClick={() => setActiveTab('ai')}
          />
        </div>
      </div>

      {/* TRDS AI Educational Assistant Card (Requirement 12) */}
      <div
        id="home-trds-ai-card"
        onClick={() => setActiveTab('ai')}
        className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/50 via-indigo-950/40 to-slate-900 border border-purple-500/30 hover:border-purple-500/50 cursor-pointer transition shadow-lg relative overflow-hidden group"
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-purple-500/25 shrink-0 group-hover:scale-105 transition-transform">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-white tracking-wide">TRDS AI</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30">
                  Tutor Virtual
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Ask anything about learning and virtual markets.
              </p>
            </div>
          </div>
          <div className="p-2 rounded-xl bg-purple-500/15 text-purple-400 group-hover:bg-purple-500/25 transition shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* TRDS Signature Features System (7 Principles) */}
      <SignatureFeaturesSection />

      {/* Phase 6: TRDS Premium Entitlement Card */}
      <PremiumCard
        isPremium={isPremium}
        onOpenPremium={() => openPremiumModal('TRDS Premium Overview')}
      />

      {/* 6. Virtual Market Summary */}
      <div id="home-market-summary" className="space-y-2">
        <SectionHeader
          title="Virtual Market Summary"
          subtitle="Harga & pergerakan demo pasar kripto"
          actionText="Lihat Semua"
          onAction={() => setActiveTab('markets')}
        />

        <div className="flex gap-2.5 overflow-x-auto pb-1.5 scrollbar-none">
          {marketSummaryAssets.map(asset => (
            <AssetCard
              key={asset.id}
              asset={asset}
              isFavorite={favoriteAssetIds.includes(asset.id)}
              onToggleFavorite={toggleFavorite}
              onClick={openAssetDetail}
            />
          ))}
        </div>

        {/* TRDS Market Pulse Highlight */}
        <div
          id="home-market-pulse-card"
          onClick={() => openMarketIntelligence()}
          className="p-3.5 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-slate-900 to-indigo-950/50 border border-cyan-500/30 hover:border-cyan-500/60 cursor-pointer transition shadow-md flex items-center justify-between group"
          role="button"
          tabIndex={0}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center shrink-0 border border-cyan-500/30 group-hover:scale-105 transition-transform">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white tracking-wide">
                  TRDS Market Pulse
                </span>
                <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300">
                  Analisis
                </span>
              </div>
              <span className="text-[11px] text-slate-300 font-medium block">
                Apa yang sedang terjadi di pasar?
              </span>
            </div>
          </div>

          <div className="p-1.5 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:bg-cyan-500/20 group-hover:translate-x-0.5 transition shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* 7. Favorites Section */}
      <div id="home-favorites-section" className="space-y-2">
        <SectionHeader
          title="Aset Favorit"
          subtitle="Daftar pantauan instrumen pilihanmu"
          badge={`${favoriteAssets.length}`}
          actionText="Kelola di Markets"
          onAction={() => setActiveTab('markets')}
        />

        {favoriteAssets.length === 0 ? (
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-1.5">
            <Star className="w-6 h-6 text-slate-600 mx-auto" />
            <p className="text-xs font-semibold text-slate-300">
              Belum ada aset favorit.
            </p>
            <p className="text-[11px] text-slate-500">
              Tandai ikon bintang di halaman Markets untuk memantau aset pilihan secara cepat di sini.
            </p>
            <button
              type="button"
              onClick={() => setActiveTab('markets')}
              className="mt-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-semibold inline-flex items-center gap-1 transition"
            >
              <span>Buka Markets</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {favoriteAssets.slice(0, 3).map(asset => {
              const isPos = asset.change24h >= 0;
              return (
                <div
                  key={asset.id}
                  onClick={() => openAssetDetail(asset)}
                  className="p-3 rounded-2xl bg-slate-900/70 hover:bg-slate-850 border border-slate-800/90 hover:border-slate-700 flex items-center justify-between cursor-pointer transition shadow-sm"
                  role="button"
                  tabIndex={0}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center font-bold text-xs text-white">
                      {asset.symbol.split('/')[0].slice(0, 3)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">{asset.symbol}</span>
                        <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                          {asset.category}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 block">{asset.name}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <div className="w-14 h-6 flex items-center">
                      <Sparkline data={asset.sparkline} isPositive={isPos} width={56} height={22} />
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-bold text-white font-mono block">
                        ${asset.price.toLocaleString('en-US', {
                          minimumFractionDigits: asset.price < 1 ? 4 : 2,
                          maximumFractionDigits: asset.price < 1 ? 4 : 2
                        })}
                      </span>
                      <span
                        className={`text-[10px] font-bold flex items-center justify-end gap-0.5 ${
                          isPos ? 'text-emerald-400' : 'text-red-400'
                        }`}
                      >
                        {isPos ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
                        {isPos ? '+' : ''}{asset.change24h}%
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={e => {
                        e.stopPropagation();
                        toggleFavorite(asset.id);
                      }}
                      className="p-1 text-amber-400 hover:text-slate-500 transition"
                      aria-label="Hapus dari favorit"
                    >
                      <Star className="w-4 h-4 fill-amber-400" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 8. Learning Progress */}
      <div id="home-learning-progress" className="space-y-2">
        <SectionHeader
          title="Learning Progress"
          subtitle="Pantau peningkatan level & XP belajarmu"
          actionText="Buka Modul"
          onAction={() => setActiveTab('learn')}
        />

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">
                  Level {userProfile.level}: {userProfile.levelTitle}
                </span>
                <span className="text-[11px] text-slate-400">
                  {userProfile.currentXp} / {userProfile.nextLevelXp} XP (Tersisa {userProfile.nextLevelXp - userProfile.currentXp} XP)
                </span>
              </div>
            </div>

            <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-orange-500/10 text-orange-400 text-xs font-bold border border-orange-500/20">
              <Flame className="w-3 h-3 fill-orange-400" />
              <span>{userProfile.streakDays} Hari Streak</span>
            </div>
          </div>

          {/* XP Progress Bar */}
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-gradient-to-r from-amber-500 to-amber-300 h-2 rounded-full transition-all duration-500"
              style={{
                width: `${Math.min(100, (userProfile.currentXp / userProfile.nextLevelXp) * 100)}%`
              }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>
              Progres Belajar: {completedLessonsCount}/{lessons.length} Modul Selesai ({learnProgressPercent}%)
            </span>
            <button
              onClick={openAchievementsModal}
              className="text-amber-400 font-semibold hover:underline flex items-center gap-1"
            >
              <Award className="w-3 h-3" />
              <span>{achievements.filter(a => a.isUnlocked).length} Prestasi</span>
            </button>
          </div>
        </div>
      </div>

      {/* 9. Daily Challenge */}
      <div id="home-daily-challenges" className="space-y-2">
        <SectionHeader
          title="Daily Challenge"
          subtitle="Tuntaskan misi harian untuk raih bonus XP"
          actionText="Lihat Semua"
          onAction={openDailyChallengesModal}
        />

        <div className="space-y-2">
          {dailyChallenges.slice(0, 2).map(challenge => (
            <div
              key={challenge.id}
              className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs gap-2"
            >
              <div className="flex items-start gap-2.5 min-w-0">
                <div
                  className={`mt-0.5 w-4 h-4 rounded-full flex items-center justify-center shrink-0 ${
                    challenge.isCompleted
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : 'border border-slate-600 text-transparent'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0">
                  <span
                    className={`font-bold block truncate ${
                      challenge.isCompleted ? 'line-through text-slate-400' : 'text-slate-200'
                    }`}
                  >
                    {challenge.title}
                  </span>
                  <span className="text-[11px] text-slate-400 block truncate">{challenge.description}</span>
                </div>
              </div>

              <div className="shrink-0 text-right">
                {challenge.isCompleted && !challenge.isClaimed ? (
                  <button
                    onClick={() => claimDailyChallenge(challenge.id)}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] transition shadow-sm"
                  >
                    Klaim +{challenge.xpReward} XP
                  </button>
                ) : (
                  <span className="text-[11px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/20">
                    +{challenge.xpReward} XP
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 10. Recent Activity / Simulated History */}
      <div id="home-recent-activity" className="space-y-2">
        <SectionHeader
          title="Recent Activity"
          subtitle="Riwayat aktivitas simulasi trading terakhir"
          actionText="Buka Simulator"
          onAction={() => setActiveTab('simulator')}
        />

        {recentTrades.length === 0 ? (
          <div className="p-4 rounded-2xl bg-slate-900/40 border border-slate-800 text-center text-xs text-slate-500">
            Belum ada aktivitas simulasi. Coba tempatkan order pertamamu di Simulator!
          </div>
        ) : (
          <div className="space-y-2">
            {recentTrades.map(trade => {
              const isBuy = trade.side === 'buy';
              const isProfit = (trade.simulatedPnL || 0) >= 0;
              return (
                <div
                  key={trade.id}
                  onClick={() => navigateToTrade(trade.assetId)}
                  className="p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-850 border border-slate-800/80 flex items-center justify-between text-xs transition cursor-pointer"
                  role="button"
                  tabIndex={0}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-[10px] ${
                        isBuy ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'
                      }`}
                    >
                      {isBuy ? 'BUY' : 'SELL'}
                    </div>
                    <div>
                      <span className="font-bold text-white block">
                        {trade.symbol} • {trade.amount} unit
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        @${trade.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-bold text-white font-mono block">
                      ${trade.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </span>
                    {trade.simulatedPnL !== undefined && (
                      <span
                        className={`text-[10px] font-bold ${
                          isProfit ? 'text-emerald-400' : 'text-red-400'
                        }`}
                      >
                        PnL: {isProfit ? '+' : ''}${trade.simulatedPnL.toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

