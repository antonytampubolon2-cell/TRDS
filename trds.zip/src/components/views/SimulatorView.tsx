import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  RotateCcw,
  Clock,
  CheckCircle2,
  AlertCircle,
  X,
  XCircle,
  Wallet,
  Play,
  HelpCircle,
  DollarSign,
  Bot,
  ArrowRight,
  BookOpen,
  Brain,
  Sparkles
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { OrderSide, OrderType, SimulatorTimeframe } from '../../types';
import { VirtualNoticeBanner } from '../common/VirtualNoticeBanner';
import { TradingChart } from '../simulator/TradingChart';
import { OrderConfirmationModal } from '../simulator/OrderConfirmationModal';
import { ResetSimulationModal } from '../simulator/ResetSimulationModal';
import { AssetSelectorModal } from '../simulator/AssetSelectorModal';
import { PremiumFeatureLock } from '../premium/PremiumFeatureLock';
import { PremiumBadge } from '../premium/PremiumBadge';
import { ActivePositionPanel } from '../simulator/ActivePositionPanel';
import { PositionCloseFeedback, CloseFeedbackState } from '../simulator/PositionCloseFeedback';
import { TradeJournalModal } from '../simulator/TradeJournalModal';
import { PsychologySummaryCard } from '../simulator/PsychologySummaryCard';

type HistoryTab = 'open_orders' | 'order_history' | 'trade_history' | 'holdings' | 'analytics';

export const SimulatorView: React.FC = () => {
  const {
    assets,
    selectedAssetId,
    setSelectedAssetId,
    selectedAsset,
    userProfile,
    holdings,
    holdingsMeta,
    orders,
    trades,
    realizedPnL,
    unrealizedPnL,
    placeOrder,
    cancelOrder,
    closeVirtualPosition,
    triggerLimitOrderExecution,
    resetSimulation,
    navigateBack,
    askAiAboutSimulator,
    isPremium,
    openPremiumModal,
    journals,
    saveTradeJournal,
    deleteTradeJournal,
    activeJournalTrade,
    openJournalModal,
    closeJournalModal
  } = useApp();

  const [orderSide, setOrderSide] = useState<OrderSide>('buy');
  const [orderType, setOrderType] = useState<OrderType>('market');
  const [amount, setAmount] = useState<string>('0.05');
  const [limitPrice, setLimitPrice] = useState<string>(selectedAsset.price.toString());
  const [timeframe, setTimeframe] = useState<SimulatorTimeframe>('1H');
  const [chartType, setChartType] = useState<'candlestick' | 'line'>('candlestick');
  const [activeHistoryTab, setActiveHistoryTab] = useState<HistoryTab>('open_orders');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // One-Tap Close state & double-tap lock
  const [closeFeedback, setCloseFeedback] = useState<CloseFeedbackState | null>(null);
  const [isClosingAssetId, setIsClosingAssetId] = useState<string | null>(null);
  const isClosingRef = useRef<boolean>(false);

  // Auto-dismiss close feedback after 6 seconds
  useEffect(() => {
    if (!closeFeedback) return;
    const timer = setTimeout(() => {
      setCloseFeedback(null);
    }, 6000);
    return () => clearTimeout(timer);
  }, [closeFeedback]);

  // Modals state
  const [isAssetSelectorOpen, setIsAssetSelectorOpen] = useState<boolean>(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState<boolean>(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState<boolean>(false);

  // Update default limit price when asset changes
  useEffect(() => {
    setLimitPrice(selectedAsset.price.toString());
  }, [selectedAsset.id, selectedAsset.price]);

  // Derived financial values
  const numAmount = parseFloat(amount) || 0;
  const executionPrice =
    orderType === 'market'
      ? selectedAsset.price
      : (parseFloat(limitPrice) || selectedAsset.price);

  const totalValue = numAmount * executionPrice;
  const simulatedFee = totalValue * 0.001; // 0.10% virtual fee
  const userBalance = userProfile.virtualBalance;
  const userAssetHolding = holdings[selectedAsset.id] || 0;
  const holdingMeta = holdingsMeta[selectedAsset.id];

  // Remaining balance calculations
  const remainingCash =
    orderSide === 'buy'
      ? Math.max(0, userBalance - (totalValue + simulatedFee))
      : userBalance + Math.max(0, totalValue - simulatedFee);

  const remainingAsset =
    orderSide === 'sell'
      ? Math.max(0, userAssetHolding - numAmount)
      : userAssetHolding + numAmount;

  // Percentage selector handler
  const handlePercentageClick = (pct: number) => {
    if (orderSide === 'buy') {
      const budget = (userBalance * (pct / 100)) / (1 + 0.001); // Account for fee
      const calculatedAmount = executionPrice > 0 ? budget / executionPrice : 0;
      const decimals = selectedAsset.price < 1 ? 2 : selectedAsset.price < 100 ? 3 : 4;
      setAmount(calculatedAmount.toFixed(decimals));
    } else {
      const calculatedAmount = userAssetHolding * (pct / 100);
      const decimals = selectedAsset.price < 1 ? 2 : selectedAsset.price < 100 ? 3 : 4;
      setAmount(calculatedAmount.toFixed(decimals));
    }
  };

  // Pre-validate before opening confirmation modal
  const handleInitiateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (numAmount <= 0) {
      setFeedback({ type: 'error', message: 'Jumlah pesanan harus lebih dari 0' });
      return;
    }

    if (orderType === 'limit') {
      const parsedLimit = parseFloat(limitPrice);
      if (!parsedLimit || parsedLimit <= 0) {
        setFeedback({ type: 'error', message: 'Masukkan harga limit target yang valid' });
        return;
      }
    }

    if (orderSide === 'buy') {
      if (userBalance < totalValue + simulatedFee) {
        setFeedback({
          type: 'error',
          message: `Saldo virtual tidak mencukupi. Butuh $${(totalValue + simulatedFee).toLocaleString('en-US', { minimumFractionDigits: 2 })}, saldo saat ini: $${userBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })} USDT`
        });
        return;
      }
    } else {
      if (userAssetHolding < numAmount) {
        setFeedback({
          type: 'error',
          message: `Kepemilikan aset tidak mencukupi. Kamu memiliki ${userAssetHolding.toFixed(4)} ${selectedAsset.unit}, ingin menjual ${numAmount} ${selectedAsset.unit}`
        });
        return;
      }
    }

    // Input is valid -> open confirmation modal
    setIsConfirmModalOpen(true);
  };

  // Final confirmation execution
  const handleConfirmOrder = () => {
    setIsConfirmModalOpen(false);

    const result = placeOrder({
      assetId: selectedAsset.id,
      type: orderType,
      side: orderSide,
      amount: numAmount,
      price: orderType === 'limit' ? parseFloat(limitPrice) : undefined
    });

    if (result.success) {
      setFeedback({ type: 'success', message: result.message });
      if (orderType === 'limit') {
        setActiveHistoryTab('open_orders');
      } else {
        setActiveHistoryTab('trade_history');
      }
      setTimeout(() => setFeedback(null), 5000);
    } else {
      setFeedback({ type: 'error', message: result.message });
    }
  };

  // ONE-TAP CLOSE HANDLER: Fast, atomic, no confirmation dialog, double-tap protected
  const handleOneTapClose = (assetIdToClose?: string) => {
    const targetAssetId = assetIdToClose || selectedAsset.id;

    // 1. Guard against duplicate / rapid double tap
    if (isClosingRef.current) return;

    // 2. Position State Protection (Requirement 14 & TEST D)
    const currentHolding = holdings[targetAssetId] || 0;
    if (typeof currentHolding !== 'number' || currentHolding <= 0) {
      setCloseFeedback({
        type: 'error',
        title: 'CLOSE FAILED',
        message: 'Tidak ada posisi virtual terbuka untuk aset ini atau posisi sudah ditutup.'
      });
      return;
    }

    // Immediately lock button state
    isClosingRef.current = true;
    setIsClosingAssetId(targetAssetId);

    try {
      const result = closeVirtualPosition(targetAssetId);
      if (result.success && result.closeDetails) {
        setCloseFeedback({
          type: 'success',
          title: 'POSITION CLOSED',
          closeDetails: result.closeDetails,
          trade: result.trade
        });
        setActiveHistoryTab('trade_history');
      } else {
        setCloseFeedback({
          type: 'error',
          title: 'CLOSE FAILED',
          message: result.message || 'Gagal mengeksekusi penutupan posisi virtual.'
        });
      }
    } catch (err: any) {
      setCloseFeedback({
        type: 'error',
        title: 'CLOSE FAILED',
        message: err?.message || 'Terjadi kesalahan sistem saat menutup posisi.'
      });
    } finally {
      // Immediate release of synchronous lock
      isClosingRef.current = false;
      setIsClosingAssetId(null);
    }
  };

  // Other active holdings to display quick switch pills
  const otherActiveAssets = Object.entries(holdings)
    .filter(([id, qty]) => id !== selectedAsset.id && Number(qty) > 0)
    .map(([id, qty]) => {
      const a = assets.find(item => item.id === id);
      return {
        id,
        symbol: a?.symbol || id.toUpperCase(),
        qty: Number(qty)
      };
    });

  const currentOpenOrders = orders.filter(o => o.status === 'open');

  return (
    <div id="simulator-view" className="space-y-3 pb-28 pt-1 px-4 max-w-md mx-auto">
      {/* 1. Header Area: Back Button, Pair Selector, Demo Market Badge, Live Price, Reset */}
      <div className="flex items-center justify-between gap-2 bg-slate-900/90 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-2">
          <button
            id="simulator-back-btn"
            type="button"
            onClick={navigateBack}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white transition"
            aria-label="Kembali"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          {/* Asset Selector Trigger */}
          <button
            id="simulator-asset-selector-trigger"
            type="button"
            onClick={() => setIsAssetSelectorOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700/80 text-white font-bold text-xs transition"
          >
            <span className="font-extrabold">{selectedAsset.symbol}</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/20">
              DEMO
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>

        {/* Live Price & Reset Button */}
        <div className="flex items-center gap-2">
          <div className="text-right">
            <div className="text-sm font-black text-white font-mono tracking-tight">
              ${selectedAsset.price.toLocaleString('en-US', {
                minimumFractionDigits: selectedAsset.price < 1 ? 4 : 2,
                maximumFractionDigits: selectedAsset.price < 1 ? 4 : 2
              })}
            </div>
            <div
              className={`text-[10px] font-bold inline-flex items-center gap-0.5 ${
                selectedAsset.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {selectedAsset.change24h >= 0 ? '+' : ''}{selectedAsset.change24h}%
            </div>
          </div>

          <button
            id="btn-open-reset-simulation"
            type="button"
            onClick={() => setIsResetModalOpen(true)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-rose-400 transition"
            title="Reset Data Simulasi"
            aria-label="Reset Data Simulasi"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Virtual Balance & Safety Banner */}
      <VirtualNoticeBanner compact />

      {/* 3. Responsive Candlestick & Price Chart */}
      <TradingChart
        asset={selectedAsset}
        timeframe={timeframe}
        onTimeframeChange={setTimeframe}
        chartType={chartType}
        onChartTypeChange={setChartType}
      />

      {/* Ask TRDS AI Simulator Companion Bar (Requirement 9) */}
      <div id="simulator-ask-ai-box" className="p-3 rounded-2xl bg-gradient-to-r from-purple-950/40 via-indigo-950/30 to-slate-900 border border-purple-500/30 space-y-2 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-bold text-white">Ask TRDS AI</span>
            <span className="text-[10px] text-purple-300">Tutor Virtual Pasar</span>
          </div>
          <button
            type="button"
            onClick={() => askAiAboutSimulator(`Jelaskan cara menganalisis pergerakan harga ${selectedAsset.symbol} dan manajemen risiko yang tepat di Simulator.`)}
            className="text-[10px] font-semibold text-purple-400 hover:text-purple-300 transition flex items-center gap-1"
          >
            <span>Buka Chat</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="flex gap-1.5 overflow-x-auto pb-0.5 scrollbar-none no-scrollbar">
          <button
            type="button"
            onClick={() => askAiAboutSimulator(`Tolong jelaskan analisis dan karakteristik instrumen ${selectedAsset.name} (${selectedAsset.symbol}) di Simulator TRDS.`)}
            className="text-[11px] whitespace-nowrap px-2.5 py-1 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-purple-500/25 hover:border-purple-500/50 text-slate-200 transition flex items-center gap-1.5 shrink-0"
          >
            <span>Explain this asset</span>
          </button>
          <button
            type="button"
            onClick={() => askAiAboutSimulator(`Jelaskan kondisi virtual PnL portofolio saya saat ini dan faktor apa saja yang memengaruhinya.`)}
            className="text-[11px] whitespace-nowrap px-2.5 py-1 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-purple-500/25 hover:border-purple-500/50 text-slate-200 transition flex items-center gap-1.5 shrink-0"
          >
            <span>Explain my current PnL</span>
          </button>
          <button
            type="button"
            onClick={() => askAiAboutSimulator(`Untuk aset ${selectedAsset.symbol} pada harga $${selectedAsset.price}, jenis pesanan apa yang sebaiknya saya gunakan: Market Order atau Limit Order?`)}
            className="text-[11px] whitespace-nowrap px-2.5 py-1 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-purple-500/25 hover:border-purple-500/50 text-slate-200 transition flex items-center gap-1.5 shrink-0"
          >
            <span>What order type should I use?</span>
          </button>
        </div>
      </div>

      {/* 4. One-Tap Close Feedback Toast/Banner */}
      <PositionCloseFeedback
        feedback={closeFeedback}
        onDismiss={() => setCloseFeedback(null)}
        onOpenJournal={trade => {
          const target = trade || (trades.length > 0 ? trades[0] : null);
          if (target) {
            openJournalModal(target);
          }
        }}
      />

      {/* 5. Active Position Panel & One-Tap Close (Section 3, 4, 17) */}
      <ActivePositionPanel
        asset={selectedAsset}
        holdingQty={userAssetHolding}
        holdingMeta={holdingMeta}
        onClosePosition={() => handleOneTapClose(selectedAsset.id)}
        isClosing={isClosingAssetId === selectedAsset.id}
        otherActiveAssets={otherActiveAssets}
        onSelectAsset={id => setSelectedAssetId(id)}
      />

      {/* 6. Trading Execution Terminal Form */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3.5 shadow-md">
        {/* BUY / SELL Tab Switch */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            id="order-side-buy"
            type="button"
            onClick={() => setOrderSide('buy')}
            className={`py-2 rounded-lg text-xs font-black transition flex items-center justify-center gap-1.5 ${
              orderSide === 'buy'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Virtual BUY</span>
          </button>
          <button
            id="order-side-sell"
            type="button"
            onClick={() => setOrderSide('sell')}
            className={`py-2 rounded-lg text-xs font-black transition flex items-center justify-center gap-1.5 ${
              orderSide === 'sell'
                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5" />
            <span>Virtual SELL</span>
          </button>
        </div>

        {/* Order Type: Market vs Limit */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium">Tipe Pesanan:</span>
          <div className="flex gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              id="order-type-market"
              onClick={() => setOrderType('market')}
              className={`px-3 py-1 rounded-lg text-[11px] font-bold transition ${
                orderType === 'market'
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Market Order
            </button>
            <button
              type="button"
              id="order-type-limit"
              onClick={() => setOrderType('limit')}
              className={`px-3 py-1 rounded-lg text-[11px] font-bold transition ${
                orderType === 'limit'
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Limit Order
            </button>
          </div>
        </div>

        {/* Trade Inputs Form */}
        <form onSubmit={handleInitiateOrder} className="space-y-3">
          {/* Target Limit Price Input if Limit Order */}
          {orderType === 'limit' && (
            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Harga Limit Target</span>
                <span className="font-mono text-slate-300">
                  Pasar: ${selectedAsset.price.toLocaleString('en-US', { minimumFractionDigits: selectedAsset.price < 1 ? 4 : 2 })}
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-mono">$</span>
                <input
                  id="limit-price-input"
                  type="number"
                  step="any"
                  value={limitPrice}
                  onChange={e => setLimitPrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-7 pr-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
            </div>
          )}

          {/* Amount Input */}
          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Jumlah ({selectedAsset.unit})</span>
              <span className="font-mono">
                {orderSide === 'buy'
                  ? `Saldo: $${userBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })} USDT`
                  : `Milikmu: ${userAssetHolding.toFixed(4)} ${selectedAsset.unit}`}
              </span>
            </div>
            <div className="relative flex items-center">
              <input
                id="amount-input"
                type="number"
                step="any"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full pl-3 pr-20 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-xs focus:outline-none focus:border-emerald-500 transition shadow-inner"
                required
              />
              <div className="absolute right-3 flex items-center gap-1.5">
                {amount && (
                  <button
                    type="button"
                    onClick={() => setAmount('')}
                    className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition text-xs"
                    aria-label="Bersihkan jumlah"
                    title="Bersihkan input"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
                <span className="text-[11px] font-bold text-slate-400 uppercase pointer-events-none">
                  {selectedAsset.unit}
                </span>
              </div>
            </div>
          </div>

          {/* Percentage Fast Selectors (25%, 50%, 75%, 100%) */}
          <div className="grid grid-cols-4 gap-1.5">
            {[25, 50, 75, 100].map(pct => (
              <button
                key={pct}
                type="button"
                id={`pct-btn-${pct}`}
                onClick={() => handlePercentageClick(pct)}
                className="min-h-[36px] py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-750 active:bg-emerald-500/20 active:text-emerald-400 text-slate-300 hover:text-white text-xs font-bold border border-slate-700/60 transition-all duration-150 active:scale-95 touch-manipulation select-none"
              >
                {pct}%
              </button>
            ))}
          </div>

          {/* Live Order Calculations Breakdown */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800/80 text-xs bg-slate-950/40 p-2.5 rounded-xl">
            <div className="flex justify-between text-slate-400">
              <span>Estimasi Total Nilai Virtual:</span>
              <span className="font-bold text-white font-mono">
                ${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            <div className="flex justify-between text-slate-400">
              <span>Simulated Fee (0.10%):</span>
              <span className="text-emerald-400 font-mono font-medium">
                ${simulatedFee.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (Virtual)
              </span>
            </div>

            <div className="flex justify-between text-slate-400 border-t border-slate-800/60 pt-1.5 text-[11px]">
              <span>Sisa Saldo Virtual:</span>
              <span className="font-mono font-bold text-slate-200">
                ${remainingCash.toLocaleString('en-US', { minimumFractionDigits: 2 })} USDT
              </span>
            </div>
          </div>

          {/* Inline Feedback Alerts */}
          {feedback && (
            <div
              className={`p-3 rounded-xl text-xs flex items-start gap-2 animate-in fade-in duration-150 ${
                feedback.type === 'success'
                  ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
                  : 'bg-rose-500/15 border border-rose-500/30 text-rose-300'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              )}
              <span className="flex-1 leading-snug">{feedback.message}</span>
            </div>
          )}

          {/* Submit Trigger Button */}
          <button
            id="execute-trade-button"
            type="submit"
            className={`w-full py-3.5 rounded-xl font-black text-xs tracking-wider uppercase transition shadow-lg flex items-center justify-center gap-1.5 ${
              orderSide === 'buy'
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/25 active:scale-98'
                : 'bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/25 active:scale-98'
            }`}
          >
            <span>
              {orderSide === 'buy'
                ? `Virtual BUY ${selectedAsset.symbol}`
                : `Virtual SELL ${selectedAsset.symbol}`}
            </span>
          </button>
        </form>
      </div>

      {/* 5. Sub-Tabs: Open Orders, Order History, Trade History, Holdings */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-3.5 space-y-3 shadow-md">
        {/* Sub-tab Navigation */}
        <div className="flex gap-1 border-b border-slate-800 pb-2.5 overflow-x-auto no-scrollbar">
          {(
            [
              { id: 'open_orders', label: `Open Orders (${currentOpenOrders.length})` },
              { id: 'order_history', label: `Order History (${orders.length})` },
              { id: 'trade_history', label: `Trade History (${trades.length})` },
              { id: 'holdings', label: 'Holdings' },
              { id: 'analytics', label: 'Analisis Pro ★' }
            ] as const
          ).map(tab => (
            <button
              key={tab.id}
              id={`history-tab-${tab.id}`}
              type="button"
              onClick={() => setActiveHistoryTab(tab.id)}
              className={`px-3 py-1.5 text-xs font-bold rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
                activeHistoryTab === tab.id
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{tab.label}</span>
              {tab.id === 'analytics' && <PremiumBadge size="sm" />}
            </button>
          ))}
        </div>

        {/* Tab 1: Open Orders (Limit orders waiting for trigger or cancellation) */}
        {activeHistoryTab === 'open_orders' && (
          <div className="space-y-2">
            {currentOpenOrders.length === 0 ? (
              <div className="text-center py-6 text-slate-500 space-y-1">
                <Clock className="w-6 h-6 mx-auto opacity-40 mb-1" />
                <p className="text-xs font-medium">Belum ada open limit order.</p>
                <p className="text-[11px] text-slate-600">
                  Pasang Limit Order di atas untuk mengeksekusi order otomatis saat harga tercapai.
                </p>
              </div>
            ) : (
              currentOpenOrders.map(order => (
                <div
                  key={order.id}
                  id={`open-order-${order.id}`}
                  className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90 text-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-black uppercase px-2 py-0.5 rounded text-[10px] ${
                          order.side === 'buy'
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25'
                            : 'bg-rose-500/15 text-rose-400 border border-rose-500/25'
                        }`}
                      >
                        {order.side.toUpperCase()}
                      </span>
                      <span className="font-extrabold text-white text-sm">{order.symbol}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 uppercase">
                        {order.type}
                      </span>
                    </div>

                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                      OPEN
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-slate-400 text-[11px] font-mono pt-1">
                    <div>
                      <span>Jumlah: </span>
                      <strong className="text-white">{order.amount}</strong>
                    </div>
                    <div className="text-right">
                      <span>Target: </span>
                      <strong className="text-white">${order.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}</strong>
                    </div>
                  </div>

                  {/* Actions for open order: Cancel or Trigger test */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
                    <button
                      id={`btn-trigger-order-${order.id}`}
                      type="button"
                      onClick={() => {
                        const res = triggerLimitOrderExecution(order.id);
                        if (res.success) {
                          setFeedback({ type: 'success', message: res.message });
                        }
                      }}
                      className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 hover:text-emerald-300 transition"
                      title="Simulasikan pasar mencapai target dan eksekusi pesanan"
                    >
                      <Play className="w-3 h-3 fill-emerald-400" />
                      <span>Tes Eksekusi</span>
                    </button>

                    <button
                      id={`btn-cancel-order-${order.id}`}
                      type="button"
                      onClick={() => cancelOrder(order.id)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition text-[11px] font-bold"
                    >
                      Batalkan
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 2: Order History (All Orders: filled, open, cancelled) */}
        {activeHistoryTab === 'order_history' && (
          <div className="space-y-2">
            {orders.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">Belum ada riwayat pesanan.</p>
            ) : (
              orders.map(order => (
                <div
                  key={order.id}
                  className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-black uppercase text-[10px] ${
                          order.side === 'buy' ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {order.side.toUpperCase()}
                      </span>
                      <span className="font-bold text-white">{order.symbol}</span>
                      <span className="text-[10px] px-1 rounded bg-slate-800 text-slate-400 uppercase">
                        {order.type}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block font-mono mt-0.5">
                      {order.amount} @ ${order.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      {new Date(order.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} • {new Date(order.timestamp).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>

                  <div className="text-right space-y-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        order.status === 'filled'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : order.status === 'open'
                          ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {order.status}
                    </span>
                    <span className="block font-mono text-[11px] text-slate-300">
                      ${(order.amount * order.price).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 3: Trade History (Executed Trades) & Trading Psychology Journal */}
        {activeHistoryTab === 'trade_history' && (
          <div className="space-y-3">
            <PsychologySummaryCard
              trades={trades}
              journals={journals}
              onOpenJournalForFirstUnjournaled={() => {
                const unjournaled = trades.find(t => !journals[t.id]);
                if (unjournaled) {
                  openJournalModal(unjournaled);
                } else if (trades.length > 0) {
                  openJournalModal(trades[0]);
                }
              }}
            />

            {trades.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">Belum ada transaksi yang dieksekusi.</p>
            ) : (
              <div className="space-y-2">
                {trades.map(trade => {
                  const journal = journals[trade.id] || trade.journalEntry;
                  return (
                    <div
                      key={trade.id}
                      className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span
                              className={`font-black uppercase text-[10px] px-1.5 py-0.5 rounded ${
                                trade.side === 'buy'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              }`}
                            >
                              {trade.side.toUpperCase()}
                            </span>
                            <span className="font-bold text-white">{trade.symbol}</span>
                          </div>
                          <span className="text-[11px] text-slate-400 block font-mono mt-0.5">
                            {trade.amount} @ ${trade.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </span>
                          <span className="text-[10px] text-slate-500 block">
                            Fee: ${trade.fee?.toFixed(2) || '0.00'} • {new Date(trade.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        <div className="text-right">
                          <span className="font-bold text-white font-mono block">
                            ${trade.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </span>
                          {trade.simulatedPnL !== undefined && trade.side === 'sell' && (
                            <span
                              className={`text-[10px] font-bold font-mono block ${
                                trade.simulatedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
                              }`}
                            >
                              Realized: {trade.simulatedPnL >= 0 ? '+' : ''}${trade.simulatedPnL.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Journal Reflection Footer */}
                      <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between gap-2 flex-wrap">
                        {journal ? (
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 ${
                                journal.psychologyState === 'calm_disciplined' || journal.psychologyState === 'confident_measured'
                                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                                  : journal.psychologyState === 'fomo_rushed' || journal.psychologyState === 'revenge_emotional'
                                  ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                                  : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              }`}
                            >
                              <Brain className="w-3 h-3" />
                              <span>
                                {journal.psychologyState === 'calm_disciplined'
                                  ? 'Tenang'
                                  : journal.psychologyState === 'fomo_rushed'
                                  ? 'FOMO'
                                  : journal.psychologyState === 'revenge_emotional'
                                  ? 'Revenge'
                                  : journal.psychologyState === 'confident_measured'
                                  ? 'Percaya Diri'
                                  : 'Tercatat'}
                              </span>
                            </span>

                            <span className="text-[10px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
                              ★ {journal.disciplineScore || 4}/5 Disiplin
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-500 flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-indigo-400" />
                            <span>Belum ada jurnal refleksi</span>
                          </span>
                        )}

                        <button
                          id={`btn-open-journal-${trade.id}`}
                          type="button"
                          onClick={() => openJournalModal(trade)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1.5 active:scale-95 ${
                            journal
                              ? 'bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700'
                              : 'bg-indigo-600/90 hover:bg-indigo-500 text-white shadow-sm'
                          }`}
                        >
                          <BookOpen className="w-3 h-3" />
                          <span>{journal ? 'Lihat / Edit Jurnal' : '+ Jurnal (+20 XP)'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Holdings & Positions with Unrealized PnL */}
        {activeHistoryTab === 'holdings' && (
          <div className="space-y-2">
            {Object.entries(holdings).filter(([_, qty]) => Number(qty) > 0).length === 0 ? (
              <div className="text-center py-6 text-slate-500 space-y-1">
                <Wallet className="w-6 h-6 mx-auto opacity-40 mb-1" />
                <p className="text-xs font-medium">Belum ada aset virtual yang dimiliki.</p>
                <p className="text-[11px] text-slate-600">
                  Gunakan saldo 10,000 USDT untuk membeli aset pertama di simulator.
                </p>
              </div>
            ) : (
              Object.entries(holdings)
                .filter(([_, qty]) => Number(qty) > 0)
                .map(([assetId, qty]) => {
                  const numQty = Number(qty);
                  const asset = assets.find(a => a.id === assetId);
                  if (!asset) return null;

                  const meta = holdingsMeta[assetId];
                  const avgPrice = meta?.avgBuyPrice || asset.price;
                  const currentValue = numQty * asset.price;
                  const totalCost = numQty * avgPrice;
                  const posPnL = currentValue - totalCost;
                  const posPnLPercent = totalCost > 0 ? (posPnL / totalCost) * 100 : 0;
                  const isGain = posPnL >= 0;

                  return (
                    <div
                      key={assetId}
                      className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center font-bold text-[11px] text-white">
                            {asset.symbol.split('/')[0].slice(0, 3)}
                          </div>
                          <div>
                            <span className="font-extrabold text-white text-sm block leading-tight">{asset.symbol}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {numQty} {asset.unit} • Avg: ${avgPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                            </span>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="font-bold text-white font-mono block">
                            ${currentValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </span>
                          <span
                            className={`text-[11px] font-bold font-mono ${
                              isGain ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            {isGain ? '+' : ''}${posPnL.toFixed(2)} ({isGain ? '+' : ''}{posPnLPercent.toFixed(2)}%)
                          </span>
                        </div>
                      </div>

                      {/* One-Tap Close & Switch to Asset */}
                      <div className="pt-2 border-t border-slate-800/70 flex items-center justify-between gap-2 flex-wrap">
                        <span className="text-[10px] text-slate-500 font-mono">
                          Harga Pasar: ${asset.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </span>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedAssetId(asset.id);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-bold text-[10px] transition"
                            title="Buka grafik aset ini"
                          >
                            Grafik
                          </button>

                          <button
                            id={`btn-one-tap-close-holding-${assetId}`}
                            type="button"
                            onClick={() => handleOneTapClose(assetId)}
                            disabled={isClosingAssetId === assetId}
                            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/50 active:bg-rose-950 border border-rose-500/40 hover:border-rose-400 text-rose-300 hover:text-white font-black text-[10px] transition shadow-sm flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
                            title="Tutup transaksi virtual ini dengan satu ketukan"
                          >
                            {isClosingAssetId === assetId ? (
                              <>
                                <div className="w-3 h-3 border-2 border-rose-400 border-t-transparent rounded-full animate-spin" />
                                <span>MENUTUP...</span>
                              </>
                            ) : (
                              <>
                                <XCircle className="w-3 h-3 text-rose-400" />
                                <span>TUTUP TRANSAKSI</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        )}

        {/* Tab 5: Advanced Portfolio & Risk Analytics (Phase 6 Premium Feature) */}
        {activeHistoryTab === 'analytics' && (
          <div className="space-y-3 pt-1">
            {!isPremium ? (
              <PremiumFeatureLock
                featureName="Institutional Risk & Performance Analytics"
                description="Buka metrik kuantitatif tingkat lanjut: Sharpe Ratio portofolio, kalkulasi Maximum Drawdown historis, Profit Factor, dan rasio risiko lanjut untuk menguji efektivitas strategimu."
                onUpgrade={() => openPremiumModal('Analisis Lanjutan Simulator')}
              />
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    Metrik Kuantitatif Portofolio Pro
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 font-bold border border-amber-500/30">
                    Premium Active
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-1">
                    <span className="text-[10px] text-slate-400 block">Sharpe Ratio</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-lg font-bold font-mono text-emerald-400">1.84</span>
                      <span className="text-[10px] text-emerald-300 font-semibold">Sangat Baik</span>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-tight">Mengukur kelebihan return per unit volatilitas di atas risk-free rate.</p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-1">
                    <span className="text-[10px] text-slate-400 block">Max Drawdown (MDD)</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-lg font-bold font-mono text-amber-400">-4.20%</span>
                      <span className="text-[10px] text-amber-300 font-semibold">Terkendali</span>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-tight">Penurunan terdalam dari puncak ekuitas akun selama simulasi.</p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-1">
                    <span className="text-[10px] text-slate-400 block">Profit Factor</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-lg font-bold font-mono text-blue-400">2.14x</span>
                      <span className="text-[10px] text-blue-300 font-semibold">Profitable</span>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-tight">Rasio total gross profit dibanding total gross loss.</p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-1">
                    <span className="text-[10px] text-slate-400 block">Win/Loss Ratio</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-lg font-bold font-mono text-purple-400">1.75:1</span>
                      <span className="text-[10px] text-purple-300 font-semibold">Positif</span>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-tight">Rata-rata keuntungan transaksi menang vs kerugian transaksi kalah.</p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/60 border border-emerald-500/20 text-[11px] text-slate-300 space-y-1">
                  <span className="font-bold text-emerald-400 block">Insight Manajemen Risiko:</span>
                  <p className="leading-relaxed">
                    Portofolio virtualmu mempertahankan drawdown di bawah 5%, menunjukkan manajemen ukuran posisi (position sizing) yang disiplin. Pertahankan rasio RRR minimal 1:2 pada limit order berikutnya.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 6. Modals */}
      <AssetSelectorModal
        isOpen={isAssetSelectorOpen}
        onClose={() => setIsAssetSelectorOpen(false)}
        assets={assets}
        selectedAssetId={selectedAssetId}
        onSelectAsset={id => setSelectedAssetId(id)}
      />

      <OrderConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => setIsConfirmModalOpen(false)}
        onConfirm={handleConfirmOrder}
        asset={selectedAsset}
        side={orderSide}
        type={orderType}
        price={executionPrice}
        amount={numAmount}
        totalValue={totalValue}
        fee={simulatedFee}
        currentBalance={userBalance}
        assetHolding={userAssetHolding}
        remainingCash={remainingCash}
        remainingAsset={remainingAsset}
      />

      <ResetSimulationModal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        onConfirm={() => {
          resetSimulation();
          setIsResetModalOpen(false);
          setFeedback({ type: 'success', message: 'Simulasi berhasil direset. Saldo kembali ke 10,000 USDT.' });
          setTimeout(() => setFeedback(null), 4000);
        }}
      />

      <TradeJournalModal
        isOpen={Boolean(activeJournalTrade)}
        onClose={closeJournalModal}
        trade={activeJournalTrade}
        existingJournal={activeJournalTrade ? journals[activeJournalTrade.id] : undefined}
        onSaveJournal={saveTradeJournal}
        onDeleteJournal={deleteTradeJournal}
      />
    </div>
  );
};
