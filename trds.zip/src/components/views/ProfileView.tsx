import React, { useState } from 'react';
import {
  User,
  Sparkles,
  Award,
  BookOpen,
  Bell,
  Volume2,
  Globe,
  Moon,
  Sun,
  HelpCircle,
  Info,
  ShieldCheck,
  FileText,
  RotateCcw,
  ChevronRight,
  TrendingUp,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VirtualNoticeBanner } from '../common/VirtualNoticeBanner';
import { PremiumStatusCard } from '../premium/PremiumStatusCard';
import { PremiumBadge } from '../premium/PremiumBadge';
import officialLogoImg from '../../assets/images/trds_official_logo.png';

type LegalModalType = 'about' | 'privacy' | 'terms' | 'help' | null;

export const ProfileView: React.FC = () => {
  const {
    userProfile,
    theme,
    toggleTheme,
    achievements,
    lessons,
    completedLessonIds,
    resetVirtualAccount,
    isPremium,
    customerInfo,
    activePackageId,
    openPremiumModal,
    setShowOpeningScreen
  } = useApp();

  const [activeModal, setActiveModal] = useState<LegalModalType>(null);
  const [notifications, setNotifications] = useState(userProfile.notificationsEnabled);
  const [sound, setSound] = useState(userProfile.soundEnabled);
  const [language, setLanguage] = useState(userProfile.language);
  const [confirmReset, setConfirmReset] = useState(false);

  const completedLessons = completedLessonIds.length;
  const unlockedAchievements = achievements.filter(a => a.isUnlocked).length;
  const winRatePercent = userProfile.tradesCount > 0
    ? Math.round((userProfile.profitableTradesCount / userProfile.tradesCount) * 100)
    : 0;

  const premiumEntitlement = customerInfo?.entitlements['trds_premium'] || null;

  return (
    <div id="profile-view" className="space-y-4 pb-28 pt-1 px-4 max-w-md mx-auto">
      {/* Top Banner */}
      <VirtualNoticeBanner compact />

      {/* User Header Profile Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 shadow-xl flex items-center gap-3.5">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-400 to-teal-600 p-0.5 shadow-lg shadow-emerald-500/20 shrink-0">
          <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center text-emerald-400">
            <User className="w-7 h-7" />
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <h1 className="text-base font-bold text-white truncate">{userProfile.name}</h1>
            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30">
              Lv.{userProfile.level}
            </span>
          </div>
          <span className="text-xs text-slate-400 block">{userProfile.handle}</span>
          <span className="text-[11px] font-semibold text-emerald-400 mt-0.5 block">
            {userProfile.levelTitle}
          </span>
        </div>
      </div>

      {/* Phase 6: RevenueCat Subscription Status Card */}
      <PremiumStatusCard
        isPremium={isPremium}
        entitlement={premiumEntitlement}
        activePackageId={activePackageId}
        onOpenPremium={() => openPremiumModal('TRDS Premium Member Portal')}
      />

      {/* Trading & Learning Performance Stats Grid */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 block mb-0.5">Total XP</span>
          <span className="text-sm font-bold text-amber-400 font-mono">
            {userProfile.totalXp ?? (userProfile.level > 1 ? 250 : userProfile.currentXp)}
          </span>
        </div>
        <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 block mb-0.5">Win Rate Sim</span>
          <span className="text-sm font-bold text-emerald-400 font-mono">{winRatePercent}%</span>
        </div>
        <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 block mb-0.5">Modul Selesai</span>
          <span className="text-sm font-bold text-blue-400 font-mono">
            {completedLessons}/{lessons.length}
          </span>
        </div>
      </div>

      {/* XP & Progress Section */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-white flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-400" />
            Kemajuan Level Trader
          </span>
          <span className="text-amber-400 font-semibold text-[11px]">
            {userProfile.currentXp} / {userProfile.nextLevelXp} XP
          </span>
        </div>

        <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
          <div
            className="bg-amber-400 h-2 rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, (userProfile.currentXp / userProfile.nextLevelXp) * 100)}%` }}
          />
        </div>
      </div>

      {/* Achievements Gallery */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            Koleksi Badge Pencapaian ({unlockedAchievements}/{achievements.length})
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {achievements.map(ach => (
            <div
              key={ach.id}
              className={`p-3 rounded-xl border text-xs space-y-1 ${
                ach.isUnlocked
                  ? 'bg-slate-900/90 border-emerald-500/30'
                  : 'bg-slate-950/40 border-slate-800/80 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 min-w-0">
                  <span className="font-bold text-white text-[11px] truncate">{ach.title}</span>
                  {ach.isPremium && <PremiumBadge size="sm" />}
                </div>
                <span className="text-[10px] text-amber-400 font-bold shrink-0">+{ach.xpReward} XP</span>
              </div>
              <p className="text-[10px] text-slate-400 leading-tight">{ach.description}</p>
              <span
                className={`text-[9px] font-bold block ${
                  ach.isUnlocked ? 'text-emerald-400' : 'text-slate-500'
                }`}
              >
                {ach.isUnlocked ? '✓ Terbuka' : `Progress: ${ach.progress}/${ach.maxProgress}`}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Settings List */}
      <div className="p-2 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
        <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3 pt-2 block">
          Pengaturan Aplikasi
        </span>

        {/* Theme Toggle */}
        <div className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 transition">
          <div className="flex items-center gap-2.5 text-xs text-slate-200">
            {theme === 'dark' ? <Moon className="w-4 h-4 text-emerald-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
            <span>Tema Tampilan</span>
          </div>
          <button
            onClick={toggleTheme}
            className="px-2.5 py-1 rounded-lg bg-slate-800 text-xs font-semibold text-slate-300 border border-slate-700"
          >
            {theme === 'dark' ? 'Dark Mode (Aktif)' : 'Light Mode (Aktif)'}
          </button>
        </div>

        {/* Language Selection */}
        <div className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 transition">
          <div className="flex items-center gap-2.5 text-xs text-slate-200">
            <Globe className="w-4 h-4 text-blue-400" />
            <span>Bahasa</span>
          </div>
          <select
            aria-label="Pilih Bahasa"
            value={language}
            onChange={e => setLanguage(e.target.value as 'id' | 'en')}
            className="bg-slate-800 text-slate-300 text-xs font-semibold px-2 py-1 rounded-lg border border-slate-700"
          >
            <option value="id">Bahasa Indonesia</option>
            <option value="en">English (US)</option>
          </select>
        </div>

        {/* Notifications */}
        <div className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 transition">
          <div className="flex items-center gap-2.5 text-xs text-slate-200">
            <Bell className="w-4 h-4 text-purple-400" />
            <span>Notifikasi Pasar & Belajar</span>
          </div>
          <button
            onClick={() => setNotifications(!notifications)}
            className={`w-10 h-5 rounded-full transition-colors relative ${
              notifications ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                notifications ? 'left-5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Sound FX */}
        <div className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 transition">
          <div className="flex items-center gap-2.5 text-xs text-slate-200">
            <Volume2 className="w-4 h-4 text-teal-400" />
            <span>Efek Suara Eksekusi Sim</span>
          </div>
          <button
            onClick={() => setSound(!sound)}
            className={`w-10 h-5 rounded-full transition-colors relative ${
              sound ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                sound ? 'left-5' : 'left-0.5'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Legal & Educational Info Links */}
      <div className="p-2 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
        <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3 pt-2 block">
          Informasi & Bantuan
        </span>

        <button
          onClick={() => setShowOpeningScreen(true)}
          className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 text-xs text-slate-200 transition text-left"
        >
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>Tampilkan Welcome & Opening Screen</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() => setActiveModal('about')}
          className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 text-xs text-slate-200 transition"
        >
          <div className="flex items-center gap-2.5">
            <Info className="w-4 h-4 text-blue-400" />
            <span>Tentang TRDS (Shipathon 2026)</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() => setActiveModal('terms')}
          className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 text-xs text-slate-200 transition"
        >
          <div className="flex items-center gap-2.5">
            <FileText className="w-4 h-4 text-amber-400" />
            <span>Ketentuan Layanan & Simulasi</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() => setActiveModal('privacy')}
          className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 text-xs text-slate-200 transition"
        >
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Kebijakan Privasi</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() => setActiveModal('help')}
          className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/60 text-xs text-slate-200 transition"
        >
          <div className="flex items-center gap-2.5">
            <HelpCircle className="w-4 h-4 text-purple-400" />
            <span>Pusat Bantuan & FAQ</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>
      </div>

      {/* Reset Virtual Account Button */}
      <div className="pt-1">
        {!confirmReset ? (
          <button
            onClick={() => setConfirmReset(true)}
            className="w-full py-2.5 rounded-xl border border-red-500/30 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Saldo & Riwayat Simulasi Virtual</span>
          </button>
        ) : (
          <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-xs space-y-2 text-center">
            <span className="text-red-300 font-bold block">
              Kembalikan saldo virtual ke $10,000 dan hapus order?
            </span>
            <div className="flex gap-2 justify-center">
              <button
                onClick={() => {
                  resetVirtualAccount();
                  setConfirmReset(false);
                }}
                className="px-4 py-1.5 rounded-lg bg-red-500 text-white font-bold text-xs"
              >
                Ya, Reset Sekarang
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs"
              >
                Batal
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modals for About / Terms / Privacy / Help */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full max-w-md max-h-[85vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-2xl p-5 overflow-y-auto space-y-3.5 shadow-2xl text-xs text-slate-300">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-sm text-white capitalize">
                {activeModal === 'about' && 'Tentang TRDS'}
                {activeModal === 'terms' && 'Ketentuan Layanan & Simulasi'}
                {activeModal === 'privacy' && 'Kebijakan Privasi'}
                {activeModal === 'help' && 'Pusat Bantuan TRDS'}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {activeModal === 'about' && (
              <div className="space-y-3 leading-relaxed">
                <div className="flex flex-col items-center justify-center py-2">
                  <div className="relative flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full bg-cyan-500/20 blur-xl pointer-events-none" />
                    <img
                      src={officialLogoImg}
                      alt="TRDS Official Logo"
                      className="relative z-10 w-24 h-24 aspect-square object-contain drop-shadow-md"
                    />
                  </div>
                </div>
                <p>
                  <strong>TRDS (Trading Simulator & Education)</strong> dikembangkan untuk berpartisipasi dalam ajang <strong>RevenueCat Shipathon 2026</strong>.
                </p>
                <p>
                  Misi TRDS adalah mendemokratisasi pemahaman finansial dengan memberikan sarana latihan pasar nyata tanpa risiko uang sungguhan, didukung oleh AI tutor dan sistem gamifikasi.
                </p>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-semibold text-emerald-400 block mb-1">Versi V1 Foundation:</span>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-400 text-[11px]">
                    <li>Full Virtual Balances ($10,000 starting demo funds)</li>
                    <li>No Real Money Deposits or Custody</li>
                    <li>Built-in TRDS AI Educational Tutor</li>
                    <li>Cross-Platform Architecture (Android-first, iOS ready)</li>
                  </ul>
                </div>
              </div>
            )}

            {activeModal === 'terms' && (
              <div className="space-y-2 leading-relaxed">
                <p className="font-semibold text-amber-400">Pernyataan Non-Kustodi & Non-Exchange:</p>
                <p>
                  TRDS bukan merupakan bursa berjangka, broker, maupun penyedia layanan keuangan berizin. Seluruh nilai portofolio, keuntungan, dan kerugian adalah <strong>hasil simulasi matematis belaka</strong>.
                </p>
                <p>
                  Pengguna tidak dapat melakukan deposit, penarikan, pemindahan dana tunai, atau transfer kripto nyata.
                </p>
              </div>
            )}

            {activeModal === 'privacy' && (
              <div className="space-y-2 leading-relaxed">
                <p>
                  Privasi pengguna adalah prioritas kami. Pada tahap V1, semua progres belajar, saldo virtual, dan preferensi tema disimpan secara lokal dalam session aplikasi.
                </p>
                <p>
                  Kami tidak menjual data pribadi atau aktivitas simulasi Anda kepada pihak ketiga manapun.
                </p>
              </div>
            )}

            {activeModal === 'help' && (
              <div className="space-y-2.5 leading-relaxed">
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-white block mb-0.5">Bagaimana cara memulai simulasi?</span>
                  <p className="text-slate-400 text-[11px]">
                    Buka tab <strong>Simulator</strong>, pilih aset dari daftar dropdown, masukkan jumlah, lalu tekan tombol Beli atau Jual Virtual.
                  </p>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-white block mb-0.5">Apakah saya bisa kehilangan uang nyata?</span>
                  <p className="text-slate-400 text-[11px]">
                    Sama sekali tidak. TRDS 100% menggunakan dana virtual untuk tujuan edukasi.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
