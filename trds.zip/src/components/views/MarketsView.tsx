import React, { useState, useMemo } from 'react';
import { RefreshCw, Star, ShieldCheck, SlidersHorizontal, Sparkles, Compass, ChevronRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MarketFilter, MarketCategory, Asset } from '../../types';
import { SearchBar } from '../common/SearchBar';
import { CategoryTabs } from '../common/CategoryTabs';
import { MarketRow } from '../common/MarketRow';
import { MarketDataStatusBadge } from '../intelligence/MarketDataStatusBadge';

export const MarketsView: React.FC = () => {
  const {
    assets,
    favoriteAssetIds,
    toggleFavorite,
    openAssetDetail,
    openMarketIntelligence,
    navigateToTrade,
    isRefreshing,
    lastRefreshed,
    refreshMarkets
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<MarketFilter>('all');
  const [activeCategory, setActiveCategory] = useState<MarketCategory>('all');

  const filteredAssets = useMemo(() => {
    return assets.filter(asset => {
      // Search matching (symbol or name)
      const q = searchQuery.trim().toLowerCase();
      if (q) {
        const matchesSymbol = asset.symbol.toLowerCase().includes(q);
        const matchesName = asset.name.toLowerCase().includes(q);
        if (!matchesSymbol && !matchesName) return false;
      }

      // Asset Class Category matching
      if (activeCategory !== 'all' && asset.category !== activeCategory) {
        return false;
      }

      // Horizontal Filter Tab matching
      if (activeFilter === 'favorites') {
        return favoriteAssetIds.includes(asset.id);
      }
      if (activeFilter === 'gainers') {
        return asset.change24h > 0;
      }
      if (activeFilter === 'losers') {
        return asset.change24h < 0;
      }
      if (activeFilter === 'trending') {
        // High volatility or high volume
        return Math.abs(asset.change24h) >= 2.0;
      }
      if (activeFilter === 'volume') {
        // Sort or filter high volume ($1B+)
        return asset.volume.includes('B');
      }

      return true;
    });
  }, [assets, searchQuery, activeFilter, activeCategory, favoriteAssetIds]);

  const [showRefreshToast, setShowRefreshToast] = useState(false);

  const handleRefresh = () => {
    refreshMarkets();
    setShowRefreshToast(true);
    setTimeout(() => setShowRefreshToast(false), 2000);
  };

  // Formatted last refreshed time
  const formattedRefreshTime = lastRefreshed.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });

  return (
    <div id="markets-view" className="space-y-4 pb-28 pt-2 px-4 max-w-md mx-auto">
      {/* Refreshed feedback badge */}
      {showRefreshToast && (
        <div className="flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold mx-auto w-fit animate-in fade-in slide-in-from-top-2 duration-200">
          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          <span>Harga pasar simulasi berhasil diperbarui</span>
        </div>
      )}

      {/* 4. Label Pasar Demo & Disclaimer Banner */}
      <div
        id="demo-market-banner"
        className="flex items-center justify-between px-3.5 py-2.5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 shadow-sm"
      >
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-cyan-500/15 text-cyan-400 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-white tracking-tight">
                MARKET FEED
              </span>
              <span className="text-[10px] text-slate-400">• Educational Simulation</span>
            </div>
            <span className="text-[10px] text-slate-400 block">
              Harga pasar virtual untuk pelatihan analisa & eksekusi
            </span>
          </div>
        </div>

        <MarketDataStatusBadge status={isRefreshing ? 'UPDATING' : 'SIMULATED'} size="sm" />
      </div>

      {/* TRDS MARKET PULSE Card */}
      <div
        id="trds-market-pulse-entry-card"
        className="p-3.5 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/50 border border-cyan-500/30 hover:border-cyan-500/50 transition shadow-sm space-y-2.5"
      >
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center shrink-0 border border-cyan-500/30">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-white tracking-tight">
                  TRDS Market Pulse
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300">
                  Analisis
                </span>
              </div>
              <span className="text-[11px] text-slate-300 font-medium block">
                Apa yang sedang terjadi di pasar?
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => openMarketIntelligence()}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 hover:from-cyan-300 hover:to-sky-400 text-slate-950 font-black text-xs transition flex items-center gap-1 shadow-md shadow-cyan-500/20 active:scale-95 shrink-0"
          >
            <span>Buka Pulse</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center justify-between text-[10px] text-slate-400 bg-slate-950/50 px-2.5 py-1.5 rounded-xl border border-slate-800/80">
          <span>Skor Kondisi • RSI • Moving Average • Konteks Risiko</span>
          <span className="text-cyan-400 font-semibold font-mono">TRDS Analysis</span>
        </div>
      </div>

      {/* 1. Header Markets */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black text-white tracking-tight">Markets</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700/60">
              {filteredAssets.length} Aset
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
            <span className="flex items-center gap-1 font-semibold text-cyan-300/90">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
              DATA SIMULASI
            </span>
            <span>•</span>
            <span>Last Updated: {formattedRefreshTime}</span>
          </div>
        </div>

        {/* Quick Header Actions: Quick Favorite Toggle & Refresh Button */}
        <div className="flex items-center gap-1.5">
          {/* Quick Favorite Filter Shortcut */}
          <button
            id="btn-filter-quick-favorite"
            type="button"
            onClick={() => {
              setActiveFilter(prev => (prev === 'favorites' ? 'all' : 'favorites'));
            }}
            className={`p-2 rounded-xl border transition active:scale-95 ${
              activeFilter === 'favorites'
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-amber-400'
            }`}
            aria-label="Filter Cepat Favorit"
            title="Tampilkan Favorit"
          >
            <Star className={`w-4 h-4 ${activeFilter === 'favorites' ? 'fill-amber-400' : ''}`} />
          </button>

          {/* Indikator Refresh Pasar Button */}
          <button
            id="btn-refresh-markets"
            type="button"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className={`p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-emerald-400 hover:border-emerald-500/30 transition active:scale-95 flex items-center justify-center ${
              isRefreshing ? 'opacity-70 cursor-not-allowed' : ''
            }`}
            aria-label="Refresh Harga Pasar Demo"
            title="Refresh Pasar Demo"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Search Field */}
      <SearchBar
        value={searchQuery}
        onChange={setSearchQuery}
        placeholder="Cari simbol atau nama aset (misal: BTC, ETH, SOL)..."
      />

      {/* 2. Kategori Horizontal Filter Tabs */}
      <CategoryTabs
        activeFilter={activeFilter}
        onFilterChange={setActiveFilter}
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
        showCategoryPills
      />

      {/* 3. Asset List */}
      <div className="space-y-2.5">
        {filteredAssets.length === 0 ? (
          activeFilter === 'favorites' && !searchQuery ? (
            <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800 space-y-2.5">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center mx-auto">
                <Star className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-white">
                Belum ada aset favorit yang disimpan
              </p>
              <p className="text-[11px] text-slate-400 max-w-xs mx-auto leading-relaxed">
                Sentuh ikon bintang di samping aset manapun pada daftar pasar untuk memasukkannya ke daftar pantauan cepat.
              </p>
              <button
                type="button"
                onClick={() => setActiveFilter('all')}
                className="mt-2 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition active:scale-95"
              >
                Jelajahi Semua Pasar
              </button>
            </div>
          ) : (
            <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800 space-y-2">
              <p className="text-xs font-semibold text-slate-300">
                Tidak ada aset yang sesuai kriteria pencarian/filter.
              </p>
              <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                Coba ganti kata kunci pencarian atau ganti filter kategori di atas.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setActiveFilter('all');
                  setActiveCategory('all');
                }}
                className="mt-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-emerald-400 text-xs font-bold transition"
              >
                Reset Semua Filter
              </button>
            </div>
          )
        ) : (
          filteredAssets.map(asset => (
            <MarketRow
              key={asset.id}
              asset={asset}
              isFavorite={favoriteAssetIds.includes(asset.id)}
              onToggleFavorite={toggleFavorite}
              onClick={openAssetDetail}
              onTradeClick={navigateToTrade}
            />
          ))
        )}
      </div>
    </div>
  );
};

