import React from 'react';
import { Sparkles, Moon, Sun, Bell, TrendingUp } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import officialLogoImg from '../../assets/images/trds_official_logo.png';

export const HeaderBar: React.FC = () => {
  const {
    theme,
    toggleTheme,
    userProfile,
    totalPortfolioValue,
    openPortfolioModal,
    openNotificationsModal
  } = useApp();

  return (
    <header
      id="trds-header-bar"
      className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5 transition-colors"
    >
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* Brand identity */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-slate-900 border border-cyan-500/30 flex items-center justify-center overflow-hidden shadow-lg shadow-cyan-500/15">
            <img
              src={officialLogoImg}
              alt="TRDS Official Logo"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black tracking-tight text-white text-base">TRDS</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.2 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/25">
                Sim V1
              </span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-slate-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Virtual Market Open</span>
            </div>
          </div>
        </div>

        {/* User XP and Controls */}
        <div className="flex items-center gap-2">
          {/* Level badge */}
          <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span className="font-bold text-amber-400">Lv.{userProfile.level}</span>
            <span className="text-slate-500">•</span>
            <span>{userProfile.currentXp} XP</span>
          </div>

          {/* Quick Balance pill / Virtual portfolio shortcut */}
          <button
            id="btn-header-portfolio-shortcut"
            type="button"
            onClick={openPortfolioModal}
            className="flex items-center gap-1.5 h-9 px-2.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-400 text-xs font-semibold transition active:scale-95 touch-manipulation cursor-pointer"
            aria-label="Buka Rincian Portofolio Virtual"
            title="Lihat Rincian Portofolio Virtual"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>${totalPortfolioValue.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</span>
          </button>

          {/* Theme toggle */}
          <button
            id="btn-toggle-theme"
            onClick={toggleTheme}
            className="h-9 w-9 flex items-center justify-center rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition active:scale-95 touch-manipulation"
            aria-label="Ganti Tema"
            title={theme === 'dark' ? 'Beralih ke Light Mode' : 'Beralih ke Dark Mode'}
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
          </button>

          {/* Notification bell */}
          <button
            id="btn-notifications"
            type="button"
            onClick={openNotificationsModal}
            className="relative h-9 w-9 flex items-center justify-center rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition active:scale-95 touch-manipulation"
            aria-label="Notifikasi TRDS"
            title="Notifikasi & Pembaruan"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-950" />
          </button>
        </div>
      </div>
    </header>
  );
};
