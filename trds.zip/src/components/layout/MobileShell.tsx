import React, { useState } from 'react';
import { Smartphone, Monitor, Wifi, Battery, Signal } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { HeaderBar } from './HeaderBar';
import { BottomNavBar } from './BottomNavBar';
import { HomeView } from '../views/HomeView';
import { MarketsView } from '../views/MarketsView';
import { SimulatorView } from '../views/SimulatorView';
import { LearnView } from '../views/LearnView';
import { TrdsAiView } from '../views/TrdsAiView';
import { ProfileView } from '../views/ProfileView';
import { AssetDetailModal } from '../common/AssetDetailModal';
import { PortfolioDetailModal } from '../common/PortfolioDetailModal';
import { NotificationsModal } from '../common/NotificationsModal';
import { AchievementToast } from '../common/AchievementToast';
import { AchievementsModal } from '../learn/AchievementsModal';
import { DailyChallengesModal } from '../learn/DailyChallengesModal';
import { PremiumModal } from '../premium/PremiumModal';
import { OpeningExperience } from '../opening/OpeningExperience';
import { MarketIntelligenceModal } from '../intelligence/MarketIntelligenceModal';

export const MobileShell: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    favoriteAssetIds,
    toggleFavorite,
    navigateToTrade,
    isPortfolioModalOpen,
    closePortfolioModal,
    isNotificationsModalOpen,
    closeNotificationsModal,
    selectedDetailAsset,
    closeAssetDetail,
    isPremiumModalOpen,
    closePremiumModal,
    premiumModalContext,
    showOpeningScreen,
    setShowOpeningScreen,
    assets,
    isPremium,
    openPremiumModal,
    isMarketIntelligenceOpen,
    selectedIntelligenceAsset,
    openMarketIntelligence,
    closeMarketIntelligence,
    askAiAboutMarketIntelligence,
    openLessonModal,
    lessons
  } = useApp();

  const [deviceFrameMode, setDeviceFrameMode] = useState<boolean>(true);

  const renderActiveView = () => {
    switch (activeTab) {
      case 'home':
        return <HomeView />;
      case 'markets':
        return <MarketsView />;
      case 'simulator':
        return <SimulatorView />;
      case 'learn':
        return <LearnView />;
      case 'ai':
        return <TrdsAiView />;
      case 'profile':
        return <ProfileView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div
      id="trds-root-container"
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start transition-colors selection:bg-emerald-500/30 selection:text-emerald-300"
    >
      {/* Desktop view controller floating pill */}
      <div className="hidden lg:flex fixed top-3 right-4 z-50 items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-xs text-slate-300 shadow-xl backdrop-blur-md">
        <span className="text-[11px] text-slate-400">Mode Tampilan:</span>
        <button
          onClick={() => setDeviceFrameMode(true)}
          className={`px-2 py-0.5 rounded-md flex items-center gap-1 transition ${
            deviceFrameMode ? 'bg-emerald-500 text-slate-950 font-bold' : 'hover:text-white'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Android Mobile</span>
        </button>
        <button
          onClick={() => setDeviceFrameMode(false)}
          className={`px-2 py-0.5 rounded-md flex items-center gap-1 transition ${
            !deviceFrameMode ? 'bg-emerald-500 text-slate-950 font-bold' : 'hover:text-white'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Responsive Web</span>
        </button>
      </div>

      {/* Main Container: Android device frame or responsive layout */}
      <div
        className={`w-full transition-all duration-300 ${
          deviceFrameMode
            ? 'max-w-md my-0 sm:my-4 sm:rounded-[36px] sm:border-[6px] sm:border-slate-800/90 sm:shadow-[0_0_50px_rgba(0,0,0,0.8)] sm:overflow-hidden relative min-h-screen sm:min-h-[850px] bg-slate-950'
            : 'max-w-xl min-h-screen bg-slate-950'
        }`}
      >
        {/* Mobile Status Bar (Simulated Android) */}
        <div className="flex items-center justify-between px-5 pt-2 pb-1 text-[11px] font-semibold text-slate-400 select-none bg-slate-950/90">
          <span className="font-mono">09:41</span>
          <div className="w-20 h-4 rounded-full bg-slate-900 mx-auto hidden sm:block border border-slate-800/80" />
          <div className="flex items-center gap-1.5">
            <Signal className="w-3 h-3 text-slate-300" />
            <Wifi className="w-3 h-3 text-slate-300" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px]">100%</span>
              <Battery className="w-3.5 h-3.5 text-slate-300" />
            </div>
          </div>
        </div>

        {/* Conditional Opening Experience vs Main Application */}
        {showOpeningScreen ? (
          <OpeningExperience
            onComplete={() => {
              setShowOpeningScreen(false);
              setActiveTab('home');
            }}
          />
        ) : (
          <>
            {/* Top Header Bar */}
            <HeaderBar />

            {/* Dynamic Active View */}
            <main className="w-full relative">{renderActiveView()}</main>

            {/* Bottom Persistent Navigation Bar */}
            <BottomNavBar />
          </>
        )}

        {/* Modals */}
        <AssetDetailModal
          isOpen={!!selectedDetailAsset}
          asset={selectedDetailAsset}
          isFavorite={selectedDetailAsset ? favoriteAssetIds.includes(selectedDetailAsset.id) : false}
          onClose={closeAssetDetail}
          onToggleFavorite={toggleFavorite}
          onTrade={assetId => {
            closeAssetDetail();
            navigateToTrade(assetId);
          }}
          onOpenMarketIntelligence={asset => {
            closeAssetDetail();
            openMarketIntelligence(asset);
          }}
        />

        {/* TRDS Market Intelligence Modal */}
        <MarketIntelligenceModal
          isOpen={isMarketIntelligenceOpen}
          asset={selectedIntelligenceAsset}
          allAssets={assets}
          isPremium={isPremium}
          onClose={closeMarketIntelligence}
          onSelectAsset={asset => openMarketIntelligence(asset)}
          onOpenSimulator={assetId => {
            closeMarketIntelligence();
            navigateToTrade(assetId);
          }}
          onAskAi={(asset, intel) => {
            askAiAboutMarketIntelligence(asset, intel);
          }}
          onOpenLesson={lessonId => {
            closeMarketIntelligence();
            const targetLesson = lessons.find(l => l.id === lessonId);
            if (targetLesson) {
              setActiveTab('learn');
              openLessonModal(targetLesson);
            } else {
              setActiveTab('learn');
            }
          }}
          onOpenPremiumPaywall={featureName => {
            openPremiumModal(featureName);
          }}
        />

        <PortfolioDetailModal
          isOpen={isPortfolioModalOpen}
          onClose={closePortfolioModal}
        />

        <NotificationsModal
          isOpen={isNotificationsModalOpen}
          onClose={closeNotificationsModal}
        />

        {/* Phase 4: Achievement Toast & Global Modals */}
        <AchievementToast />
        <AchievementsModal />
        <DailyChallengesModal />

        {/* Phase 6: RevenueCat Premium Paywall Modal */}
        <PremiumModal
          isOpen={isPremiumModalOpen}
          onClose={closePremiumModal}
          contextFeatureName={premiumModalContext}
        />
      </div>
    </div>
  );
};

