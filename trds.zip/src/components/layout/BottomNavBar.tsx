import React from 'react';
import { Home, TrendingUp, SlidersHorizontal, BookOpen, Bot, User } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { NavTab } from '../../types';

interface TabItem {
  id: NavTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
}

const TABS: TabItem[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'markets', label: 'Markets', icon: TrendingUp },
  { id: 'simulator', label: 'Simulator', icon: SlidersHorizontal },
  { id: 'learn', label: 'Learn', icon: BookOpen, badge: 'XP' },
  { id: 'ai', label: 'TRDS AI', icon: Bot, badge: 'AI' },
  { id: 'profile', label: 'Profile', icon: User }
];

export const BottomNavBar: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();

  return (
    <nav
      id="trds-bottom-nav"
      className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 dark:bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 px-2 py-1.5 transition-colors"
      aria-label="Main Navigation"
    >
      <div className="max-w-md mx-auto grid grid-cols-6 gap-1 items-center">
        {TABS.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              id={`nav-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              role="tab"
              aria-selected={isActive}
              aria-label={tab.label}
              className={`relative flex flex-col items-center justify-center min-h-[50px] py-1 px-1 rounded-xl transition-all duration-150 active:scale-95 touch-manipulation select-none ${
                isActive
                  ? 'text-emerald-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 stroke-[2.4]' : 'stroke-[1.8]'
                  }`}
                />
                {tab.badge && !isActive && (
                  <span className="absolute -top-1 -right-2 px-1 py-0.2 bg-emerald-500/20 text-emerald-400 text-[9px] font-bold rounded-full border border-emerald-500/30">
                    {tab.badge}
                  </span>
                )}
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50" />
                )}
              </div>
              <span
                className={`text-[10px] mt-1 whitespace-nowrap tracking-tight ${
                  isActive ? 'text-emerald-400' : 'text-slate-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
