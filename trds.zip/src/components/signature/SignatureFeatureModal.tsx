import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  ShieldCheck,
  BookOpen,
  Award,
  ArrowRight,
  RefreshCw,
  Info,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Heart,
  Layers,
  Compass,
  Link2,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  TRDS_SIGNATURE_FEATURES,
  EDUCATIONAL_REMINDERS,
  SignatureFeatureItem
} from '../../data/signatureFeaturesData';

interface SignatureFeatureModalProps {
  featureId: string | null;
  onClose: () => void;
  onSelectFeature: (id: string) => void;
}

export const SignatureFeatureModal: React.FC<SignatureFeatureModalProps> = ({
  featureId,
  onClose,
  onSelectFeature
}) => {
  const {
    userProfile,
    totalPortfolioValue,
    totalSimulatedPnL,
    simulatedPnLPercent,
    trades,
    lessons,
    completedLessonIds,
    achievements,
    isPremium,
    premiumTier,
    setActiveTab,
    openPortfolioModal,
    openAchievementsModal
  } = useApp();

  const [reminderIndex, setReminderIndex] = useState(0);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  if (!featureId) return null;

  const currentIndex = TRDS_SIGNATURE_FEATURES.findIndex(f => f.id === featureId);
  const currentFeature: SignatureFeatureItem =
    currentIndex !== -1 ? TRDS_SIGNATURE_FEATURES[currentIndex] : TRDS_SIGNATURE_FEATURES[0];

  const handlePrevFeature = () => {
    const prevIndex =
      (currentIndex - 1 + TRDS_SIGNATURE_FEATURES.length) % TRDS_SIGNATURE_FEATURES.length;
    onSelectFeature(TRDS_SIGNATURE_FEATURES[prevIndex].id);
    setIsDropdownOpen(false);
  };

  const handleNextFeature = () => {
    const nextIndex = (currentIndex + 1) % TRDS_SIGNATURE_FEATURES.length;
    onSelectFeature(TRDS_SIGNATURE_FEATURES[nextIndex].id);
    setIsDropdownOpen(false);
  };

  const handleSelect = (id: string) => {
    onSelectFeature(id);
    setIsDropdownOpen(false);
  };

  const handleNextReminder = () => {
    setReminderIndex(prev => (prev + 1) % EDUCATIONAL_REMINDERS.length);
  };

  const completedLessonsCount = completedLessonIds.length;
  const unlockedAchievementsCount = achievements.filter(a => a.isUnlocked).length;

  const row1Features = TRDS_SIGNATURE_FEATURES.filter(f => f.row === 1);
  const row2Features = TRDS_SIGNATURE_FEATURES.filter(f => f.row === 2);

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/85 backdrop-blur-md"
        role="dialog"
        aria-modal="true"
        aria-labelledby="signature-modal-title"
      >
        {/* Backdrop click to dismiss */}
        <div
          className="absolute inset-0"
          onClick={() => {
            if (isDropdownOpen) {
              setIsDropdownOpen(false);
            } else {
              onClose();
            }
          }}
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, y: 35, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 35, scale: 0.98 }}
          transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        >
          {/* Top Decorative Touch Bar (Mobile) */}
          <div className="w-12 h-1 bg-slate-700/80 rounded-full mx-auto mt-3 mb-1 shrink-0 sm:hidden" />

          {/* Modal Header */}
          <div className="flex items-center justify-between px-5 pt-3 pb-2.5 border-b border-slate-800/80 shrink-0 bg-slate-900/95">
            <div className="flex items-center gap-2">
              <span
                id="signature-modal-title"
                className="text-xs font-black tracking-widest text-emerald-400 uppercase font-mono"
              >
                FITUR KHAS TRDS
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-bold border border-slate-700">
                Prinsip #{currentFeature.order} dari 7
              </span>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition active:scale-90 cursor-pointer"
              aria-label="Tutup modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* ============================================================ */}
          {/* RESPONSIVE FEATURE SELECTOR                                  */}
          {/* Mobile: Dropdown Selector (Option B) + Prev/Next Controls   */}
          {/* Desktop/Tablet: Clean Segmented Grid (Option A)             */}
          {/* ============================================================ */}
          <div className="px-4 py-2.5 bg-slate-950/70 border-b border-slate-800/80 shrink-0 relative">
            {/* MOBILE SELECTOR VIEW (OPTION B) */}
            <div className="block sm:hidden">
              <div className="flex items-center gap-2">
                {/* Previous Feature Button */}
                <button
                  type="button"
                  onClick={handlePrevFeature}
                  className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 active:scale-95 text-slate-300 hover:text-white flex items-center justify-center shrink-0 transition"
                  aria-label="Prinsip sebelumnya"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                {/* Central Selector Trigger */}
                <button
                  type="button"
                  id="trds-mobile-feature-selector-btn"
                  onClick={() => setIsDropdownOpen(prev => !prev)}
                  className={`flex-1 min-h-[42px] px-3 py-1.5 rounded-xl border transition-all duration-150 flex items-center justify-between gap-2 text-left cursor-pointer active:scale-[0.98] ${
                    isDropdownOpen
                      ? 'bg-slate-850 border-emerald-500/50 shadow-[0_0_12px_rgba(16,185,129,0.15)] ring-1 ring-emerald-500/30'
                      : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                  }`}
                  aria-expanded={isDropdownOpen}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-base shrink-0">{currentFeature.emoji}</span>
                    <div className="min-w-0">
                      <span className="text-xs font-black text-white tracking-wide block truncate">
                        {currentFeature.title}
                      </span>
                      <span className="text-[10px] text-slate-400 block truncate">
                        {currentFeature.shortDesc}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 pl-1">
                    <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-800 text-emerald-400 border border-slate-750">
                      {currentFeature.order}/7
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                        isDropdownOpen ? 'rotate-180 text-emerald-400' : ''
                      }`}
                    />
                  </div>
                </button>

                {/* Next Feature Button */}
                <button
                  type="button"
                  onClick={handleNextFeature}
                  className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 active:scale-95 text-slate-300 hover:text-white flex items-center justify-center shrink-0 transition"
                  aria-label="Prinsip berikutnya"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* EXPANDABLE DROPDOWN MENU FOR MOBILE */}
              <AnimatePresence>
                {isDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -6, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -6, scale: 0.98 }}
                    transition={{ duration: 0.15 }}
                    className="absolute left-4 right-4 top-full mt-1.5 z-30 bg-slate-900/98 border border-slate-750 rounded-2xl shadow-2xl backdrop-blur-xl p-2 max-h-[58vh] overflow-y-auto space-y-1"
                  >
                    <div className="px-2 py-1 flex items-center justify-between border-b border-slate-800 mb-1">
                      <span className="text-[9px] font-bold text-slate-400 tracking-wider uppercase">
                        PILIH PRINSIP TRDS
                      </span>
                      <span className="text-[9px] font-mono text-emerald-400">
                        7 SISTEM UTUH
                      </span>
                    </div>

                    {TRDS_SIGNATURE_FEATURES.map(feature => {
                      const isSelected = feature.id === currentFeature.id;
                      return (
                        <button
                          key={feature.id}
                          type="button"
                          onClick={() => handleSelect(feature.id)}
                          className={`w-full p-2 rounded-xl text-left transition-all duration-120 flex items-center justify-between gap-2.5 cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-500/15 border border-emerald-500/50 text-white shadow-[0_0_10px_rgba(16,185,129,0.12)]'
                              : 'bg-slate-900/90 hover:bg-slate-800 border border-slate-800/80 text-slate-300 hover:text-white'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span className="w-8 h-8 rounded-lg bg-slate-850 border border-slate-750 flex items-center justify-center text-base shrink-0">
                              {feature.emoji}
                            </span>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-black tracking-wide text-white">
                                  {feature.title}
                                </span>
                                <span className="text-[9px] font-mono text-slate-400">
                                  #{feature.order}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-400 truncate">
                                {feature.shortDesc}
                              </p>
                            </div>
                          </div>

                          {isSelected ? (
                            <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </span>
                          ) : (
                            <span className="text-[9px] font-mono text-slate-500 shrink-0">
                              Pilih &rarr;
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* DESKTOP / TABLET SEGMENTED SELECTOR (OPTION A) */}
            <div className="hidden sm:block space-y-1.5">
              <div className="grid grid-cols-4 gap-1.5">
                {row1Features.map(feature => {
                  const isSelected = feature.id === currentFeature.id;
                  return (
                    <button
                      key={feature.id}
                      type="button"
                      onClick={() => handleSelect(feature.id)}
                      className={`p-1.5 rounded-xl border text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-500/15 border-emerald-500/60 shadow-[0_0_12px_rgba(16,185,129,0.15)] ring-1 ring-emerald-500/30 text-white'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-1">
                        <span className="text-xs">{feature.emoji}</span>
                        <span className="text-[10px] font-black truncate">{feature.title}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="flex justify-center gap-1.5">
                {row2Features.map(feature => {
                  const isSelected = feature.id === currentFeature.id;
                  return (
                    <button
                      key={feature.id}
                      type="button"
                      onClick={() => handleSelect(feature.id)}
                      className={`w-[calc((100%-12px)/4)] p-1.5 rounded-xl border text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-500/15 border-emerald-500/60 shadow-[0_0_12px_rgba(16,185,129,0.15)] ring-1 ring-emerald-500/30 text-white'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-1">
                        <span className="text-xs">{feature.emoji}</span>
                        <span className="text-[10px] font-black truncate">{feature.title}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ============================================================ */}
          {/* SCROLLABLE DETAIL BODY: STRICT HIERARCHY AS REQUESTED        */}
          {/* ============================================================ */}
          <div className="p-5 overflow-y-auto space-y-6 text-slate-200 flex-1">
            <motion.div
              key={currentFeature.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.18 }}
              className="space-y-6"
            >
              {/* 1. [ICON BESAR] + NAMA FITUR + DESKRIPSI SINGKAT */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-slate-850/80 to-slate-950/90 border border-slate-800 relative overflow-hidden shadow-inner">
                <div className="flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-4">
                  {/* ICON BESAR */}
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-900 border border-slate-700/80 flex items-center justify-center text-3xl sm:text-4xl shadow-xl shrink-0">
                    <span>{currentFeature.emoji}</span>
                  </div>

                  {/* NAMA FITUR & DESKRIPSI SINGKAT */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-center sm:justify-start gap-2 mb-1">
                      <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        PRINSIP #{currentFeature.order}
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium">
                        TRDS Signature
                      </span>
                    </div>

                    <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight">
                      {currentFeature.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-slate-300 font-medium mt-1 leading-snug">
                      {currentFeature.tagline}
                    </p>

                    <div className="mt-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/90 text-slate-300 text-[10px] font-medium border border-slate-750">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>Peran: {currentFeature.ecosystemRole}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* ──────────────────────────────────────────────────────── */}
              {/* DIVIDER */}
              <div className="h-px bg-slate-800/80 w-full" />

              {/* 2. "PRINSIP TRDS" (Penjelasan Utama) */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <Compass className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-black text-white tracking-wider uppercase">
                    PRINSIP TRDS
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3">
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-normal">
                    {currentFeature.prinsipTRDS}
                  </p>

                  {/* Bullet points of principles */}
                  {currentFeature.principles && currentFeature.principles.length > 0 && (
                    <div className="pt-3 border-t border-slate-800/80 space-y-2">
                      <span className="text-[11px] font-bold text-slate-400 block uppercase tracking-wider">
                        Poin-Poin Utama:
                      </span>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                        {currentFeature.principles.map((prinsip, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            <span>{prinsip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>

              {/* ──────────────────────────────────────────────────────── */}
              {/* DIVIDER */}
              <div className="h-px bg-slate-800/80 w-full" />

              {/* 3. "CARA KERJA" (Penjelasan Fungsi Fitur) */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                    <Layers className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-black text-white tracking-wider uppercase">
                    CARA KERJA
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    {currentFeature.caraKerja}
                  </p>
                </div>
              </div>

              {/* ──────────────────────────────────────────────────────── */}
              {/* DIVIDER */}
              <div className="h-px bg-slate-800/80 w-full" />

              {/* 4. "TERHUBUNG DENGAN" (Data & Fungsi Existing yang Relevan) */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                    <Link2 className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-black text-white tracking-wider uppercase">
                    TERHUBUNG DENGAN
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3">
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {currentFeature.terhubungDenganDeskripsi}
                  </p>

                  {/* REAL DATA INTEGRATION (100% REAL CONTEXT, NO FAKE DATA) */}

                  {/* A. ZONA DAMAI */}
                  {currentFeature.id === 'zona-damai' && (
                    <div className="space-y-2 pt-1">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750">
                          <span className="text-[10px] text-slate-400 block">Mode Pembelajaran</span>
                          <span className="text-xs font-bold text-emerald-400 mt-0.5 block">
                            100% Edukasi Mandiri
                          </span>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750">
                          <span className="text-[10px] text-slate-400 block">Tekanan Bersaing</span>
                          <span className="text-xs font-bold text-sky-400 mt-0.5 block">
                            0% (Fokus Diri)
                          </span>
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-850/40 border border-slate-750/70 text-[11px] text-slate-300 leading-relaxed flex items-start gap-2">
                        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>
                          Tidak ada leaderboard kompetitif atau tekanan pamer keuntungan. Pembelajaran berjalan tenang dengan ritme Anda sendiri.
                        </span>
                      </div>
                    </div>
                  )}

                  {/* B. LINDUNG NILAI */}
                  {currentFeature.id === 'lindung-nilai' && (
                    <div className="space-y-2 pt-1">
                      <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Saldo Kas Virtual Tersedia</span>
                          <span className="font-mono font-bold text-white">
                            ${userProfile.virtualBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Total Nilai Portofolio</span>
                          <span className="font-mono font-bold text-emerald-400">
                            ${totalPortfolioValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 leading-relaxed flex items-start gap-2">
                        <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <span>
                          Manajemen risiko virtual melindungi nalar keputusan. Seluruh transaksi di TRDS adalah simulasi edukasi bebas risiko uang riil.
                        </span>
                      </div>
                    </div>
                  )}

                  {/* C. JEJAK JUJUR */}
                  {currentFeature.id === 'jejak-jujur' && (
                    <div className="space-y-2 pt-1">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750">
                          <span className="text-[10px] text-slate-400 block">Total Transaksi Tercatat</span>
                          <span className="text-sm font-black font-mono text-white mt-0.5 block">
                            {trades.length} Transaksi
                          </span>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750">
                          <span className="text-[10px] text-slate-400 block">Simulated PnL Akumulatif</span>
                          <span
                            className={`text-sm font-black font-mono mt-0.5 block ${
                              totalSimulatedPnL >= 0 ? 'text-emerald-400' : 'text-red-400'
                            }`}
                          >
                            {totalSimulatedPnL >= 0 ? '+' : ''}${totalSimulatedPnL.toFixed(2)} ({simulatedPnLPercent.toFixed(2)}%)
                          </span>
                        </div>
                      </div>

                      {/* Riwayat Asli atau Pesan Transparan */}
                      <div className="space-y-1.5 pt-1">
                        <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">
                          Log Transaksi Terkini:
                        </span>
                        {trades.length === 0 ? (
                          <div className="p-3 rounded-xl bg-slate-850/40 border border-slate-750/70 text-center text-xs text-slate-400">
                            Belum ada aktivitas transaksi. Mulai berlatih di Simulator untuk membangun jejak belajarmu.
                          </div>
                        ) : (
                          <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
                            {trades.slice(0, 3).map(trade => (
                              <div
                                key={trade.id}
                                className="p-2 rounded-lg bg-slate-850 border border-slate-750 flex items-center justify-between text-xs"
                              >
                                <div className="flex items-center gap-2">
                                  <span
                                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                      trade.side === 'buy'
                                        ? 'bg-emerald-500/20 text-emerald-400'
                                        : 'bg-red-500/20 text-red-400'
                                    }`}
                                  >
                                    {trade.side.toUpperCase()}
                                  </span>
                                  <span className="font-bold text-white">{trade.symbol}</span>
                                </div>
                                <span className="font-mono text-slate-300">
                                  ${trade.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* D. TUJUAN BERSAMA */}
                  {currentFeature.id === 'tujuan-bersama' && (
                    <div className="space-y-2 pt-1">
                      <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2.5">
                          <BookOpen className="w-4 h-4 text-sky-400 shrink-0" />
                          <div>
                            <span className="font-bold text-white block">Modul Edukasi Selesai</span>
                            <span className="text-[10px] text-slate-400">
                              {completedLessonsCount} dari {lessons.length} modul kurikulum
                            </span>
                          </div>
                        </div>
                        <span className="font-mono font-bold text-sky-400 text-xs">
                          {Math.round((completedLessonsCount / Math.max(lessons.length, 1)) * 100)}%
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2.5">
                          <Award className="w-4 h-4 text-amber-400 shrink-0" />
                          <div>
                            <span className="font-bold text-white block">Pencapaian Prestasi</span>
                            <span className="text-[10px] text-slate-400">
                              {unlockedAchievementsCount} dari {achievements.length} badge terbuka
                            </span>
                          </div>
                        </div>
                        <span className="font-mono font-bold text-amber-400 text-xs">
                          {unlockedAchievementsCount}/{achievements.length}
                        </span>
                      </div>
                    </div>
                  )}

                  {/* E. TUMBUH BERSAMA */}
                  {currentFeature.id === 'tumbuh-bersama' && (
                    <div className="space-y-2.5 pt-1">
                      <div className="grid grid-cols-4 gap-1 text-center">
                        <div className="p-2 rounded-xl bg-slate-850 border border-emerald-500/30">
                          <span className="text-[9px] font-black text-emerald-400 block">1. BELAJAR</span>
                          <span className="text-[8px] text-slate-400 block mt-0.5">Teori Dasar</span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-850 border border-sky-500/30">
                          <span className="text-[9px] font-black text-sky-400 block">2. BERLATIH</span>
                          <span className="text-[8px] text-slate-400 block mt-0.5">Simulasi</span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-850 border border-indigo-500/30">
                          <span className="text-[9px] font-black text-indigo-400 block">3. MEMAHAMI</span>
                          <span className="text-[8px] text-slate-400 block mt-0.5">Uji Kuis</span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-850 border border-purple-500/30">
                          <span className="text-[9px] font-black text-purple-400 block">4. TUMBUH</span>
                          <span className="text-[8px] text-slate-400 block mt-0.5">Disiplin XP</span>
                        </div>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750 flex items-center justify-between text-xs">
                        <div>
                          <span className="text-[10px] text-slate-400 block">Tingkat Pengguna Saat Ini</span>
                          <span className="font-bold text-white">
                            Level {userProfile.level} • {userProfile.levelTitle}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block">Akumulasi Belajar</span>
                          <span className="font-mono font-bold text-amber-400">
                            {userProfile.currentXp} XP
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* F. JELAS TANPA RAHASIA */}
                  {currentFeature.id === 'jelas-tanpa-rahasia' && (
                    <div className="space-y-2 pt-1 text-xs">
                      <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750 flex items-center justify-between">
                        <div>
                          <span className="font-bold text-white block">Modal Awal Simulasi</span>
                          <span className="text-[10px] text-slate-400">Dana latihan virtual cuma-cuma</span>
                        </div>
                        <span className="font-mono font-bold text-emerald-400">$10,000.00</span>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750 flex items-center justify-between">
                        <div>
                          <span className="font-bold text-white block">Komisi Transaksi Simulasi</span>
                          <span className="text-[10px] text-slate-400">Bebas biaya tersembunyi</span>
                        </div>
                        <span className="font-mono font-bold text-emerald-400">$0.00 (0%)</span>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-850/80 border border-slate-750 flex items-center justify-between">
                        <div>
                          <span className="font-bold text-white block">Status Keanggotaan</span>
                          <span className="text-[10px] text-slate-400">
                            {isPremium ? `Paket Pro (${premiumTier})` : 'Akses Edukasi Standar'}
                          </span>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isPremium ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-slate-800 text-slate-300'
                        }`}>
                          {isPremium ? 'PRO AKTIF' : 'GRATIS'}
                        </span>
                      </div>
                    </div>
                  )}

                  {/* G. PENGINGAT BAIK */}
                  {currentFeature.id === 'pengingat-baik' && (
                    <div className="space-y-2 pt-1">
                      <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/40 to-slate-900 border border-emerald-500/30">
                        <div className="flex items-start gap-2.5">
                          <Heart className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5 fill-emerald-500/20" />
                          <div>
                            <p className="text-xs font-bold text-emerald-200 leading-snug">
                              "{EDUCATIONAL_REMINDERS[reminderIndex]}"
                            </p>
                            <button
                              type="button"
                              onClick={handleNextReminder}
                              className="mt-2 text-[10px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition"
                            >
                              <RefreshCw className="w-3 h-3" />
                              <span>Ambil Pengingat Lain ({reminderIndex + 1}/{EDUCATIONAL_REMINDERS.length})</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Contextual Quick Navigation Action */}
                  <div className="pt-2">
                    {currentFeature.id === 'zona-damai' && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          setActiveTab('learn');
                        }}
                        className="w-full py-2.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                      >
                        <span>Mulai Belajar Tenang di Learn</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {currentFeature.id === 'lindung-nilai' && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          setActiveTab('simulator');
                        }}
                        className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                      >
                        <span>Praktikkan Kelola Risiko di Simulator</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {currentFeature.id === 'jejak-jujur' && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          openPortfolioModal();
                        }}
                        className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                      >
                        <span>Buka Portofolio Lengkap</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {currentFeature.id === 'tujuan-bersama' && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          setActiveTab('learn');
                        }}
                        className="w-full py-2.5 px-4 rounded-xl bg-rose-500 hover:bg-rose-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                      >
                        <span>Buka Modul Belajar & Kuis</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {currentFeature.id === 'tumbuh-bersama' && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          openAchievementsModal();
                        }}
                        className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                      >
                        <span>Buka Prestasi & Level</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {currentFeature.id === 'jelas-tanpa-rahasia' && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          setActiveTab('profile');
                        }}
                        className="w-full py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                      >
                        <span>Periksa Pengaturan & Profil Akun</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {currentFeature.id === 'pengingat-baik' && (
                      <button
                        type="button"
                        onClick={handleNextReminder}
                        className="w-full py-2.5 px-4 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                      >
                        <span>Ambil Pengingat Lain</span>
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* ──────────────────────────────────────────────────────── */}
              {/* 5. [ KEMBALI KE FITUR KHAS ] BUTTON */}
              <div className="pt-2 pb-1">
                <button
                  type="button"
                  id="trds-back-to-signature-btn"
                  onClick={onClose}
                  className="w-full py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs sm:text-sm tracking-wider uppercase transition-all duration-150 border border-slate-700/60 shadow-sm cursor-pointer min-h-[46px] flex items-center justify-center gap-2"
                >
                  <span>KEMBALI KE FITUR KHAS</span>
                </button>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
