import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Info, ShieldCheck } from 'lucide-react';
import {
  TRDS_SIGNATURE_FEATURES,
  SignatureFeatureItem
} from '../../data/signatureFeaturesData';
import { SignatureFeatureModal } from './SignatureFeatureModal';

interface FeatureCardProps {
  feature: SignatureFeatureItem;
  onClick: () => void;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ feature, onClick }) => {
  return (
    <button
      type="button"
      id={`sig-feature-${feature.id}`}
      onClick={onClick}
      className="group relative w-full p-2 sm:p-2.5 rounded-2xl bg-[linear-gradient(180deg,rgba(0,229,255,0.22)_0%,rgba(0,51,255,0.32)_48%,rgba(2,11,36,0.95)_100%)]"
      aria-label={`Buka detail fitur khas ${feature.title}`}
    >
      {/* Subtle Ambient Hover Glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

      {/* Top Feature Order Badge */}
      <div className="w-full flex items-center justify-between pointer-events-none mb-1">
        <span className="text-[8px] font-bold text-slate-500 font-mono tracking-tighter">
          #{feature.order}
        </span>
        <span className="w-1.5 h-1.5 rounded-full bg-slate-700 group-hover:bg-emerald-400 transition-colors" />
      </div>

      {/* Feature Icon / Emoji */}
      <div className="relative my-0.5">
        <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-850 border border-slate-750 flex items-center justify-center text-lg sm:text-xl shadow-inner group-hover:scale-105 transition-transform">
          <span>{feature.emoji}</span>
        </div>
      </div>

      {/* Feature Name & Short Description */}
      <div className="w-full mt-1 min-w-0">
        <span className="text-[10px] sm:text-[11px] font-black text-white tracking-tight leading-tight block truncate group-hover:text-emerald-300 transition-colors">
          {feature.title}
        </span>
        <p className="text-[8px] sm:text-[8.5px] text-slate-400 leading-snug mt-0.5 line-clamp-2">
          {feature.shortDesc}
        </p>
      </div>
    </button>
  );
};

export const SignatureFeaturesSection: React.FC = () => {
  const [selectedFeatureId, setSelectedFeatureId] = useState<string | null>(null);

  const row1Features = TRDS_SIGNATURE_FEATURES.filter(f => f.row === 1);
  const row2Features = TRDS_SIGNATURE_FEATURES.filter(f => f.row === 2);

  return (
    <section
      id="home-signature-features"
      className="space-y-3 pt-1 select-none"
      aria-labelledby="signature-features-heading"
    >
      {/* Section Header with Official Title & Subtitle */}
      <div className="flex items-end justify-between px-0.5">
        <div>
          <div className="flex items-center gap-1.5">
            <h2
              id="signature-features-heading"
              className="text-xs sm:text-sm font-black text-white tracking-wider uppercase"
            >
              FITUR KHAS TRDS
            </h2>
            <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              7 SISTEM
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium mt-0.5">
            7 prinsip yang membangun pengalaman TRDS.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setSelectedFeatureId(TRDS_SIGNATURE_FEATURES[0].id)}
          className="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 transition flex items-center gap-1 shrink-0 pb-0.5"
        >
          <Sparkles className="w-3 h-3" />
          <span>Buka Sistem</span>
        </button>
      </div>

      {/* MANDATORY GRID SYSTEM: 4 CARDS ROW 1, 3 CARDS ROW 2 (CENTERED) */}
      <div className="relative overflow-hidden p-3 rounded-3xl bg-[linear-gradient(180deg,rgba(0,229,255,0.25)_0%,rgba(0,51,255,0.35)_45%,rgba(2,11,36,0.95)_100%)] border border-[#00E5FF]/30 shadow-[0_8px_32px_rgba(0,51,255,0.22),0_0_20px_rgba(0,229,255,0.12)]">
        {/* Subtle Electric Cyan Ambient Glow at the top edge */}
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-4/5 h-20 bg-[#00E5FF]/20 blur-2xl pointer-events-none rounded-full" />
        {/* BARIS PERTAMA: 4 KARTU */}
        <div className="grid grid-cols-4 gap-2">
          {row1Features.map(feature => (
            <FeatureCard
              key={feature.id}
              feature={feature}
              onClick={() => setSelectedFeatureId(feature.id)}
            />
          ))}
        </div>

        {/* BARIS KEDUA: 3 KARTU (CENTERED DENGAN LEBAR IDENTIK) */}
        <div className="flex justify-center gap-2 pt-2">
          {row2Features.map(feature => (
            <div key={feature.id} className="w-[calc((100%-24px)/4)]">
              <FeatureCard
                feature={feature}
                onClick={() => setSelectedFeatureId(feature.id)}
              />
            </div>
          ))}
        </div>

        {/* Bottom Ecosystem Connecting Philosophy Indicator */}
        <div className="mt-3 pt-2.5 border-t border-slate-850/80 flex items-center justify-between text-[10px] text-slate-400 px-1">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
            <span className="truncate">Ekosistem saling terhubung • Tekan kartu untuk detail</span>
          </div>
          <span className="text-[9px] font-mono text-slate-500 shrink-0 uppercase">
            TRDS • 100% Edukasi
          </span>
        </div>
      </div>

      {/* Dedicated Interactive Detail Modal */}
      <SignatureFeatureModal
        featureId={selectedFeatureId}
        onClose={() => setSelectedFeatureId(null)}
        onSelectFeature={id => setSelectedFeatureId(id)}
      />
    </section>
  );
};
