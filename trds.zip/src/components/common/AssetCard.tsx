import React from 'react';
import { TrendingUp, TrendingDown, Star } from 'lucide-react';
import { Asset } from '../../types';
import { Sparkline } from './Sparkline';

interface AssetCardProps {
  asset: Asset;
  onClick: (asset: Asset) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (assetId: string) => void;
  className?: string;
}

export const AssetCard: React.FC<AssetCardProps> = ({
  asset,
  onClick,
  isFavorite = false,
  onToggleFavorite,
  className = ''
}) => {
  const isPositive = asset.change24h >= 0;

  return (
    <div
      onClick={() => onClick(asset)}
      className={`min-w-[145px] p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800/90 hover:border-slate-700 cursor-pointer shrink-0 transition duration-200 flex flex-col justify-between shadow-sm relative group active:scale-98 ${className}`}
      role="button"
      tabIndex={0}
      aria-label={`Lihat detail ${asset.symbol}`}
    >
      {/* Top line: Symbol, Favorite toggle, 24h% badge */}
      <div className="flex items-center justify-between gap-1 mb-1.5">
        <div className="flex items-center gap-1">
          <span className="text-xs font-bold text-white group-hover:text-emerald-300 transition">
            {asset.symbol}
          </span>
        </div>

        {onToggleFavorite && (
          <button
            type="button"
            onClick={e => {
              e.stopPropagation();
              onToggleFavorite(asset.id);
            }}
            className="p-1 -mr-1 text-slate-500 hover:text-amber-400 transition"
            aria-label={isFavorite ? 'Hapus dari favorit' : 'Tambah ke favorit'}
          >
            <Star className={`w-3.5 h-3.5 ${isFavorite ? 'text-amber-400 fill-amber-400' : ''}`} />
          </button>
        )}
      </div>

      {/* Price */}
      <div className="mb-2">
        <span className="text-xs font-bold text-white font-mono tracking-tight block">
          ${asset.price.toLocaleString('en-US', {
            minimumFractionDigits: asset.price < 1 ? 4 : 2,
            maximumFractionDigits: asset.price < 1 ? 4 : 2
          })}
        </span>
      </div>

      {/* Bottom line: Sparkline & Change% badge */}
      <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-800/60">
        <div className="w-[60px] h-[22px] flex items-center">
          <Sparkline data={asset.sparkline} isPositive={isPositive} width={60} height={20} showGradient />
        </div>

        <div
          className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md flex items-center gap-0.5 shrink-0 ${
            isPositive ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'
          }`}
        >
          {isPositive ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
          <span>
            {isPositive ? '+' : ''}{asset.change24h}%
          </span>
        </div>
      </div>
    </div>
  );
};
