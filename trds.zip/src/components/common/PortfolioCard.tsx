import React from 'react';
import { TrendingUp, TrendingDown, ShieldCheck, Eye, SlidersHorizontal, DollarSign } from 'lucide-react';

interface PortfolioCardProps {
  totalValue: number;
  simulatedPnL: number;
  pnlPercent: number;
  cashBalance: number;
  onViewPortfolio: () => void;
  onGoToSimulator: () => void;
  className?: string;
}

export const PortfolioCard: React.FC<PortfolioCardProps> = ({
  totalValue,
  simulatedPnL,
  pnlPercent,
  cashBalance,
  onViewPortfolio,
  onGoToSimulator,
  className = ''
}) => {
  const isPositive = simulatedPnL >= 0;

  return (
    <div
      id="virtual-portfolio-card"
      className={`relative overflow-hidden rounded-2xl p-4 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 shadow-xl ${className}`}
    >
      {/* Ambient glow accent */}
      <div
        className={`absolute -top-10 -right-10 w-40 h-40 rounded-full blur-3xl pointer-events-none opacity-20 ${
          isPositive ? 'bg-emerald-500' : 'bg-red-500'
        }`}
      />

      <div className="relative z-10 space-y-3.5">
        {/* Header row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-semibold text-slate-300">Total Nilai Portofolio Virtual</span>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800/80 text-emerald-400 border border-emerald-500/20">
            USD Sim
          </span>
        </div>

        {/* Big Balance Display */}
        <div>
          <div className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
            ${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>

        {/* PnL & Cash Metrics Grid */}
        <div className="grid grid-cols-2 gap-2 pt-2.5 pb-1 border-t border-slate-800/90 text-xs">
          {/* Simulated PnL */}
          <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60">
            <span className="text-[10px] text-slate-400 block mb-0.5">Simulated PnL</span>
            <div
              className={`inline-flex items-center gap-1 font-bold text-xs ${
                isPositive ? 'text-emerald-400' : 'text-red-400'
              }`}
            >
              {isPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              <span className="font-mono">
                {isPositive ? '+' : ''}${simulatedPnL.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[10px] font-semibold opacity-90">
                ({isPositive ? '+' : ''}{pnlPercent.toFixed(2)}%)
              </span>
            </div>
          </div>

          {/* Virtual Cash Balance */}
          <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60">
            <span className="text-[10px] text-slate-400 block mb-0.5">Saldo Tunai Virtual</span>
            <div className="flex items-center gap-1 font-bold text-slate-200 text-xs font-mono">
              <DollarSign className="w-3 h-3 text-emerald-400" />
              <span>${cashBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons: View Portfolio & Simulator */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            id="btn-view-portfolio"
            type="button"
            onClick={onViewPortfolio}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/80 text-xs font-semibold transition active:scale-98"
            aria-label="View Portfolio Details"
          >
            <Eye className="w-3.5 h-3.5 text-blue-400" />
            <span>View Portfolio</span>
          </button>

          <button
            id="btn-portfolio-simulator"
            type="button"
            onClick={onGoToSimulator}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition shadow-md shadow-emerald-500/15 active:scale-98"
            aria-label="Open Trading Simulator"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-950" />
            <span>Simulator</span>
          </button>
        </div>
      </div>
    </div>
  );
};
