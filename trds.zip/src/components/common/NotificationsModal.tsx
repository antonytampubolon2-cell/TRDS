import React from 'react';
import { X, Bell, CheckCircle2, TrendingUp, Award, Sparkles } from 'lucide-react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'market' | 'achievement' | 'challenge';
}

const MOCK_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Pasar Virtual Buka',
    message: 'Simulasi market TRDS 24/7 aktif. Coba uji strategi tanpa risiko uang nyata.',
    time: '5 menit lalu',
    type: 'market'
  },
  {
    id: 'notif-2',
    title: 'Daily Challenge Baru',
    message: 'Tantangan hari ini: "Eksplorasi Pasar" siap diselesaikan untuk klaim +40 XP.',
    time: '1 jam lalu',
    type: 'challenge'
  },
  {
    id: 'notif-3',
    title: 'Peringatan Harga Demo (BTC)',
    message: 'Bitcoin melonjak +3.42% ke level $64,280 di pasar simulasi demo.',
    time: '2 jam lalu',
    type: 'market'
  }
];

export const NotificationsModal: React.FC<NotificationsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      id="notifications-modal"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="notif-modal-title"
    >
      <div className="w-full max-w-md max-h-[85vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl text-slate-200">
        <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1 mb-2 sm:hidden" />

        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 id="notif-modal-title" className="text-sm font-bold text-white">
                Notifikasi Simulator
              </h3>
              <span className="text-[10px] text-slate-400">Pemberitahuan latihan & aktivitas</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
            aria-label="Tutup Notifikasi"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2.5">
          {MOCK_NOTIFICATIONS.map(notif => (
            <div
              key={notif.id}
              className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  {notif.title}
                </span>
                <span className="text-[10px] text-slate-500">{notif.time}</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">{notif.message}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
