import React from 'react';
import { ShieldCheck, Info } from 'lucide-react';

interface Props {
  compact?: boolean;
}

export const VirtualNoticeBanner: React.FC<Props> = ({ compact = false }) => {
  if (compact) {
    return (
      <div
        id="virtual-notice-compact"
        className="flex items-center justify-center gap-1.5 py-1 px-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-medium rounded-full"
      >
        <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
        <span>100% Saldo Virtual • Tanpa Uang Nyata</span>
      </div>
    );
  }

  return (
    <div
      id="virtual-notice-card"
      className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-slate-300 text-xs shadow-sm"
    >
      <div className="p-1 rounded-lg bg-emerald-500/15 text-emerald-400 shrink-0 mt-0.5">
        <Info className="w-4 h-4" />
      </div>
      <div className="flex-1 leading-relaxed">
        <span className="font-semibold text-emerald-400 block mb-0.5">
          Platform Simulasi & Edukasi Finansial
        </span>
        TRDS V1 adalah aplikasi pembelajaran mandiri. Semua transaksi menggunakan uang virtual untuk latihan tanpa risiko finansial.
      </div>
    </div>
  );
};
