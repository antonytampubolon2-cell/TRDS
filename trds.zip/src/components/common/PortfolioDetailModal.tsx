import React from 'react';
import {
  X,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  Wallet,
  ArrowUpRight,
  PieChart,
  DollarSign
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface PortfolioDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PortfolioDetailModal: React.FC<PortfolioDetailModalProps> = ({
  isOpen,
  onClose
}) => {
  const {
    userProfile,
    holdings,
    holdingsMeta,
    assets,
    totalPortfolioValue,
    totalSimulatedPnL,
    simulatedPnLPercent,
    realizedPnL,
    unrealizedPnL,
    navigateToTrade
  } = useApp();

  if (!isOpen) return null;

  const isPositive = totalSimulatedPnL >= 0;

  // Active holdings items
  const activeHoldings = Object.entries(holdings)
    .filter(([_, qty]) => Number(qty) > 0)
    .map(([assetId, qty]) => {
      const asset = assets.find(a => a.id === assetId);
      const numQty = Number(qty);
      const value = asset ? numQty * asset.price : 0;
      const meta = holdingsMeta[assetId];
      const avgPrice = meta?.avgBuyPrice || asset?.price || 0;
      const costBasis = numQty * avgPrice;
      const pnl = value - costBasis;
      const pnlPct = costBasis > 0 ? (pnl / costBasis) * 100 : 0;

      return {
        assetId,
        asset,
        qty: numQty,
        avgPrice,
        value,
        pnl,
        pnlPct
      };
    })
    .sort((a, b) => b.value - a.value);

  const totalAssetValue = activeHoldings.reduce((sum, item) => sum + item.value, 0);

  return (
    <div
      id="portfolio-detail-modal"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="portfolio-modal-title"
    >
      <div className="w-full max-w-md max-h-[88vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl text-slate-200">
        <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1 mb-2 sm:hidden" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <h3 id="portfolio-modal-title" className="text-sm font-bold text-white">
                Rincian Portofolio Virtual
              </h3>
              <span className="text-[10px] text-slate-400">
                100% Saldo Simulasi • Tanpa Uang Nyata
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
            aria-label="Tutup Rincian Portofolio"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Summary Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">Total Nilai Akun Demo</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Demo Active
            </span>
          </div>

          <div className="text-3xl font-black text-white font-mono tracking-tight">
            ${totalPortfolioValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>

          {/* Balance breakdown metrics */}
          <div className="grid grid-cols-2 gap-2 pt-2.5 border-t border-slate-800/80 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block">Saldo Kas Virtual (USDT)</span>
              <span className="font-bold text-slate-200 font-mono text-sm">
                ${userProfile.virtualBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 block">Nilai Aset Virtual</span>
              <span className="font-bold text-slate-200 font-mono text-sm">
                ${totalAssetValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {/* PnL Breakdown: Realized vs Unrealized */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-[11px] bg-slate-950/60 p-2.5 rounded-xl">
            <div>
              <span className="text-slate-400 block text-[10px]">Realized PnL</span>
              <span
                className={`font-mono font-bold ${
                  realizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {realizedPnL >= 0 ? '+' : ''}${realizedPnL.toFixed(2)}
              </span>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px]">Unrealized PnL</span>
              <span
                className={`font-mono font-bold ${
                  unrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {unrealizedPnL >= 0 ? '+' : ''}${unrealizedPnL.toFixed(2)}
              </span>
            </div>

            <div className="text-right">
              <span className="text-slate-400 block text-[10px]">Total PnL</span>
              <span
                className={`font-mono font-bold ${
                  isPositive ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {isPositive ? '+' : ''}${totalSimulatedPnL.toFixed(2)} ({isPositive ? '+' : ''}{simulatedPnLPercent.toFixed(2)}%)
              </span>
            </div>
          </div>
        </div>

        {/* Active Holdings List */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              Aset Virtual yang Dimiliki ({activeHoldings.length})
            </span>
            <span className="text-[11px] text-slate-500 font-mono">
              Total: ${totalAssetValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </span>
          </div>

          {activeHoldings.length === 0 ? (
            <div className="p-4 rounded-2xl bg-slate-950/40 border border-slate-800/60 text-center text-xs text-slate-500">
              Belum ada aset virtual yang dibeli. Buka Simulator untuk mengeksekusi order virtual!
            </div>
          ) : (
            <div className="space-y-2">
              {activeHoldings.map(item => {
                const isGain = item.pnl >= 0;
                return (
                  <div
                    key={item.assetId}
                    onClick={() => {
                      onClose();
                      navigateToTrade(item.assetId);
                    }}
                    className="p-3 rounded-xl bg-slate-950/60 hover:bg-slate-800/50 border border-slate-800/80 flex items-center justify-between cursor-pointer transition"
                    role="button"
                    tabIndex={0}
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">
                          {item.asset?.symbol || item.assetId.toUpperCase()}
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {item.qty} {item.asset?.unit}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Avg: ${item.avgPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })} • Pasar: ${item.asset?.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="text-right flex items-center gap-2">
                      <div>
                        <span className="text-xs font-bold text-white font-mono block">
                          ${item.value.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </span>
                        <span
                          className={`text-[10px] font-semibold font-mono ${
                            isGain ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isGain ? '+' : ''}${item.pnl.toFixed(2)} ({isGain ? '+' : ''}{item.pnlPct.toFixed(2)}%)
                        </span>
                      </div>
                      <ArrowUpRight className="w-4 h-4 text-slate-500" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Safety Footer */}
        <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-[11px] text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            Simulasi edukasi 100% aman. Data dan saldo portofolio tersimpan di perangkat lokal.
          </span>
        </div>
      </div>
    </div>
  );
};
