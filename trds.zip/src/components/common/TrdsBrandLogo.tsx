import React from 'react';
import officialLogoImg from '../../assets/images/trds_official_logo.png';

interface TrdsBrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showWordmark?: boolean;
  showTagline?: boolean;
  className?: string;
  id?: string;
}

export const TrdsBrandLogo: React.FC<TrdsBrandLogoProps> = ({
  size = 'lg',
  className = '',
  id = 'trds-official-brand-logo'
}) => {
  // Proportional responsive scaling matching the official TRDS emblem
  // Ensures both left and right wings are 100% visible and symmetrical on all viewports without clipping
  const sizeClasses = {
    sm: 'w-10 h-10 max-w-[40px]',
    md: 'w-40 sm:w-48 max-w-[200px] max-h-[190px]',
    lg: 'w-48 sm:w-56 max-w-[230px] max-h-[220px]',
    xl: 'w-60 sm:w-72 max-w-[270px] max-h-[260px]'
  }[size];

  return (
    <div id={id} className={`flex flex-col items-center justify-center select-none ${className}`}>
      {/* Container with Ambient Radiant Neon Cyan & Deep Blue Glow */}
      <div className="relative flex items-center justify-center">
        {/* Outer Radiant Atmospheric Glow Halo */}
        <div className="absolute inset-0 -m-4 rounded-full bg-cyan-500/20 blur-2xl pointer-events-none" />
        <div className="absolute inset-2 rounded-full bg-blue-600/25 blur-xl pointer-events-none" />

        {/* Official TRDS Logo Image */}
        <img
          src={officialLogoImg}
          alt="TRDS Official Logo - Trade Trust Transparency"
          className={`relative z-10 ${sizeClasses} aspect-square object-contain drop-shadow-[0_10px_28px_rgba(0,0,0,0.85)] filter transition-transform duration-300`}
          loading="eager"
          decoding="async"
        />
      </div>
    </div>
  );
};

