import React, { useState } from 'react';
import {
  X,
  Star,
  TrendingUp,
  TrendingDown,
  SlidersHorizontal,
  Info,
  ShieldCheck,
  BarChart3,
  Calendar,
  Compass,
  ChevronRight
} from 'lucide-react';
import { Asset, ChartTimeframe } from '../../types';
import { formatMarketPairSymbol } from '../../utils/formatters';

interface AssetDetailModalProps {
  asset: Asset | null;
  isOpen?: boolean;
  onClose: () => void;
  onOpenSimulator?: (assetId: string) => void;
  onTrade?: (assetId: string) => void;
  onOpenMarketIntelligence?: (asset: Asset) => void;
  isFavorite: boolean;
  onToggleFavorite: (assetId: string) => void;
}

const TIMEFRAMES: ChartTimeframe[] = ['1H', '4H', '1D', '1W', '1M'];

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({
  asset,
  isOpen = true,
  onClose,
  onOpenSimulator,
  onTrade,
  onOpenMarketIntelligence,
  isFavorite,
  onToggleFavorite
}) => {
  const [selectedTimeframe, setSelectedTimeframe] = useState<ChartTimeframe>('1D');

  if (!asset || !isOpen) return null;

  const handleOpenTrade = (assetId: string) => {
    if (onOpenSimulator) onOpenSimulator(assetId);
    else if (onTrade) onTrade(assetId);
  };

  const isPositive = asset.change24h >= 0;
  const chartData = asset.timeframeData?.[selectedTimeframe] || asset.sparkline;

  // Chart min and max calculations
  const minPrice = Math.min(...chartData);
  const maxPrice = Math.max(...chartData);
  const priceRange = maxPrice - minPrice || 1;

  // Render SVG interactive line chart
  const vbWidth = 300;
  const vbHeight = 130;
  const paddingX = 12;
  const paddingY = 16;

  const points = chartData.map((val, idx) => {
    const x = paddingX + (idx / (chartData.length - 1)) * (vbWidth - paddingX * 2);
    const y = vbHeight - paddingY - ((val - minPrice) / priceRange) * (vbHeight - paddingY * 2);
    return [Number(x.toFixed(1)), Number(y.toFixed(1))];
  });

  const polylineStr = points.map(p => `${p[0]},${p[1]}`).join(' ');
  const areaPath = `M ${points[0][0]},${vbHeight} L ${polylineStr} L ${points[points.length - 1][0]},${vbHeight} Z`;

  const strokeColor = isPositive ? '#10B981' : '#EF4444';

  return (
    <div
      id="asset-detail-modal"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="detail-asset-title"
    >
      <div className="w-full max-w-md max-h-[90vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl text-slate-200 relative">
        {/* Top Handle for mobile feel */}
        <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1 mb-2 sm:hidden" />

        {/* Modal Header: Symbol, Name, Category, Favorite, Close */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center font-black text-sm text-white shadow-inner">
              {asset.symbol.split('/')[0].slice(0, 3)}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 id="detail-asset-title" className="text-base font-bold text-white tracking-tight">
                  {asset.symbol}
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  DEMO MARKET
                </span>
              </div>
              <span className="text-xs text-slate-400">{asset.name}</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onToggleFavorite(asset.id)}
              className="p-2 rounded-xl bg-slate-800/70 hover:bg-slate-800 text-slate-400 hover:text-amber-400 transition"
              aria-label={isFavorite ? 'Hapus dari favorit' : 'Tambah ke favorit'}
            >
              <Star className={`w-4 h-4 ${isFavorite ? 'text-amber-400 fill-amber-400' : ''}`} />
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/70 hover:bg-slate-800 text-slate-400 hover:text-white transition"
              aria-label="Tutup Detail"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Price & 24h Change Banner */}
        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">
              Harga Simulasi Saat Ini
            </span>
            <span className="text-2xl font-black text-white font-mono tracking-tight">
              ${asset.price.toLocaleString('en-US', {
                minimumFractionDigits: asset.price < 1 ? 4 : 2,
                maximumFractionDigits: asset.price < 1 ? 4 : 2
              })}
            </span>
          </div>

          <div
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 ${
              isPositive ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/15 text-red-400 border border-red-500/30'
            }`}
          >
            {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span>
              {isPositive ? '+' : ''}{asset.change24h}%
            </span>
          </div>
        </div>

        {/* Interactive Chart Section with Timeframe Filter */}
        <div className="space-y-2 p-3.5 rounded-2xl bg-slate-950/40 border border-slate-800/80">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <BarChart3 className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-semibold text-slate-300">Grafik Pergerakan</span>
            </div>

            {/* Timeframe selector */}
            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
              {TIMEFRAMES.map(tf => {
                const isSelected = selectedTimeframe === tf;
                return (
                  <button
                    key={tf}
                    type="button"
                    onClick={() => setSelectedTimeframe(tf)}
                    className={`px-2 py-0.5 rounded-lg text-xs font-bold transition ${
                      isSelected
                        ? 'bg-emerald-500 text-slate-950 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tf}
                  </button>
                );
              })}
            </div>
          </div>

          {/* SVG Line Chart Canvas */}
          <div className="relative w-full h-[140px] pt-1 flex items-center justify-center">
            <svg
              viewBox={`0 0 ${vbWidth} ${vbHeight}`}
              preserveAspectRatio="none"
              className="w-full h-full overflow-visible"
              aria-label={`Grafik harga ${asset.symbol} rentang ${selectedTimeframe}`}
            >
              <defs>
                <linearGradient id="detailGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={strokeColor} stopOpacity={0.3} />
                  <stop offset="100%" stopColor={strokeColor} stopOpacity={0.0} />
                </linearGradient>
              </defs>

              {/* Baseline reference grid */}
              <line
                x1="0"
                y1={vbHeight / 2}
                x2={vbWidth}
                y2={vbHeight / 2}
                stroke="#334155"
                strokeDasharray="4 4"
                strokeWidth="0.8"
                opacity="0.6"
              />

              {/* Area Fill */}
              <path d={areaPath} fill="url(#detailGrad)" />

              {/* Line */}
              <polyline
                fill="none"
                stroke={strokeColor}
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={polylineStr}
              />

              {/* End pointer dot */}
              {points.length > 0 && (
                <circle
                  cx={points[points.length - 1][0]}
                  cy={points[points.length - 1][1]}
                  r="4"
                  fill={strokeColor}
                  stroke="#020617"
                  strokeWidth="2"
                />
              )}
            </svg>
          </div>

          <div className="flex justify-between text-[10px] text-slate-500 font-mono pt-1">
            <span>Low: ${minPrice.toLocaleString()}</span>
            <span>High: ${maxPrice.toLocaleString()}</span>
          </div>
        </div>

        {/* Detailed Stats Grid: High, Low, Volume, Unit */}
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 block mb-0.5">24h High</span>
            <span className="font-bold text-slate-200 font-mono">
              ${asset.high24h.toLocaleString('en-US', {
                minimumFractionDigits: asset.high24h < 1 ? 4 : 2,
                maximumFractionDigits: asset.high24h < 1 ? 4 : 2
              })}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 block mb-0.5">24h Low</span>
            <span className="font-bold text-slate-200 font-mono">
              ${asset.low24h.toLocaleString('en-US', {
                minimumFractionDigits: asset.low24h < 1 ? 4 : 2,
                maximumFractionDigits: asset.low24h < 1 ? 4 : 2
              })}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-right">
            <span className="text-[10px] text-slate-400 block mb-0.5">Volume 24h</span>
            <span className="font-bold text-slate-200 font-mono">{asset.volume}</span>
          </div>
        </div>

        {/* Asset Description */}
        <div className="p-3 rounded-2xl bg-slate-950/40 border border-slate-800/80 text-xs text-slate-400 space-y-1">
          <span className="font-bold text-slate-300 block text-[11px]">Tentang {asset.name}:</span>
          <p className="leading-relaxed text-[11px]">{asset.description}</p>
        </div>

        {/* TRDS Market Pulse Button */}
        {onOpenMarketIntelligence && (
          <button
            id="btn-open-market-pulse-from-detail"
            type="button"
            onClick={() => onOpenMarketIntelligence(asset)}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-slate-900 to-indigo-950/60 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 font-bold text-xs flex items-center justify-between shadow-md transition group active:scale-98"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center shrink-0 border border-cyan-500/30 group-hover:scale-105 transition-transform">
                <Compass className="w-4 h-4" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white text-xs">TRDS Market Pulse</span>
                  <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300">
                    Analisis
                  </span>
                </div>
                <span className="text-[10px] text-slate-300 block font-medium">
                  Apa yang sedang terjadi di pasar {formatMarketPairSymbol(asset.symbol)}?
                </span>
              </div>
            </div>
            <div className="p-1 rounded-lg bg-cyan-500/10 text-cyan-400 group-hover:bg-cyan-500/20 group-hover:translate-x-0.5 transition">
              <ChevronRight className="w-4 h-4" />
            </div>
          </button>
        )}

        {/* Prominent Action Button: "Open Simulator" */}
        <div className="pt-1">
          <button
            id="btn-open-simulator-from-detail"
            type="button"
            onClick={() => {
              handleOpenTrade(asset.id);
            }}
            className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-98 transition duration-150"
            aria-label={`Open Simulator untuk ${asset.symbol}`}
          >
            <SlidersHorizontal className="w-4 h-4 text-slate-950" />
            <span>Open Simulator ({asset.symbol})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
