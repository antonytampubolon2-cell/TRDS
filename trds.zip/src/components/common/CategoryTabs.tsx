import React from 'react';
import { MarketFilter, MarketCategory } from '../../types';

interface FilterOption {
  id: MarketFilter;
  label: string;
}

interface CategoryOption {
  id: MarketCategory;
  label: string;
}

const FILTER_TABS: FilterOption[] = [
  { id: 'all', label: 'All' },
  { id: 'favorites', label: 'Favorites' },
  { id: 'trending', label: 'Trending' },
  { id: 'gainers', label: 'Gainers' },
  { id: 'losers', label: 'Losers' },
  { id: 'volume', label: 'Volume' }
];

const CATEGORY_PILLS: CategoryOption[] = [
  { id: 'all', label: 'Semua' },
  { id: 'crypto', label: 'Crypto' },
  { id: 'stocks', label: 'Saham' },
  { id: 'forex', label: 'Forex' },
  { id: 'commodities', label: 'Komoditas' }
];

interface CategoryTabsProps {
  activeFilter: MarketFilter;
  onFilterChange: (filter: MarketFilter) => void;
  activeCategory?: MarketCategory;
  onCategoryChange?: (category: MarketCategory) => void;
  showCategoryPills?: boolean;
  className?: string;
}

export const CategoryTabs: React.FC<CategoryTabsProps> = ({
  activeFilter,
  onFilterChange,
  activeCategory = 'all',
  onCategoryChange,
  showCategoryPills = true,
  className = ''
}) => {
  return (
    <div className={`space-y-2.5 ${className}`}>
      {/* Primary Horizontal Filter Tabs */}
      <div
        className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none select-none"
        role="tablist"
        aria-label="Market Filters"
      >
        {FILTER_TABS.map(tab => {
          const isActive = activeFilter === tab.id;
          return (
            <button
              key={tab.id}
              id={`filter-tab-${tab.id}`}
              role="tab"
              aria-selected={isActive}
              onClick={() => onFilterChange(tab.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 active:scale-95 ${
                isActive
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20 ring-1 ring-emerald-400'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 hover:bg-slate-850 border border-slate-800'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Secondary Asset Class Category Pills (if enabled) */}
      {showCategoryPills && onCategoryChange && (
        <div className="flex items-center gap-1 text-xs text-slate-400 overflow-x-auto pb-0.5 scrollbar-none">
          <span className="text-[10px] text-slate-500 uppercase font-semibold tracking-wider mr-1 shrink-0">
            Kelas:
          </span>
          {CATEGORY_PILLS.map(cat => {
            const isCatActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onCategoryChange(cat.id)}
                className={`px-2 py-0.5 rounded-lg text-[11px] font-medium transition shrink-0 ${
                  isCatActive
                    ? 'bg-slate-800 text-emerald-400 font-bold border border-emerald-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
