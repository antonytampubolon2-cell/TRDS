import React from 'react';
import { TrendingUp, TrendingDown, Star, SlidersHorizontal } from 'lucide-react';
import { Asset } from '../../types';
import { Sparkline } from './Sparkline';
import { formatMarketPairSymbol } from '../../utils/formatters';

interface MarketRowProps {
  asset: Asset;
  isFavorite: boolean;
  onToggleFavorite: (assetId: string) => void;
  onClick: (asset: Asset) => void;
  onTradeClick?: (assetId: string) => void;
  className?: string;
}

export const MarketRow: React.FC<MarketRowProps> = ({
  asset,
  isFavorite,
  onToggleFavorite,
  onClick,
  onTradeClick,
  className = ''
}) => {
  const isPositive = asset.change24h >= 0;

  return (
    <div
      id={`market-row-${asset.id}`}
      onClick={() => onClick(asset)}
      className={`p-3.5 rounded-2xl bg-slate-900/70 hover:bg-slate-850 border border-slate-800/80 hover:border-slate-700 transition duration-200 cursor-pointer shadow-sm space-y-2.5 active:scale-[0.99] ${className}`}
      role="button"
      tabIndex={0}
      aria-label={`Buka detail pasar ${asset.symbol}`}
    >
      {/* Top Header: Icon, Symbol, Name, Category Pill, Star Favorite, Simulator Button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5 min-w-0">
          {/* Asset Icon Avatar */}
          <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700/80 flex items-center justify-center font-extrabold text-xs text-white shrink-0 shadow-inner">
            {formatMarketPairSymbol(asset.symbol).split('/')[0].slice(0, 3)}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-white tracking-tight truncate">
                {formatMarketPairSymbol(asset.symbol)}
              </span>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700/50">
                {asset.category}
              </span>
            </div>
            <span className="text-[11px] text-slate-400 block truncate">
              {asset.name}
            </span>
          </div>
        </div>

        {/* Favorite & Quick Action buttons */}
        <div className="flex items-center gap-1.5 shrink-0" onClick={e => e.stopPropagation()}>
          <button
            type="button"
            onClick={() => onToggleFavorite(asset.id)}
            className="p-2 rounded-xl text-slate-500 hover:text-amber-400 hover:bg-slate-800 transition"
            aria-label={isFavorite ? 'Hapus dari favorit' : 'Tambah ke favorit'}
          >
            <Star className={`w-4 h-4 ${isFavorite ? 'text-amber-400 fill-amber-400' : ''}`} />
          </button>

          {onTradeClick && (
            <button
              type="button"
              onClick={() => onTradeClick(asset.id)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 text-xs font-semibold transition active:scale-95"
              aria-label={`Simulasi ${asset.symbol}`}
            >
              <SlidersHorizontal className="w-3 h-3" />
              <span>Simulasi</span>
            </button>
          )}
        </div>
      </div>

      {/* Middle Row: Price, 24h Change, Sparkline */}
      <div className="flex items-end justify-between pt-1 border-t border-slate-800/60">
        <div>
          <span className="text-[10px] text-slate-500 block uppercase font-medium">
            Harga Demo
          </span>
          <span className="text-base font-bold text-white font-mono tracking-tight">
            ${asset.price.toLocaleString('en-US', {
              minimumFractionDigits: asset.price < 1 ? 4 : 2,
              maximumFractionDigits: asset.price < 1 ? 4 : 2
            })}
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="w-16 h-6 flex items-center">
            <Sparkline data={asset.sparkline} isPositive={isPositive} width={64} height={24} showGradient />
          </div>

          <div
            className={`px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-0.5 ${
              isPositive ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'
            }`}
          >
            {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            <span>
              {isPositive ? '+' : ''}{asset.change24h}%
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Stats Grid: 24h High, 24h Low, Volume */}
      <div className="grid grid-cols-3 gap-1 text-[10px] bg-slate-950/50 p-2 rounded-xl border border-slate-800/40">
        <div>
          <span className="text-slate-500 block">24h High</span>
          <span className="font-semibold text-slate-300 font-mono">
            ${asset.high24h.toLocaleString('en-US', {
              minimumFractionDigits: asset.high24h < 1 ? 4 : 2,
              maximumFractionDigits: asset.high24h < 1 ? 4 : 2
            })}
          </span>
        </div>
        <div>
          <span className="text-slate-500 block">24h Low</span>
          <span className="font-semibold text-slate-300 font-mono">
            ${asset.low24h.toLocaleString('en-US', {
              minimumFractionDigits: asset.low24h < 1 ? 4 : 2,
              maximumFractionDigits: asset.low24h < 1 ? 4 : 2
            })}
          </span>
        </div>
        <div className="text-right">
          <span className="text-slate-500 block">Volume 24h</span>
          <span className="font-semibold text-slate-300 font-mono">{asset.volume}</span>
        </div>
      </div>
    </div>
  );
};
