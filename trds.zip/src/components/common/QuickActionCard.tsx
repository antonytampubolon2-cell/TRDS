import React from 'react';

interface QuickActionCardProps {
  id?: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  iconBgColor: string;
  badge?: string;
  onClick: () => void;
  className?: string;
}

export const QuickActionCard: React.FC<QuickActionCardProps> = ({
  id,
  title,
  subtitle,
  icon,
  iconBgColor,
  badge,
  onClick,
  className = ''
}) => {
  return (
    <button
      id={id}
      type="button"
      onClick={onClick}
      className={`flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 transition duration-200 group text-center relative overflow-hidden active:scale-95 ${className}`}
    >
      {badge && (
        <span className="absolute top-1.5 right-1.5 text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
          {badge}
        </span>
      )}

      <div
        className={`w-10 h-10 rounded-xl flex items-center justify-center mb-1.5 group-hover:scale-110 transition duration-200 shadow-md ${iconBgColor}`}
      >
        {icon}
      </div>

      <span className="text-xs font-bold text-white block group-hover:text-emerald-300 transition">
        {title}
      </span>
      <span className="text-[10px] text-slate-400 block truncate max-w-full">
        {subtitle}
      </span>
    </button>
  );
};
