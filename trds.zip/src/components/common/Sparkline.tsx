import React from 'react';

interface SparklineProps {
  data: number[];
  isPositive: boolean;
  width?: number | string;
  height?: number;
  showGradient?: boolean;
  strokeWidth?: number;
  className?: string;
}

export const Sparkline: React.FC<SparklineProps> = ({
  data,
  isPositive,
  width = 72,
  height = 28,
  showGradient = false,
  strokeWidth = 2,
  className = ''
}) => {
  if (!data || data.length < 2) return null;

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;

  // Viewbox coordinates
  const vbWidth = 100;
  const vbHeight = 40;
  const padding = 3;

  const pointsArray = data.map((val, idx) => {
    const x = padding + (idx / (data.length - 1)) * (vbWidth - padding * 2);
    const y = vbHeight - padding - ((val - min) / range) * (vbHeight - padding * 2);
    return [Number(x.toFixed(1)), Number(y.toFixed(1))];
  });

  const polylinePoints = pointsArray.map(p => `${p[0]},${p[1]}`).join(' ');

  // For gradient fill path
  const areaPath = `M ${pointsArray[0][0]},${vbHeight} L ${polylinePoints} L ${pointsArray[pointsArray.length - 1][0]},${vbHeight} Z`;

  const strokeColor = isPositive ? '#10B981' : '#EF4444';
  const gradientId = `spark-grad-${Math.random().toString(36).substring(2, 9)}`;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${vbWidth} ${vbHeight}`}
      preserveAspectRatio="none"
      className={`overflow-visible shrink-0 ${className}`}
      aria-label="Trend sparkline chart"
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={strokeColor} stopOpacity={0.35} />
          <stop offset="100%" stopColor={strokeColor} stopOpacity={0.0} />
        </linearGradient>
      </defs>

      {showGradient && (
        <path d={areaPath} fill={`url(#${gradientId})`} />
      )}

      <polyline
        fill="none"
        stroke={strokeColor}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        points={polylinePoints}
      />
    </svg>
  );
};
