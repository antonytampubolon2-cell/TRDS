import React, { useEffect } from 'react';
import { Award, Sparkles, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AchievementToast: React.FC = () => {
  const { latestUnlockedAchievement, dismissAchievementToast } = useApp();

  useEffect(() => {
    if (latestUnlockedAchievement) {
      const timer = setTimeout(() => {
        dismissAchievementToast();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [latestUnlockedAchievement, dismissAchievementToast]);

  if (!latestUnlockedAchievement) return null;

  return (
    <div
      id="achievement-toast"
      className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-sm animate-in fade-in slide-in-from-top-4 duration-300 pointer-events-auto"
    >
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 via-slate-900 to-slate-900 border border-amber-500/40 shadow-2xl backdrop-blur-md flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">Achievement Terbuka!</span>
              <span className="flex items-center text-[10px] font-bold text-emerald-400">
                <Sparkles className="w-2.5 h-2.5 mr-0.5" />+{latestUnlockedAchievement.xpReward} XP
              </span>
            </div>
            <h4 className="text-xs font-bold text-white mt-0.5">{latestUnlockedAchievement.title}</h4>
            <p className="text-[11px] text-slate-400 line-clamp-1">{latestUnlockedAchievement.description}</p>
          </div>
        </div>

        <button
          onClick={dismissAchievementToast}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          aria-label="Tutup notifikasi achievement"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
