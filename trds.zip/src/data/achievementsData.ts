import { Achievement, DailyChallenge } from '../types';

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first-lesson',
    title: 'Langkah Awal Belajar',
    description: 'Selesaikan modul pembelajaran edukasi pertamamu.',
    iconName: 'BookOpen',
    xpReward: 50,
    isUnlocked: false,
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'first-quiz',
    title: 'Ujian Perdana',
    description: 'Selesaikan kuis evaluasi materi pertamamu.',
    iconName: 'HelpCircle',
    xpReward: 50,
    isUnlocked: false,
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'simulator-beginner',
    title: 'Simulator Beginner',
    description: 'Tempatkan transaksi simulasi virtual pertamamu di Simulator.',
    iconName: 'SlidersHorizontal',
    xpReward: 60,
    isUnlocked: false,
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'quick-learner',
    title: 'Quick Learner',
    description: 'Selesaikan 5 modul pembelajaran edukatif di Akademi TRDS.',
    iconName: 'Zap',
    xpReward: 100,
    isUnlocked: false,
    progress: 0,
    maxProgress: 5
  },
  {
    id: 'quiz-master',
    title: 'Quiz Master',
    description: 'Lulus 5 kuis dengan nilai memuaskan.',
    iconName: 'Award',
    xpReward: 150,
    isUnlocked: false,
    progress: 0,
    maxProgress: 5
  },
  {
    id: 'knowledge-builder',
    title: 'Knowledge Builder',
    description: 'Selesaikan 10 modul pembelajaran edukatif.',
    iconName: 'GraduationCap',
    xpReward: 200,
    isUnlocked: false,
    progress: 0,
    maxProgress: 10
  },
  {
    id: 'market-explorer',
    title: 'Market Explorer',
    description: 'Buka dan eksplorasi rincian 5 instrumen aset berbeda di Markets.',
    iconName: 'Compass',
    xpReward: 80,
    isUnlocked: false,
    progress: 0,
    maxProgress: 5
  },
  {
    id: 'dedicated-learner',
    title: 'Dedicated Learner',
    description: 'Selesaikan 3 misi tantangan harian (Daily Challenge).',
    iconName: 'Flame',
    xpReward: 120,
    isUnlocked: false,
    progress: 0,
    maxProgress: 3
  },
  {
    id: 'risk-guardian',
    title: 'Risk Guardian',
    description: 'Kuasai seluruh modul pembelajaran di kategori Manajemen Risiko.',
    iconName: 'ShieldCheck',
    xpReward: 150,
    isUnlocked: false,
    progress: 0,
    maxProgress: 3
  },
  {
    id: 'pro-scholar',
    title: 'Pro Scholar',
    description: 'Akses kurikulum eksklusif TRDS Premium dan selesaikan materi tingkat lanjut.',
    iconName: 'Crown',
    xpReward: 250,
    isUnlocked: false,
    progress: 0,
    maxProgress: 1,
    isPremium: true
  },
  {
    id: 'risk-master-pro',
    title: 'Risk Master Pro',
    description: 'Pelajari metrik institusional Sharpe Ratio & Drawdown pada analitik simulator.',
    iconName: 'Zap',
    xpReward: 300,
    isUnlocked: false,
    progress: 0,
    maxProgress: 1,
    isPremium: true
  }
];

export const INITIAL_DAILY_CHALLENGES: DailyChallenge[] = [
  {
    id: 'dc-lesson-1',
    title: 'Selesaikan 1 Modul Pembelajaran',
    description: 'Baca dan tandai selesai satu materi baru di tab Learn.',
    xpReward: 50,
    targetCount: 1,
    currentCount: 0,
    isCompleted: false,
    type: 'lesson'
  },
  {
    id: 'dc-quiz-1',
    title: 'Uji Pengetahuan Lewat Kuis',
    description: 'Ikuti dan selesaikan satu kuis evaluasi materi.',
    xpReward: 50,
    targetCount: 1,
    currentCount: 0,
    isCompleted: false,
    type: 'quiz'
  },
  {
    id: 'dc-explore-assets',
    title: 'Eksplorasi Pasar',
    description: 'Buka dan pelajari 3 grafik aset berbeda di tab Markets.',
    xpReward: 40,
    targetCount: 3,
    currentCount: 0,
    isCompleted: false,
    type: 'view_market'
  },
  {
    id: 'dc-sim-trade',
    title: 'Praktik Simulasi Virtual',
    description: 'Eksekusi satu order beli atau jual di tab Simulator.',
    xpReward: 50,
    targetCount: 1,
    currentCount: 0,
    isCompleted: false,
    type: 'trade'
  }
];
