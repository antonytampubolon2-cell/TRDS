import { Asset, Lesson, Achievement, DailyChallenge, Order, Trade, UserProfile, ChatMessage } from '../types';
import { ALL_LESSONS } from './learningData';
import { INITIAL_ACHIEVEMENTS, INITIAL_DAILY_CHALLENGES } from './achievementsData';

export const INITIAL_USER_PROFILE: UserProfile = {
  name: 'Trader Alex',
  handle: '@alex_trds',
  level: 1,
  levelTitle: 'Novice Trader',
  currentXp: 0,
  nextLevelXp: 100,
  totalXp: 0,
  streakDays: 3,
  virtualBalance: 10000.00,
  initialBalance: 10000.00,
  tradesCount: 0,
  profitableTradesCount: 0,
  lessonsCompletedCount: 0,
  quizzesPassedCount: 0,
  notificationsEnabled: true,
  soundEnabled: true,
  language: 'id',
};

export const MOCK_ASSETS: Asset[] = [
  {
    id: 'btc',
    symbol: 'BTC/USD',
    name: 'Bitcoin',
    category: 'crypto',
    price: 64280.50,
    change24h: 3.42,
    high24h: 65120.00,
    low24h: 62890.10,
    volume: '$28.4B',
    sparkline: [62890, 63100, 63450, 63200, 63900, 64150, 63800, 64500, 64280.5],
    timeframeData: {
      '1H': [64100, 64150, 64080, 64220, 64180, 64280.5],
      '4H': [63800, 63950, 64100, 63900, 64150, 64280.5],
      '1D': [62890, 63200, 63600, 64100, 63900, 64500, 64280.5],
      '1W': [59800, 60900, 61500, 62400, 63200, 63800, 64280.5],
      '1M': [56500, 58200, 61000, 59400, 62100, 63500, 64280.5]
    },
    unit: 'BTC',
    description: 'Aset kripto terdesentralisasi pertama di dunia dengan pasokan terbatas 21 juta koin.'
  },
  {
    id: 'eth',
    symbol: 'ETH/USD',
    name: 'Ethereum',
    category: 'crypto',
    price: 3450.25,
    change24h: -1.18,
    high24h: 3540.00,
    low24h: 3390.50,
    volume: '$14.2B',
    sparkline: [3520, 3500, 3480, 3420, 3410, 3430, 3470, 3440, 3450.25],
    timeframeData: {
      '1H': [3445, 3455, 3448, 3452, 3449, 3450.25],
      '4H': [3480, 3465, 3440, 3435, 3458, 3450.25],
      '1D': [3520, 3490, 3460, 3410, 3430, 3470, 3450.25],
      '1W': [3300, 3350, 3420, 3490, 3510, 3460, 3450.25],
      '1M': [3100, 3250, 3380, 3450, 3390, 3500, 3450.25]
    },
    unit: 'ETH',
    description: 'Platform smart contract terkemuka yang mendukung ekosistem DeFi dan dApps global.'
  },
  {
    id: 'sol',
    symbol: 'SOL/USD',
    name: 'Solana',
    category: 'crypto',
    price: 152.80,
    change24h: 5.84,
    high24h: 156.20,
    low24h: 143.50,
    volume: '$3.8B',
    sparkline: [144, 146, 148, 147, 151, 149, 154, 155, 152.8],
    timeframeData: {
      '1H': [151.2, 151.9, 152.4, 153.1, 152.5, 152.8],
      '4H': [148.5, 149.8, 151.0, 153.5, 154.2, 152.8],
      '1D': [144.0, 146.5, 148.2, 151.0, 154.5, 152.8],
      '1W': [132.0, 138.5, 142.0, 146.5, 149.0, 152.8],
      '1M': [118.0, 126.0, 135.0, 142.0, 145.0, 152.8]
    },
    unit: 'SOL',
    description: 'Blockchain berkecepatan tinggi dengan biaya transaksi rendah untuk Web3 dan DeFi.'
  },
  {
    id: 'bnb',
    symbol: 'BNB/USD',
    name: 'BNB',
    category: 'crypto',
    price: 574.60,
    change24h: 1.75,
    high24h: 582.00,
    low24h: 561.30,
    volume: '$1.4B',
    sparkline: [564, 566, 569, 567, 572, 575, 578, 574.6],
    timeframeData: {
      '1H': [573.5, 574.2, 575.0, 574.1, 574.6],
      '4H': [568.0, 571.2, 573.5, 576.0, 574.6],
      '1D': [562.0, 565.4, 570.0, 575.5, 578.0, 574.6],
      '1W': [540.0, 552.0, 560.0, 568.0, 572.0, 574.6],
      '1M': [490.0, 515.0, 540.0, 555.0, 565.0, 574.6]
    },
    unit: 'BNB',
    description: 'Token utilitas ekosistem BNB Chain yang digunakan untuk gas fee dan ekosistem terintegrasi.'
  },
  {
    id: 'xrp',
    symbol: 'XRP/USD',
    name: 'XRP',
    category: 'crypto',
    price: 0.584,
    change24h: 4.12,
    high24h: 0.602,
    low24h: 0.558,
    volume: '$2.1B',
    sparkline: [0.56, 0.565, 0.57, 0.568, 0.575, 0.589, 0.584],
    timeframeData: {
      '1H': [0.581, 0.583, 0.586, 0.582, 0.584],
      '4H': [0.572, 0.576, 0.582, 0.588, 0.584],
      '1D': [0.560, 0.568, 0.574, 0.582, 0.590, 0.584],
      '1W': [0.520, 0.535, 0.550, 0.565, 0.580, 0.584],
      '1M': [0.480, 0.505, 0.525, 0.550, 0.570, 0.584]
    },
    unit: 'XRP',
    description: 'Aset digital pembayaran lintas batas cepat yang dirancang untuk likuiditas institusional global.'
  },
  {
    id: 'ada',
    symbol: 'ADA/USD',
    name: 'Cardano',
    category: 'crypto',
    price: 0.385,
    change24h: -0.74,
    high24h: 0.395,
    low24h: 0.378,
    volume: '$480M',
    sparkline: [0.391, 0.389, 0.387, 0.382, 0.384, 0.388, 0.385],
    timeframeData: {
      '1H': [0.384, 0.386, 0.385, 0.387, 0.385],
      '4H': [0.388, 0.385, 0.382, 0.386, 0.385],
      '1D': [0.392, 0.388, 0.382, 0.385, 0.387, 0.385],
      '1W': [0.360, 0.372, 0.380, 0.385, 0.390, 0.385],
      '1M': [0.340, 0.355, 0.370, 0.380, 0.390, 0.385]
    },
    unit: 'ADA',
    description: 'Platform blockchain berbasis proof-of-stake yang dikembangkan melalui riset akademis teruji.'
  },
  {
    id: 'doge',
    symbol: 'DOGE/USD',
    name: 'Dogecoin',
    category: 'crypto',
    price: 0.114,
    change24h: 7.25,
    high24h: 0.121,
    low24h: 0.105,
    volume: '$920M',
    sparkline: [0.106, 0.108, 0.107, 0.112, 0.115, 0.118, 0.114],
    timeframeData: {
      '1H': [0.112, 0.115, 0.113, 0.116, 0.114],
      '4H': [0.108, 0.111, 0.114, 0.117, 0.114],
      '1D': [0.105, 0.108, 0.112, 0.116, 0.119, 0.114],
      '1W': [0.095, 0.099, 0.103, 0.108, 0.112, 0.114],
      '1M': [0.088, 0.094, 0.102, 0.108, 0.115, 0.114]
    },
    unit: 'DOGE',
    description: 'Aset kripto komunitas terpopuler dengan likuiditas tinggi dan biaya transfer minimal.'
  },
  {
    id: 'avax',
    symbol: 'AVAX/USD',
    name: 'Avalanche',
    category: 'crypto',
    price: 28.45,
    change24h: -2.35,
    high24h: 29.80,
    low24h: 27.60,
    volume: '$410M',
    sparkline: [29.2, 29.0, 28.7, 28.1, 28.3, 28.6, 28.45],
    timeframeData: {
      '1H': [28.3, 28.5, 28.4, 28.6, 28.45],
      '4H': [28.9, 28.6, 28.2, 28.5, 28.45],
      '1D': [29.4, 29.1, 28.0, 28.3, 28.7, 28.45],
      '1W': [25.5, 26.8, 27.5, 28.2, 29.0, 28.45],
      '1M': [23.0, 25.0, 27.0, 28.5, 29.2, 28.45]
    },
    unit: 'AVAX',
    description: 'Platform smart contract berkecepatan sub-detik untuk subnet kustom dan aplikasi institusional.'
  },
  {
    id: 'link',
    symbol: 'LINK/USD',
    name: 'Chainlink',
    category: 'crypto',
    price: 12.65,
    change24h: 3.18,
    high24h: 13.10,
    low24h: 12.15,
    volume: '$290M',
    sparkline: [12.2, 12.3, 12.1, 12.5, 12.8, 12.7, 12.65],
    timeframeData: {
      '1H': [12.55, 12.68, 12.62, 12.70, 12.65],
      '4H': [12.30, 12.45, 12.60, 12.75, 12.65],
      '1D': [12.15, 12.30, 12.50, 12.80, 12.70, 12.65],
      '1W': [11.20, 11.60, 12.00, 12.40, 12.70, 12.65],
      '1M': [10.50, 11.20, 11.90, 12.30, 12.80, 12.65]
    },
    unit: 'LINK',
    description: 'Jaringan oracle terdesentralisasi terkemuka yang menghubungkan smart contract dengan data dunia nyata.'
  },
  {
    id: 'dot',
    symbol: 'DOT/USD',
    name: 'Polkadot',
    category: 'crypto',
    price: 4.82,
    change24h: -1.02,
    high24h: 4.98,
    low24h: 4.75,
    volume: '$180M',
    sparkline: [4.90, 4.88, 4.85, 4.80, 4.84, 4.86, 4.82],
    timeframeData: {
      '1H': [4.80, 4.83, 4.81, 4.84, 4.82],
      '4H': [4.86, 4.83, 4.80, 4.84, 4.82],
      '1D': [4.92, 4.88, 4.79, 4.83, 4.85, 4.82],
      '1W': [4.40, 4.55, 4.68, 4.78, 4.88, 4.82],
      '1M': [4.10, 4.30, 4.50, 4.70, 4.85, 4.82]
    },
    unit: 'DOT',
    description: 'Protokol multichain yang memfasilitasi interoperabilitas dan transfer lintas rantai antar blockchain.'
  },
  {
    id: 'nvda',
    symbol: 'NVDA',
    name: 'NVIDIA Corp.',
    category: 'stocks',
    price: 124.60,
    change24h: 2.15,
    high24h: 126.50,
    low24h: 121.80,
    volume: '$41.2B',
    sparkline: [122, 122.5, 123.8, 123.1, 125.0, 124.2, 125.8, 124.6],
    timeframeData: {
      '1H': [124.1, 124.8, 124.3, 124.9, 124.6],
      '4H': [123.2, 123.9, 124.5, 125.2, 124.6],
      '1D': [122.0, 123.1, 124.2, 125.5, 124.6],
      '1W': [118.0, 120.5, 122.8, 124.0, 124.6],
      '1M': [110.0, 115.0, 120.0, 123.0, 124.6]
    },
    unit: 'Shares',
    description: 'Pemimpin chip komputasi kecerdasan buatan (AI) dan GPU gaming global.'
  },
  {
    id: 'aapl',
    symbol: 'AAPL',
    name: 'Apple Inc.',
    category: 'stocks',
    price: 226.40,
    change24h: 0.85,
    high24h: 228.10,
    low24h: 224.20,
    volume: '$22.1B',
    sparkline: [224.5, 225, 225.8, 226.2, 225.9, 227.0, 226.4],
    timeframeData: {
      '1H': [226.0, 226.5, 226.2, 226.8, 226.4],
      '4H': [225.2, 225.8, 226.4, 227.0, 226.4],
      '1D': [224.5, 225.2, 226.0, 227.2, 226.4],
      '1W': [220.0, 222.5, 224.8, 226.0, 226.4],
      '1M': [212.0, 218.0, 222.0, 225.0, 226.4]
    },
    unit: 'Shares',
    description: 'Raksasa teknologi produsen iPhone, Mac, iOS ecosystem dan perangkat keras premium.'
  },
  {
    id: 'tsla',
    symbol: 'TSLA',
    name: 'Tesla Inc.',
    category: 'stocks',
    price: 248.90,
    change24h: -3.40,
    high24h: 259.00,
    low24h: 246.50,
    volume: '$19.5B',
    sparkline: [258, 256, 254, 252, 250, 251, 247, 248.9],
    timeframeData: {
      '1H': [249.5, 248.2, 249.0, 248.5, 248.9],
      '4H': [253.0, 251.2, 249.5, 248.0, 248.9],
      '1D': [257.0, 254.0, 250.5, 247.2, 248.9],
      '1W': [240.0, 245.0, 252.0, 256.0, 248.9],
      '1M': [230.0, 238.0, 248.0, 255.0, 248.9]
    },
    unit: 'Shares',
    description: 'Pelopor kendaraan listrik, teknologi baterai, dan sistem autonomous driving.'
  },
  {
    id: 'eurusd',
    symbol: 'EUR/USD',
    name: 'Euro / US Dollar',
    category: 'forex',
    price: 1.0875,
    change24h: 0.12,
    high24h: 1.0910,
    low24h: 1.0845,
    volume: '$120B',
    sparkline: [1.085, 1.086, 1.0865, 1.087, 1.088, 1.0875],
    timeframeData: {
      '1H': [1.0872, 1.0876, 1.0874, 1.0878, 1.0875],
      '4H': [1.0865, 1.0870, 1.0875, 1.0880, 1.0875],
      '1D': [1.0855, 1.0865, 1.0872, 1.0885, 1.0875],
      '1W': [1.0820, 1.0845, 1.0860, 1.0880, 1.0875],
      '1M': [1.0780, 1.0820, 1.0850, 1.0890, 1.0875]
    },
    unit: 'Lot',
    description: 'Pasangan mata uang paling likuid di pasar valuta asing (Forex) dunia.'
  },
  {
    id: 'gold',
    symbol: 'XAU/USD',
    name: 'Gold (Emas)',
    category: 'commodities',
    price: 2498.40,
    change24h: 1.04,
    high24h: 2512.00,
    low24h: 2482.50,
    volume: '$35B',
    sparkline: [2485, 2488, 2492, 2490, 2504, 2500, 2498.4],
    timeframeData: {
      '1H': [2496, 2499, 2497, 2501, 2498.4],
      '4H': [2490, 2494, 2498, 2503, 2498.4],
      '1D': [2484, 2489, 2495, 2505, 2498.4],
      '1W': [2450, 2470, 2485, 2500, 2498.4],
      '1M': [2380, 2420, 2460, 2490, 2498.4]
    },
    unit: 'Oz',
    description: 'Komoditas logam mulia safe haven utama sebagai lindung nilai inflasi dan gejolak pasar.'
  }
];

export const MOCK_LESSONS: Lesson[] = ALL_LESSONS;

export const MOCK_ACHIEVEMENTS: Achievement[] = INITIAL_ACHIEVEMENTS;

export const MOCK_DAILY_CHALLENGES: DailyChallenge[] = INITIAL_DAILY_CHALLENGES;

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-101',
    assetId: 'btc',
    symbol: 'BTC/USD',
    type: 'limit',
    side: 'buy',
    amount: 0.05,
    price: 61500.00,
    status: 'open',
    timestamp: Date.now() - 3600000 * 4
  },
  {
    id: 'ord-102',
    assetId: 'sol',
    symbol: 'SOL/USD',
    type: 'limit',
    side: 'sell',
    amount: 10,
    price: 165.00,
    status: 'open',
    timestamp: Date.now() - 3600000 * 2
  }
];

export const INITIAL_TRADES: Trade[] = [
  {
    id: 'trd-001',
    assetId: 'btc',
    symbol: 'BTC/USD',
    side: 'buy',
    amount: 0.1,
    price: 62400.00,
    totalValue: 6240.00,
    timestamp: Date.now() - 86400000 * 2,
    simulatedPnL: 188.05
  },
  {
    id: 'trd-002',
    assetId: 'nvda',
    symbol: 'NVDA',
    side: 'buy',
    amount: 15,
    price: 118.50,
    totalValue: 1777.50,
    timestamp: Date.now() - 86400000 * 1,
    simulatedPnL: 91.50
  },
  {
    id: 'trd-003',
    assetId: 'eth',
    symbol: 'ETH/USD',
    side: 'sell',
    amount: 0.5,
    price: 3490.00,
    totalValue: 1745.00,
    timestamp: Date.now() - 3600000 * 8,
    simulatedPnL: 45.00
  }
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    sender: 'assistant',
    text: 'Halo! Saya TRDS AI, tutor edukasi trading & pasar finansial pribadimu. 🚀\n\nKamu bisa bertanya tentang istilah trading, cara membaca grafik, manajemen risiko, atau cara kerja order di simulator. Perlu diingat: TRDS AI bersifat edukatif dan tidak memberikan saran investasi keuangan nyata.',
    timestamp: Date.now() - 60000,
    promptSuggestions: [
      'Apa perbedaan Market Order vs Limit Order?',
      'Bagaimana cara kerja Stop Loss?',
      'Jelaskan konsep Risk-to-Reward Ratio',
      'Apa itu Candlestick Bullish & Bearish?'
    ]
  }
];

export const AI_KNOWLEDGE_BASE: Record<string, string> = {
  'market order': `**Market Order** adalah pesanan untuk langsung membeli atau menjual aset pada harga terbaik yang tersedia detik ini di pasar.\n\n• **Kelebihan:** Eksekusi dijamin langsung selesai.\n• **Kekurangan:** Harga akhir bisa sedikit bergeser jika pasar sangat volatil (dikenal sebagai slippage).\n\n💡 *Tip TRDS:* Cocok saat kamu ingin masuk/keluar pasar dengan segera tanpa menunggu antrean.`,
  'limit order': `**Limit Order** adalah instruksi beli/jual hanya pada harga tertentu (atau lebih baik) yang kamu tentukan sendiri.\n\n• **Limit Buy:** Dipasang di bawah harga pasar saat ini.\n• **Limit Sell:** Dipasang di atas harga pasar saat ini.\n\n💡 *Tip TRDS:* Sangat baik untuk trader yang sabar menunggu harga diskon atau target profit spesifik.`,
  'stop loss': `**Stop Loss (SL)** adalah jaring pengaman otomatis untuk menutup posisi jika harga bergerak berlawanan dengan prediksi dan menyentuh batas kerugian toleransi kamu.\n\n• Mencegah akun mengalami kerugian besar (margin call).\n• Mengeliminasi emosi berharap "nanti juga balik modal".\n\n🛡️ *Aturan Emas:* Tentukan selalu Stop Loss sebelum kamu menekan tombol Buy/Sell.`,
  'candlestick': `**Candlestick** adalah grafik visual yang merepresentasikan 4 harga dalam periode waktu (OHLC: Open, High, Low, Close):\n\n🟢 **Candle Hijau (Bullish):** Harga penutupan (Close) > Pembukaan (Open).\n🔴 **Candle Merah (Bearish):** Harga penutupan (Close) < Pembukaan (Open).\n• **Sumbu (Wick):** Titik tertinggi dan terendah yang pernah disentuh selama rentang waktu tersebut.`,
  'risk': `**Risk-to-Reward Ratio (RRR)** adalah perbandingan antara potensi kerugian (risk) dengan potensi keuntungan (reward).\n\nContoh Rasio 1:2:\n• Kamu bersedia merugi maksimal $50 untuk potensi untung $100.\n• Dengan rasio ini, meskipun tingkat kemenangan (win rate) kamu hanya 40%, akunmu secara akumulatif tetap mencatatkan hasil positif!`,
  'default': `Pertanyaan bagus! Dalam trading dan analisis pasar finansial, kunci utama adalah pemahaman siklus pasar, pengendalian risiko, dan disiplin psikologis.\n\nIngin tahu lebih dalam tentang topik ini? Pilih salah satu saran di bawah atau ketik pertanyaan spesifik seperti "Apa itu Support & Resistance?" atau "Bagaimana cara membaca Volume?".`
};
