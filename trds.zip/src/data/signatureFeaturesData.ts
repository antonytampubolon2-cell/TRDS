export interface SignatureFeatureItem {
  id: string;
  order: number;
  row: 1 | 2;
  title: string;
  shortDesc: string;
  emoji: string;
  tagline: string;
  prinsipTRDS: string;
  caraKerja: string;
  terhubungDenganDeskripsi: string;
  concept: string;
  principles?: string[];
  ecosystemRole: string;
  accentColor: string;
  glowColor: string;
}

export const TRDS_SIGNATURE_FEATURES: SignatureFeatureItem[] = [
  // BARIS PERTAMA (4 KARTU)
  {
    id: 'zona-damai',
    order: 1,
    row: 1,
    title: 'ZONA DAMAI',
    shortDesc: 'Ruang tenang & sehat',
    emoji: '🤝',
    tagline: 'Ruang belajar yang tenang, sehat, dan saling menghargai.',
    prinsipTRDS:
      'TRDS meyakini bahwa proses belajar finansial terbaik terjadi dalam suasana yang jernih dan bebas tekanan. Tidak ada papan peringkat kompetitif yang memicu FOMO (Fear of Missing Out) atau perilaku impulsif.',
    caraKerja:
      'Sistem memberikan ruang simulasi mandiri di mana setiap tindakan dievaluasi berdasarkan pertimbangan logis dan disiplin pribadi, bukan karena membandingkan hasil dengan orang lain.',
    terhubungDenganDeskripsi:
      'Terhubung dengan modul pembelajaran mandiri, profil bebas tekanan sosial, dan lingkungan simulasi tanpa kompetisi agresif.',
    concept:
      'TRDS adalah ruang untuk belajar dan berlatih tanpa tekanan untuk bersaing secara tidak sehat.',
    principles: [
      'Tenang & Bebas FOMO',
      'Saling menghargai proses',
      'Belajar tanpa tekanan kompetisi',
      'Fokus pada perkembangan personal'
    ],
    ecosystemRole: 'Lingkungan belajar yang sehat',
    accentColor: 'text-sky-400 border-sky-500/30 bg-sky-500/10',
    glowColor: 'rgba(56, 189, 248, 0.25)'
  },
  {
    id: 'lindung-nilai',
    order: 2,
    row: 1,
    title: 'LINDUNG NILAI',
    shortDesc: 'Proteksi & kelola risiko',
    emoji: '🛡️',
    tagline: 'Pelajari risiko dan konsep perlindungan nilai melalui simulasi.',
    prinsipTRDS:
      'Dalam pasar keuangan, menjaga modal dan memahami eksposur risiko jauh lebih utama daripada mengejar proyeksi keuntungan semata. Edukasi risiko adalah fondasi keahlian finansial yang berkelanjutan.',
    caraKerja:
      'Melalui simulasi portofolio, pengguna mempelajari pengaruh ukuran posisi (position sizing), alokasi kas virtual, serta dampak volatilitas harga tanpa mempertaruhkan uang riil.',
    terhubungDenganDeskripsi:
      'Terhubung langsung dengan kalkulasi Portofolio, Saldo Kas Virtual, dan metrik risiko instrumen di Pasar Simulasi.',
    concept:
      'Memahami bahwa manajemen risiko dan perlindungan modal virtual adalah prioritas utama sebelum mengejar hasil.',
    principles: [
      'Pemahaman risiko & volatilitas',
      'Manajemen alokasi kas virtual',
      'Perlindungan nilai posisi',
      'Pentingnya analisis sebelum bertindak'
    ],
    ecosystemRole: 'Memahami dan mengelola risiko',
    accentColor: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10',
    glowColor: 'rgba(16, 185, 129, 0.25)'
  },
  {
    id: 'jejak-jujur',
    order: 3,
    row: 1,
    title: 'JEJAK JUJUR',
    shortDesc: 'Aktivitas transparan',
    emoji: '📖',
    tagline: 'Lihat perjalanan aktivitasmu secara transparan.',
    prinsipTRDS:
      'Kejujuran data adalah integritas tertinggi dalam edukasi. Setiap keputusan—baik transaksi simulasi yang untung maupun rugi—tercatat apa adanya tanpa rekayasa atau penyembunyian performa.',
    caraKerja:
      'Setiap order virtual dicatat lengkap dengan stempel waktu, harga eksekusi, jenis posisi (Buy/Sell), dan kalkulasi PnL simulasi secara objektif dan real-time.',
    terhubungDenganDeskripsi:
      'Terhubung dengan Riwayat Transaksi (Trade History), Catatan Pesanan, dan Kalkulasi PnL Kumulatif Portofolio.',
    concept:
      'Setiap order, perubahan saldo virtual, modul belajar, dan perolehan XP tercatat secara terbuka tanpa data palsu.',
    principles: [
      'Catatan transaksi simulator riil',
      'Eksekusi Buy & Sell transparan',
      'Rekam jejak PnL objektif',
      'Evaluasi keputusan tanpa bias'
    ],
    ecosystemRole: 'Melihat perjalanan transaksi secara nyata',
    accentColor: 'text-amber-400 border-amber-500/30 bg-amber-500/10',
    glowColor: 'rgba(245, 158, 11, 0.25)'
  },
  {
    id: 'tujuan-bersama',
    order: 4,
    row: 1,
    title: 'TUJUAN BERSAMA',
    shortDesc: 'Arah & milestone belajar',
    emoji: '🎯',
    tagline: 'Tentukan arah belajar dan capai perkembanganmu bersama TRDS.',
    prinsipTRDS:
      'Pembelajaran yang terarah membutuhkan kurikulum bertahap. Pengguna didorong untuk menetapkan target belajar yang realistis melalui modul teori dan pengujian pemahaman.',
    caraKerja:
      'Menghubungkan target harian, modul edukasi pasar, dan kuis pemahaman konsep menjadi sebuah peta jalan belajar yang sistematis dan terukur.',
    terhubungDenganDeskripsi:
      'Terhubung dengan Modul Learn, Kuis Pemahaman Pasar, dan Pencapaian Target Belajar Harian.',
    concept:
      'Menetapkan tujuan pembelajaran yang terstruktur melalui modul edukasi, kuis pemahaman, dan target harian.',
    principles: [
      'Peta jalan modul bertahap',
      'Kuis validasi pemahaman',
      'Milestone belajar terukur',
      'Disiplin penyelesaian target'
    ],
    ecosystemRole: 'Menentukan arah dan target edukasi',
    accentColor: 'text-rose-400 border-rose-500/30 bg-rose-500/10',
    glowColor: 'rgba(244, 63, 94, 0.25)'
  },

  // BARIS KEDUA (3 KARTU - CENTERED)
  {
    id: 'tumbuh-bersama',
    order: 5,
    row: 2,
    title: 'TUMBUH BERSAMA',
    shortDesc: 'Perkembangan nyata',
    emoji: '🌱',
    tagline: 'Lihat bagaimana kemampuanmu berkembang dari waktu ke waktu.',
    prinsipTRDS:
      'Kompetensi trading dibangun melalui akumulasi jam terbang belajar dan evaluasi yang konsisten. Pertumbuhan bukan tentang keberuntungan kilat, melainkan kematangan proses berpikir.',
    caraKerja:
      'Setiap modul yang diselesaikan dan latihan simulator memberikan XP edukasi yang menaikkan level kemampuan pengguna melalui 4 tahapan: Belajar, Berlatih, Memahami, dan Berkembang.',
    terhubungDenganDeskripsi:
      'Terhubung dengan Tingkat Level Pengguna, Akumulasi Experience Points (XP), dan Badge Prestasi Belajar.',
    concept:
      'Evolusi keterampilan trading virtual melalui proses belajar berkesinambungan dan bertahap.',
    principles: [
      'Tahap 1: Belajar konsep dasar',
      'Tahap 2: Berlatih simulasi kas',
      'Tahap 3: Memahami pola dinamika',
      'Tahap 4: Berkembang dengan konsistensi'
    ],
    ecosystemRole: 'Melihat perkembangan kemampuan berkala',
    accentColor: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10',
    glowColor: 'rgba(16, 185, 129, 0.25)'
  },
  {
    id: 'jelas-tanpa-rahasia',
    order: 6,
    row: 2,
    title: 'JELAS TANPA RAHASIA',
    shortDesc: 'Informasi terbuka & lugas',
    emoji: '🔍',
    tagline: 'Informasi penting ditampilkan dengan jelas dan transparan.',
    prinsipTRDS:
      'Tidak ada biaya terselubung, tidak ada algoritma tertutup yang memanipulasi eksekusi, dan tidak ada janji-janji palsu. Pengguna berhak mengetahui seluruh aturan simulasi secara terbuka.',
    caraKerja:
      'Menampilkan parameter aplikasi secara terbuka: saldo awal virtual sebesar $10,000, biaya transaksi simulasi 0%, mekanisme order book virtual, dan transparansi status hak langganan.',
    terhubungDenganDeskripsi:
      'Terhubung dengan Transparansi Saldo Simulator, Ringkasan Akun, dan Status Keanggotaan Akun.',
    concept:
      'Keterbukaan menyeluruh atas seluruh parameter aplikasi: saldo virtual, aturan trading, status langganan, dan batasan fitur.',
    principles: [
      'Saldo virtual $10,000 terbuka',
      'Bebas biaya tersembunyi (0% fee)',
      'Aturan eksekusi order transparan',
      'Informasi status akun yang jujur'
    ],
    ecosystemRole: 'Memahami informasi dan aturan secara utuh',
    accentColor: 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10',
    glowColor: 'rgba(6, 182, 212, 0.25)'
  },
  {
    id: 'pengingat-baik',
    order: 7,
    row: 2,
    title: 'PENGINGAT BAIK',
    shortDesc: 'Mindset positif & bijak',
    emoji: '💚',
    tagline: 'Pengingat positif untuk membantu proses belajar.',
    prinsipTRDS:
      'Psikologi dan ketenangan emosional adalah kunci dalam menghadapi dinamika pasar. Pesan edukatif positif membantu pengguna tetap berkepala dingin dan berfokus pada substansi ilmu.',
    caraKerja:
      'Menyajikan refleksi berkala yang mengembalikan fokus pada tujuan awal: belajar dengan tenang, menerima kesalahan sebagai ruang tumbuh, dan menjaga keseimbangan hidup.',
    terhubungDenganDeskripsi:
      'Terhubung dengan Modul Mindfulness Finansial, Catatan Refleksi Harian, dan Evaluasi Diri Pengguna.',
    concept:
      'Menjaga ketenangan psikologis dan perspektif sehat saat menghadapi dinamika pasar virtual.',
    principles: [
      'Fokus pada proses belajar',
      'Tetap berkepala dingin',
      'Kesalahan adalah peluang perbaikan',
      'Simulasi untuk mengasah nalar'
    ],
    ecosystemRole: 'Menjaga pola belajar yang positif & bijak',
    accentColor: 'text-teal-400 border-teal-500/30 bg-teal-500/10',
    glowColor: 'rgba(20, 184, 166, 0.25)'
  }
];

export const EDUCATIONAL_REMINDERS = [
  '💚 Ingat, tujuanmu adalah belajar.',
  '💚 Jangan terburu-buru. Pahami terlebih dahulu.',
  '💚 Kesalahan dalam simulasi adalah kesempatan untuk memahami.',
  '💚 Hasil simulasi bukan jaminan hasil nyata.',
  '💚 Pasar selalu ada besok. Istirahat dan jaga pikiran tetap jernih.',
  '💚 Disiplin dan pengendalian risiko jauh lebih berharga daripada mengejar profit instan.',
  '💚 Amati pola tanpa emosi, evaluasi setiap keputusan secara objektif.'
];
