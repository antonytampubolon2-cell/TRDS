import { LearningCategory, Lesson } from '../types';

export const LEARNING_CATEGORIES: LearningCategory[] = [
  {
    id: 'basics',
    title: 'Dasar-Dasar Trading',
    subtitle: 'Konsep fundamental pasar, jenis aset, dan mekanisme order',
    iconName: 'BookOpen',
    color: 'emerald'
  },
  {
    id: 'market_price',
    title: 'Pasar & Mekanisme Harga',
    subtitle: 'Supply-demand, spread, likuiditas, dan order book',
    iconName: 'Activity',
    color: 'blue'
  },
  {
    id: 'charts',
    title: 'Grafik & Candlestick',
    subtitle: 'Anatomi OHLC, pola lilin, timeframe, support & resistance',
    iconName: 'BarChart2',
    color: 'amber'
  },
  {
    id: 'indicators',
    title: 'Indikator Teknikal',
    subtitle: 'Moving Average (MA), RSI momentum, dan analisis volume',
    iconName: 'TrendingUp',
    color: 'purple'
  },
  {
    id: 'risk',
    title: 'Manajemen Risiko',
    subtitle: 'Aturan 1%, Stop Loss, Take Profit, dan rasio Risk/Reward',
    iconName: 'ShieldCheck',
    color: 'rose'
  },
  {
    id: 'psychology',
    title: 'Psikologi Trading',
    subtitle: 'Mengatasi FOMO, menjaga disiplin, dan menghindari emosi',
    iconName: 'Brain',
    color: 'teal'
  },
  {
    id: 'practice',
    title: 'Praktik Simulasi Virtual',
    subtitle: 'Strategi eksekusi demo, evaluasi jurnal, dan review PnL',
    iconName: 'SlidersHorizontal',
    color: 'indigo'
  }
];

export const ALL_LESSONS: Lesson[] = [
  // =================================================================
  // KATEGORI A: DASAR-DASAR TRADING (BASICS)
  // =================================================================
  {
    id: 'lesson-what-is-market',
    categoryId: 'basics',
    title: 'Apa itu Pasar Finansial?',
    subtitle: 'Memahami bagaimana pembeli dan penjual bertransaksi di pasar modern.',
    track: 'beginner',
    durationMinutes: 5,
    readTime: '5 menit',
    xpReward: 20,
    intro: 'Pasar finansial adalah tempat bertemunya pihak yang ingin membeli dan pihak yang ingin menjual berbagai instrumen keuangan.',
    content: [
      'Secara sederhana, pasar finansial berfungsi seperti pasar tradisional, namun instrumen yang diperdagangkan berupa aset digital, saham perusahaan, mata uang, atau komoditas.',
      'Di pasar terbuka, harga tidak ditentukan oleh satu pihak, melainkan terbentuk secara alami melalui kesepakatan antara penawaran (penjual) dan permintaan (pembeli).',
      'Di era digital saat ini, transaksi berlangsung dalam hitungan milidetik melalui jaringan elektronik bursa (exchange) yang mencocokkan pesanan secara otomatis.'
    ],
    example: {
      title: 'Contoh Nyata Pasar Terbuka',
      scenario: 'Jika ribuan orang ingin membeli Bitcoin karena kabar adopsi positif, sementara sedikit orang yang mau menjual, apa yang terjadi pada harga?',
      analysis: 'Karena permintaan jauh melebihi ketersediaan penawaran, pembeli bersedia menawar dengan harga lebih tinggi. Akibatnya harga pasar terdorong naik.'
    },
    keyTakeaways: [
      'Pasar adalah wadah pertemuan penjual dan pembeli.',
      'Harga terbentuk dari kesepakatan penawaran dan permintaan.',
      'Dalam simulasi TRDS, pergerakan pasar disimulasikan secara real-time tanpa risiko finansial nyata.'
    ],
    quiz: {
      id: 'quiz-what-is-market',
      title: 'Kuis Pengenalan Pasar',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qm-1',
          question: 'Bagaimana harga suatu aset di pasar finansial umumnya terbentuk?',
          options: [
            'Ditetapkan secara sepihak oleh aplikasi trading',
            'Melalui interaksi alami antara penawaran (supply) dan permintaan (demand)',
            'Berdasarkan nomor undian acak setiap pagi',
            'Dihitung dari jumlah pengguna aktif di media sosial'
          ],
          correctIndex: 1,
          explanation: 'Harga pasar mencerminkan titik temu antara kesediaan pembeli membayar dan kesediaan penjual melepas asetnya.'
        },
        {
          id: 'qm-2',
          question: 'Apa fungsi utama platform TRDS bagi seorang pemula?',
          options: [
            'Menyimpan uang tabungan pengguna secara langsung',
            'Tempat belajar dan menguji strategi trading dengan saldo virtual tanpa risiko rugi nyata',
            'Menjanjikan kekayaan instan dalam 24 jam',
            'Menggantikan peran penasihat keuangan bersertifikat'
          ],
          correctIndex: 1,
          explanation: 'TRDS adalah simulator edukasi murni untuk membangun pemahaman dan ketajaman analisis menggunakan dana virtual 10,000 USDT.'
        }
      ]
    }
  },
  {
    id: 'lesson-what-is-asset',
    categoryId: 'basics',
    title: 'Mengenal Beragam Kelas Aset',
    subtitle: 'Perbedaan karakteristik antara Kripto, Saham, Forex, dan Komoditas.',
    track: 'beginner',
    durationMinutes: 6,
    readTime: '6 menit',
    xpReward: 20,
    intro: 'Aset adalah instrumen atau instrumen bernilai ekonomis yang dapat diperjualbelikan untuk tujuan investasi atau spekulasi.',
    content: [
      'Kripto (Cryptocurrency): Aset digital terdesentralisasi seperti Bitcoin dan Ethereum dengan jam operasional 24/7 dan volatilitas tinggi.',
      'Saham (Stocks): Bukti kepemilikan sebagian atas suatu perusahaan publik (misal Apple, NVIDIA) yang nilainya dipengaruhi oleh kinerja bisnis dan laba perusahaan.',
      'Forex (Foreign Exchange): Pasar pertukaran mata uang antar negara (seperti EUR/USD, GBP/USD) dengan volume perdagangan global harian terbesar.',
      'Komoditas (Commodities): Bahan mentah fisik seperti Emas (Gold) atau Minyak Mentah (Oil) yang sering menjadi aset pelindung nilai (safe haven).'
    ],
    example: {
      title: 'Perbandingan Karakteristik',
      scenario: 'Seorang trader ingin instrumen yang cenderung stabil saat krisis ekonomi global melanda.',
      analysis: 'Emas (Gold) sering dipilih sebagai safe haven karena nilainya secara historis relatif tahan terhadap inflasi dan ketidakpastian geopolitik.'
    },
    keyTakeaways: [
      'Setiap kelas aset memiliki tingkat risiko dan jam pasar yang berbeda.',
      'Kripto bergerak 24/7, sedangkan saham memiliki jam bursa reguler.',
      'Diversifikasi berarti menyebarkan alokasi ke beberapa kelas aset untuk meredam risiko.'
    ],
    quiz: {
      id: 'quiz-what-is-asset',
      title: 'Kuis Kelas Aset',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qa-1',
          question: 'Manakah aset di bawah ini yang mewakili bukti kepemilikan bagian dari sebuah korporasi?',
          options: [
            'Saham (misalnya Apple / AAPL)',
            'Pasangan mata uang EUR/USD',
            'Komoditas Emas batangan',
            'Gas alam'
          ],
          correctIndex: 0,
          explanation: 'Saham adalah surat berharga yang membuktikan kepemilikan proporsional atas suatu entitas perusahaan terbuka.'
        },
        {
          id: 'qa-2',
          question: 'Kapan pasar aset kripto (seperti BTC dan ETH) aktif diperdagangkan?',
          options: [
            'Hanya hari kerja Senin hingga Jumat pukul 09.00 - 16.00',
            'Hanya saat akhir pekan',
            'Aktif 24 jam sehari, 7 hari seminggu tanpa libur',
            'Hanya saat bursa New York dibuka'
          ],
          correctIndex: 2,
          explanation: 'Jaringan blockchain beroperasi tanpa henti sehingga pasar kripto berjalan 24/7 sepanjang tahun.'
        }
      ]
    }
  },
  {
    id: 'lesson-buy-and-sell',
    categoryId: 'basics',
    title: 'Konsep Eksekusi Beli (Buy) dan Jual (Sell)',
    subtitle: 'Bagaimana pedagang menghasilkan keuntungan atau membatasi kerugian dari pergerakan harga.',
    track: 'beginner',
    durationMinutes: 5,
    readTime: '5 menit',
    xpReward: 20,
    intro: 'Dalam perdagangan spot, keuntungan diperoleh dengan membeli pada harga lebih rendah dan menjualnya pada harga lebih tinggi.',
    content: [
      'Posisi Beli (Buy): Kamu menukarkan saldo kas virtual (misal USDT) untuk memperoleh aset tertentu dengan ekspektasi harganya akan naik di masa depan.',
      'Posisi Jual (Sell): Kamu melepas kembali aset yang dimiliki ke dalam bentuk kas virtual untuk mengunci keuntungan (Take Profit) atau membatasi kerugian (Cut Loss).',
      'Keuntungan yang belum direalisasikan disebut Unrealized PnL (floating), sedangkan yang sudah ditutup melalui penjualan disebut Realized PnL.'
    ],
    example: {
      title: 'Kalkulasi PnL Beli & Jual Sederhana',
      scenario: 'Kamu membeli 0.1 BTC saat harga $60,000 (modal $6,000). Kemudian harga naik menjadi $65,000 dan kamu menjual seluruhnya.',
      analysis: 'Hasil penjualan = 0.1 * $65,000 = $6,500. Realized profit kamu adalah $6,500 - $6,000 = +$500 (sebelum potongan biaya virtual).'
    },
    keyTakeaways: [
      'Buy = membeli aset dengan saldo tunai virtual.',
      'Sell = melepas aset kembali ke saldo tunai virtual.',
      'Keuntungan baru benar-benar terkunci saat transaksi jual selesai (Realized).'
    ],
    quiz: {
      id: 'quiz-buy-and-sell',
      title: 'Kuis Beli & Jual',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qbs-1',
          question: 'Apa arti dari istilah Unrealized PnL?',
          options: [
            'Keuntungan yang sudah ditransfer ke rekening bank',
            'Keuntungan atau kerugian mengambang dari posisi terbuka yang belum ditutup/dijual',
            'Saldo bonus pendaftaran',
            'Pajak transaksi bursa'
          ],
          correctIndex: 1,
          explanation: 'Unrealized PnL adalah estimasi laba/rugi saat ini berdasarkan harga pasar terkini yang belum dieksekusi jual.'
        }
      ]
    }
  },
  {
    id: 'lesson-market-vs-limit',
    categoryId: 'basics',
    title: 'Market Order vs Limit Order',
    subtitle: 'Kapan harus menggunakan kecepatan eksekusi dan kapan memilih kepastian harga.',
    track: 'beginner',
    durationMinutes: 7,
    readTime: '7 menit',
    xpReward: 20,
    intro: 'Dua jenis instruksi order paling dasar yang wajib dikuasai sebelum melakukan simulasi di TRDS.',
    content: [
      'Market Order: Instruksi beli/jual yang langsung dieksekusi saat itu juga pada harga terbaik yang tersedia di order book. Prioritas utamanya adalah KECEPATAN eksekusi.',
      'Limit Order: Instruksi beli/jual pada harga tertentu yang kamu tentukan sendiri. Pesanan akan masuk ke order book dan baru tereksekusi ketika harga pasar menyentuh targetmu. Prioritas utamanya adalah KEPATUHAN HARGA.',
      'Gunakan Market Order jika kamu ingin segera masuk ke pasar tanpa peduli perbedaan tipis desimal harga. Gunakan Limit Order jika kamu ingin membeli di harga diskon yang lebih murah atau menjual di harga puncak.'
    ],
    example: {
      title: 'Studi Kasus Eksekusi Virtual',
      scenario: 'Ethereum saat ini seharga $3,450. Kamu berpendapat ETH akan terkoreksi ke $3,300 sebelum memantul naik.',
      analysis: 'Daripada menatap layar berjam-jam, pasang Limit Buy Order pada harga $3,300. Sistem simulator TRDS akan otomatis mengeksekusi begitu harga ETH menyentuh $3,300.'
    },
    keyTakeaways: [
      'Market Order = Instan, harga mengikuti pasar saat detik itu.',
      'Limit Order = Bersabar, harga ditentukan oleh trader.',
      'Di simulator TRDS, kamu bisa mencoba kedua jenis order ini di tab Simulator.'
    ],
    quiz: {
      id: 'quiz-market-vs-limit',
      title: 'Kuis Market vs Limit Order',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qmvl-1',
          question: 'Solana (SOL) berada di harga $145. Kamu ingin membeli jika harganya turun ke $140. Order apa yang tepat?',
          options: [
            'Market Order Beli',
            'Limit Order Beli di harga $140',
            'Market Order Jual',
            'Cancel Order'
          ],
          correctIndex: 1,
          explanation: 'Limit Buy di pasang di bawah harga pasar saat ini dan akan menunggu hingga harga pasar turun menyentuh target tersebut.'
        },
        {
          id: 'qmvl-2',
          question: 'Kelebihan utama dari Market Order adalah:',
          options: [
            'Bisa membeli di harga berapapun yang kita mau',
            'Eksekusi instan tanpa perlu menunggu antrean order book',
            'Bebas dari segala bentuk biaya trading',
            'Pasti menghasilkan profit 100%'
          ],
          correctIndex: 1,
          explanation: 'Market order mengutamakan kecepatan: order langsung dicocokkan dengan penawaran terbaik yang ada.'
        }
      ]
    }
  },

  // =================================================================
  // KATEGORI B: PASAR & HARGA (MARKET_PRICE)
  // =================================================================
  {
    id: 'lesson-supply-demand',
    categoryId: 'market_price',
    title: 'Hukum Penawaran & Permintaan (Supply & Demand)',
    subtitle: 'Prinsip utama yang menggerakkan setiap titik pergerakan harga di dunia finansial.',
    track: 'beginner',
    durationMinutes: 6,
    readTime: '6 menit',
    xpReward: 20,
    intro: 'Grafik harga pada dasarnya adalah catatan visual pertempuran antara penjual (supply) dan pembeli (demand).',
    content: [
      'Demand (Permintaan): Jumlah aset yang ingin dibeli oleh pelaku pasar pada tingkat harga tertentu. Jika permintaan tinggi dan stok terbatas, harga naik.',
      'Supply (Penawaran): Jumlah aset yang ingin dilepas atau dijual ke pasar. Jika penawaran melimpah sementara minat beli rendah, harga turun.',
      'Area Konsolidasi / Keseimbangan (Equilibrium): Ketika kekuatan pembeli dan penjual seimbang, harga cenderung bergerak menyamping (sideways) dalam rentang sempit.'
    ],
    example: {
      title: 'Pengumuman Laba Kuartalan',
      scenario: 'Perusahaan NVIDIA merilis laba di atas ekspektasi analis sebesar 40%.',
      analysis: 'Investor berbondong-bondong ingin memiliki saham NVDA (demand melonjak masif). Para pemilik saham menolak menjual murah, sehingga harga melompat naik (gap up).'
    },
    keyTakeaways: [
      'Harga naik ketika Demand > Supply.',
      'Harga turun ketika Supply > Demand.',
      'Sideways terjadi ketika Supply dan Demand seimbang.'
    ],
    quiz: {
      id: 'quiz-supply-demand',
      title: 'Kuis Supply & Demand',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qsd-1',
          question: 'Apa yang biasanya terjadi jika banyak trader ingin menjual aset sedangkan sedikit sekali pembeli yang berminat?',
          options: [
            'Harga akan melesat naik',
            'Harga akan cenderung tertekan turun',
            'Pasar langsung ditutup otomatis',
            'Jumlah koin berkurang dengan sendirinya'
          ],
          correctIndex: 1,
          explanation: 'Kelebihan penawaran memaksa penjual menurunkan harga agar asetnya laku dibeli, sehingga harga pasar tertekan turun.'
        }
      ]
    }
  },
  {
    id: 'lesson-bid-ask-spread',
    categoryId: 'market_price',
    title: 'Bid, Ask, Spread & Likuiditas Pasar',
    subtitle: 'Mengenal harga beli tertinggi, harga jual terendah, dan biaya tersembunyi transaksi.',
    track: 'intermediate',
    durationMinutes: 7,
    readTime: '7 menit',
    xpReward: 20,
    intro: 'Dalam setiap pasar selalu ada dua harga berbeda di saat bersamaan: harga Bid dan harga Ask.',
    content: [
      'Bid: Harga tertinggi yang bersedia dibayar oleh pembeli saat ini.',
      'Ask (atau Offer): Harga terendah yang bersedia diterima oleh penjual saat ini.',
      'Spread: Selisih antara harga Ask dan harga Bid (Spread = Ask - Bid). Semakin kecil spread, semakin likuid pasar tersebut.',
      'Likuiditas: Kemudahan suatu aset untuk diperjualbelikan dengan cepat dalam jumlah besar tanpa menyebabkan pergeseran harga yang signifikan.'
    ],
    example: {
      title: 'Ilustrasi Spread Kasus Bitcoin',
      scenario: 'Di bursa, harga Ask BTC tercatat $64,002 dan harga Bid tercatat $64,000.',
      analysis: 'Spread adalah $2. Jika kamu langsung melakukan Market Buy, kamu membeli di $64,002. Jika sedetik kemudian kamu Market Sell, kamu menjual di $64,000. Selisih $2 adalah spread.'
    },
    keyTakeaways: [
      'Bid = Harga antrean beli tertinggi.',
      'Ask = Harga antrean jual terendah.',
      'Aset likuid memiliki spread tipis dan volume transaksi besar.'
    ],
    quiz: {
      id: 'quiz-bid-ask-spread',
      title: 'Kuis Bid, Ask & Spread',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qbas-1',
          question: 'Apa rumus untuk menghitung nilai Spread di pasar?',
          options: [
            'Spread = Volume / Harga',
            'Spread = Ask - Bid',
            'Spread = Modal * Leverage',
            'Spread = High + Low'
          ],
          correctIndex: 1,
          explanation: 'Spread dihitung dari selisih harga jual terendah (Ask) dikurangi harga beli tertinggi (Bid).'
        }
      ]
    }
  },

  // =================================================================
  // KATEGORI C: GRAFIK & CANDLESTICK (CHARTS)
  // =================================================================
  {
    id: 'lesson-candlestick-anatomy',
    categoryId: 'charts',
    title: 'Anatomi Lengkap Candlestick (OHLC)',
    subtitle: 'Membaca bahasa visual pergerakan harga dari Open, High, Low, dan Close.',
    track: 'beginner',
    durationMinutes: 8,
    readTime: '8 menit',
    xpReward: 20,
    intro: 'Candlestick diciptakan di Jepang pada abad ke-18 oleh Munehisa Homma untuk mencatat harga beras, dan kini menjadi standar visual grafik keuangan global.',
    content: [
      'Satu batang candlestick merangkum pergerakan harga dalam periode waktu tertentu.',
      'Open (O): Harga saat sesi waktu tersebut baru saja dimulai.',
      'High (H): Titik harga tertinggi yang sempat dicapai selama sesi berlangsung.',
      'Low (L): Titik harga terendah yang sempat disentuh selama sesi berlangsung.',
      'Close (C): Harga terakhir saat sesi waktu tersebut resmi berakhir.',
      'Badan Lilin (Body): Area persegi tebal di antara harga Open dan Close.',
      'Sumbu / Ekor (Wick / Shadow): Garis vertikal tipis di atas dan di bawah badan lilin yang merekam titik ekstrem High dan Low.'
    ],
    example: {
      title: 'Membaca Candlestick 1 Jam',
      scenario: 'Pukul 10.00 harga dibuka di $100 (Open). Sempat turun ke $95 (Low), lalu melonjak ke $115 (High), dan pada 11.00 ditutup di $110 (Close).',
      analysis: 'Karena Close ($110) lebih tinggi dari Open ($100), lilin berwarna hijau (bullish). Badan lilin membentang dari $100 ke $110, sumbu atas mencapai $115, dan sumbu bawah menyentuh $95.'
    },
    keyTakeaways: [
      'Candlestick memuat 4 data penting: Open, High, Low, Close (OHLC).',
      'Body mewakili rentang Open ke Close.',
      'Wicks menunjukkan penolakan harga (price rejection) pada titik ekstrem.'
    ],
    quiz: {
      id: 'quiz-candlestick-anatomy',
      title: 'Kuis Anatomi Candlestick',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qca-1',
          question: 'Apa arti dari sumbu atas (upper wick) yang sangat panjang pada sebuah candlestick?',
          options: [
            'Pembeli sempat mendorong harga sangat tinggi, namun penjual berhasil menekan harga kembali turun sebelum sesi ditutup',
            'Tidak ada transaksi yang terjadi sama sekali',
            'Pasar sedang libur nasional',
            'Akun pengguna mengalami koneksi putus'
          ],
          correctIndex: 0,
          explanation: 'Sumbu atas yang panjang menandakan adanya penolakan harga di area atas (selling pressure / rejection).'
        },
        {
          id: 'qca-2',
          question: 'Apa kepanjangan dari singkatan OHLC dalam grafik trading?',
          options: [
            'Order, Holding, Limit, Cancel',
            'Open, High, Low, Close',
            'Offer, Hedge, Liquidity, Cash',
            'Optimal, Hedge, Loss, Capital'
          ],
          correctIndex: 1,
          explanation: 'OHLC adalah singkatan dari Open (pembukaan), High (tertinggi), Low (terendah), dan Close (penutupan).'
        }
      ]
    }
  },
  {
    id: 'lesson-green-red-candles',
    categoryId: 'charts',
    title: 'Lilin Hijau (Bullish) vs Lilin Merah (Bearish)',
    subtitle: 'Memahami siapa yang memenangkan pertempuran harga di setiap sesi.',
    track: 'beginner',
    durationMinutes: 5,
    readTime: '5 menit',
    xpReward: 20,
    intro: 'Warna candlestick memberikan informasi instan mengenai sentimen pasar dalam satu kedipan mata.',
    content: [
      'Lilin Hijau (Bullish Candle): Terbentuk jika harga Close berada DI ATAS harga Open (Close > Open). Ini berarti pembeli mendominasi dan mendorong harga naik.',
      'Lilin Merah (Bearish Candle): Terbentuk jika harga Close berada DI BAWAH harga Open (Close < Open). Ini berarti penjual mendominasi dan menekan harga turun.',
      'Doji: Lilin di mana harga Open dan Close hampir persis sama, menandakan keraguan atau keseimbangan mutlak antara pembeli dan penjual.'
    ],
    example: {
      title: 'Candle Bullish Kuat (Marubozu)',
      scenario: 'Lilin hijau dengan badan tebal penuh hampir tanpa sumbu sama sekali.',
      analysis: 'Ini menunjukkan dominasi mutlak pihak pembeli dari detik pertama pembukaan hingga detik penutupan sesi.'
    },
    keyTakeaways: [
      'Hijau = Bullish (Close > Open).',
      'Merah = Bearish (Close < Open).',
      'Ukuran badan lilin mencerminkan kekuatan momentum.'
    ],
    quiz: {
      id: 'quiz-green-red-candles',
      title: 'Kuis Lilin Hijau vs Merah',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qgrc-1',
          question: 'Secara umum, candlestick berwarna hijau merepresentasikan kondisi:',
          options: [
            'Harga ditutup lebih tinggi daripada harga pembukaan pada periode tersebut',
            'Pasar sedang mengalami pemadaman server',
            'Semua order dibatalkan oleh bursa',
            'Trader kehilangan seluruh saldonya'
          ],
          correctIndex: 0,
          explanation: 'Lilin hijau (bullish) mengindikasikan bahwa harga aset mengalami kenaikan selama periode waktu yang diamati.'
        }
      ]
    }
  },
  {
    id: 'lesson-timeframes',
    categoryId: 'charts',
    title: 'Mengenal Timeframe Grafik (1m, 15m, 1H, 1D)',
    subtitle: 'Memilih kacamata yang tepat antara sudut pandang scalper, day trader, dan swing trader.',
    track: 'intermediate',
    durationMinutes: 7,
    readTime: '7 menit',
    xpReward: 20,
    intro: 'Timeframe menentukan berapa lama waktu yang direpresentasikan oleh setiap 1 batang candlestick pada grafik.',
    content: [
      'Timeframe Pendek (1m, 5m, 15m): Setiap lilin mencatat pergerakan 1 hingga 15 menit. Menampilkan detail mikro namun memiliki banyak "noise" (sinyal palsu).',
      'Timeframe Menengah (1H, 4H): Memberikan gambaran struktur tren intraday yang lebih jernih dan stabil.',
      'Timeframe Panjang (1D, 1W): Setiap lilin mewakili 1 hari atau 1 minggu. Digunakan untuk melihat arah tren makro dan level harga kunci institusi.',
      'Praktik Terbaik: Analisis Multi-Timeframe. Selalu lihat tren besar di timeframe tinggi (1D/4H) sebelum mencari titik masuk di timeframe lebih rendah (1H/15m).'
    ],
    example: {
      title: 'Mencegah Jebakan Tren Palsu',
      scenario: 'Di grafik 5m harga tampak sedang melompat naik kencang. Namun di grafik 1D harga sedang membentur resistance tren turun utama.',
      analysis: 'Kenaikan di 5m kemungkinan hanya koreksi sesaat sebelum tren turun besar di 1D berlanjut. Memeriksa 1D mencegah trader terjebak FOMO.'
    },
    keyTakeaways: [
      'Timeframe tinggi (1D, 4H) menentukan arah tren utama.',
      'Timeframe rendah (15m, 1m) digunakan untuk presisi waktu entri.',
      'Jangan pernah trading hanya mengandalkan 1 timeframe mikro tanpa melihat peta besarnya.'
    ],
    quiz: {
      id: 'quiz-timeframes',
      title: 'Kuis Timeframe Grafik',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qtf-1',
          question: 'Jika kamu memilih timeframe "1H" pada simulator TRDS, apa arti satu batang lilin di layar?',
          options: [
            'Pergerakan harga selama 1 hari penuh',
            'Pergerakan harga selama rentang waktu 1 jam',
            'Harga rata-rata 1 minggu terakhir',
            'Total volume perdagangan 1 bulan'
          ],
          correctIndex: 1,
          explanation: 'Pada timeframe 1H (1 Hour), satu batang lilin merepresentasikan pergerakan harga selama 60 menit.'
        }
      ]
    }
  },
  {
    id: 'lesson-support-resistance',
    categoryId: 'charts',
    title: 'Konsep Dasar Support dan Resistance',
    subtitle: 'Lantai pembatas bawah dan atap penahan atas pergerakan harga.',
    track: 'intermediate',
    durationMinutes: 8,
    readTime: '8 menit',
    xpReward: 20,
    intro: 'Support dan Resistance adalah dua konsep teknikal paling fundamental yang dipantau oleh jutaan trader di seluruh dunia.',
    content: [
      'Support (Lantai Bawah): Level harga di mana minat beli (demand) dianggap cukup kuat untuk menahan harga agar tidak jatuh lebih dalam.',
      'Resistance (Atap Atas): Level harga di mana tekanan jual (supply) dianggap cukup kuat untuk menghentikan laju kenaikan harga.',
      'Role Reversal: Ketika level resistance berhasil ditembus ke atas dengan kuat (breakout), level tersebut sering kali beralih fungsi menjadi support baru.'
    ],
    example: {
      title: 'Pantulan di Area Support',
      scenario: 'Harga Bitcoin turun mendekati $60,000, lalu pembeli masuk secara masif dan harga memantul kembali ke $63,000. Kejadian ini berulang 3 kali.',
      analysis: '$60,000 menjadi area Support psikologis kuat karena pembeli konsisten menganggap harga tersebut menarik untuk dibeli.'
    },
    keyTakeaways: [
      'Support menahan penurunan harga.',
      'Resistance menahan kenaikan harga.',
      'Tembusnya resistance sering mengubahnya menjadi support baru.'
    ],
    quiz: {
      id: 'quiz-support-resistance',
      title: 'Kuis Support & Resistance',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qsr-1',
          question: 'Apa yang dimaksud dengan level Support?',
          options: [
            'Layanan pelanggan aplikasi trading',
            'Area harga di mana minat beli diperkirakan cukup kuat menahan harga dari penurunan lebih lanjut',
            'Biaya bulanan untuk menggunakan indikator grafik',
            'Tingkat leverage maksimal sebuah akun'
          ],
          correctIndex: 1,
          explanation: 'Support berfungsi layaknya lantai yang menopang harga karena tingginya konsentrasi order beli di area tersebut.'
        }
      ]
    }
  },

  // =================================================================
  // KATEGORI D: INDIKATOR TEKNIKAL (INDICATORS)
  // =================================================================
  {
    id: 'lesson-moving-average',
    categoryId: 'indicators',
    title: 'Moving Average (MA) — Mengikuti Arah Tren',
    subtitle: 'Menyaring kebisingan pasar untuk mengenali arah tren yang sebenarnya.',
    track: 'intermediate',
    durationMinutes: 7,
    readTime: '7 menit',
    xpReward: 20,
    intro: 'Moving Average menghitung harga rata-rata aset selama periode tertentu untuk menghaluskan fluktuasi jangka pendek.',
    content: [
      'Simple Moving Average (SMA) menjumlahkan harga penutupan selama N periode lalu membaginya dengan N.',
      'Jika harga berada di atas garis MA yang melandai naik, pasar dianggap berada dalam tren naik (Uptrend).',
      'Jika harga berada di bawah garis MA yang melandai turun, pasar berada dalam tren turun (Downtrend).',
      'Golden Cross & Death Cross: Golden cross terjadi saat MA jangka pendek (misal MA 50) memotong ke atas MA jangka panjang (misal MA 200), menandakan potensi tren naik besar.'
    ],
    example: {
      title: 'Identifikasi Tren dengan MA 200',
      scenario: 'Harga saham Apple berada di $220, sementara garis SMA 200 hari berada di $180 dan terus mengarah ke atas.',
      analysis: 'Struktur jangka panjang saham tersebut sangat sehat dan berada dalam fase Bullish yang kuat.'
    },
    keyTakeaways: [
      'MA menghaluskan fluktuasi harga.',
      'Harga di atas MA = potensi tren naik; di bawah MA = potensi tren turun.',
      'MA sering berfungsi sebagai support atau resistance dinamis.'
    ],
    quiz: {
      id: 'quiz-moving-average',
      title: 'Kuis Moving Average',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qma-1',
          question: 'Kondisi "Golden Cross" biasanya ditandai oleh:',
          options: [
            'MA periode pendek memotong ke atas MA periode panjang',
            'MA periode pendek memotong ke bawah MA periode panjang',
            'Harga aset anjlok ke angka nol',
            'Pasar saham ditutup lebih awal'
          ],
          correctIndex: 0,
          explanation: 'Golden cross adalah sinyal teknikal bullish ketika rata-rata jangka pendek melintasi ke atas rata-rata jangka panjang.'
        }
      ]
    }
  },
  {
    id: 'lesson-rsi-momentum',
    categoryId: 'indicators',
    title: 'Relative Strength Index (RSI) — Overbought & Oversold',
    subtitle: 'Mengukur kecepatan dan perubahan momentum pergerakan harga.',
    track: 'intermediate',
    durationMinutes: 8,
    readTime: '8 menit',
    xpReward: 20,
    intro: 'RSI adalah indikator osilator dengan skala 0 hingga 100 yang diciptakan oleh J. Welles Wilder.',
    content: [
      'Overbought (Jenuh Beli - Nilai > 70): Menandakan harga telah melesat sangat cepat dan mungkin rentan mengalami koreksi atau aksi ambil untung.',
      'Oversold (Jenuh Jual - Nilai < 30): Menandakan harga telah anjlok sangat dalam dan ada potensi terjadinya pantulan teknikal (rebound).',
      'Perhatian Penting: Dalam tren yang sangat kuat, RSI bisa bertahan di atas 70 atau di bawah 30 dalam waktu yang cukup lama. Jangan langsung melawan tren hanya karena RSI menyentuh angka ekstrem.'
    ],
    example: {
      title: 'Peluang Rebound di Area Oversold',
      scenario: 'Harga SOL turun 12% dalam 2 hari, membawa indikator RSI 14-periode menyentuh angka 22 (deep oversold).',
      analysis: 'Kondisi oversold ekstrem ini menarik pembeli yang mencari harga diskon, sehingga peluang terjadinya pantulan jangka pendek meningkat.'
    },
    keyTakeaways: [
      'RSI bergerak dalam rentang skala 0 sampai 100.',
      'RSI > 70 = area Overbought (jenuh beli).',
      'RSI < 30 = area Oversold (jenuh jual).'
    ],
    quiz: {
      id: 'quiz-rsi-momentum',
      title: 'Kuis Indikator RSI',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qrsi-1',
          question: 'Jika indikator RSI suatu aset berada pada angka 85, kondisi ini dikategorikan sebagai:',
          options: [
            'Oversold (Jenuh Jual)',
            'Overbought (Jenuh Beli)',
            'Netral sempurna',
            'Pasar tidak likuid'
          ],
          correctIndex: 1,
          explanation: 'Angka RSI di atas 70 menunjukkan kondisi Overbought di mana momentum beli telah berjalan sangat intens.'
        }
      ]
    }
  },

  // =================================================================
  // KATEGORI E: MANAJEMEN RISIKO (RISK)
  // =================================================================
  {
    id: 'lesson-what-is-risk',
    categoryId: 'risk',
    title: 'Apa itu Risiko & Mengapa Modal Wajib Dijaga?',
    subtitle: 'Pilar nomor satu yang membedakan trader profesional dari pejudi amatir.',
    track: 'beginner',
    durationMinutes: 7,
    readTime: '7 menit',
    xpReward: 20,
    intro: 'Dalam trading, kamu tidak bisa mengontrol ke mana pasar akan bergerak. Satu-satunya hal yang bisa kamu kontrol 100% adalah besaran risiko yang kamu ambil.',
    content: [
      'Setiap analisa teknikal maupun fundamental hanyalah permainan probabilitas, bukan kepastian mutlak.',
      'Jika kamu merugi 50% dari modalmu ($10,000 menjadi $5,000), kamu membutuhkan keuntungan 100% dari sisa modalmu hanya untuk kembali ke titik impas (break-even)!',
      'Tugas utama seorang trader bukanlah mencetak profit tercepat, melainkan melindungi modal agar selalu bisa bertahan untuk transaksi berikutnya.'
    ],
    example: {
      title: 'Matematika Pemulihan Kerugian (Drawdown Math)',
      scenario: 'Trader A kehilangan 10% modal ($10,000 menjadi $9,000). Trader B mempertaruhkan segalanya dan kehilangan 80% modal ($10,000 menjadi $2,000).',
      analysis: 'Trader A hanya butuh cuan +11.1% untuk pulih. Trader B butuh cuan +400% untuk sekadar kembali ke modal awal—tugas yang hampir mustahil tanpa judi ekstrem.'
    },
    keyTakeaways: [
      'Modal adalah aset paling berharga trader.',
      'Semakin dalam kerugian, semakin berat persentase yang dibutuhkan untuk kembali impas.',
      'Fokus utama trader adalah bertahan hidup di pasar.'
    ],
    quiz: {
      id: 'quiz-what-is-risk',
      title: 'Kuis Pemahaman Risiko',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qwir-1',
          question: 'Jika modal virtualmu turun sebesar 50% dari $10,000 menjadi $5,000, berapa persen keuntungan yang dibutuhkan dari sisa $5,000 untuk kembali ke $10,000?',
          options: ['25%', '50%', '100%', '200%'],
          correctIndex: 2,
          explanation: '$5,000 harus menghasilkan tambahan $5,000 (yaitu 100% dari modal saat ini) agar kembali ke $10,000.'
        }
      ]
    }
  },
  {
    id: 'lesson-position-sizing-1percent',
    categoryId: 'risk',
    title: 'Aturan Risiko 1% (Position Sizing)',
    subtitle: 'Cara menghitung ukuran posisi agar aman dari rentetan kerugian.',
    track: 'intermediate',
    durationMinutes: 8,
    readTime: '8 menit',
    xpReward: 20,
    intro: 'Aturan 1% adalah aturan baku manajemen risiko yang diterapkan oleh fund manager terkemuka dunia.',
    content: [
      'Aturan 1% menyatakan: Jangan pernah merisikokan lebih dari 1% dari total ekuitas portofoliomu pada satu transaksi tunggal.',
      'Jika modalmu adalah $10,000 (saldo demo TRDS), maka risiko maksimal per transaksi adalah $100.',
      'Artinya, jika analisamu keliru dan Stop Loss tersentuh, kamu hanya kehilangan $100. Portofoliomu masih menyisakan $9,900 (99%) untuk mencoba lagi.',
      'Dengan aturan ini, kamu harus mengalami kerugian berturut-turut sebanyak 50 kali sebelum modalmu tergerus separuh—skenario yang sangat jarang terjadi jika kamu memiliki strategi dasar.'
    ],
    example: {
      title: 'Perhitungan Risiko 1% di TRDS',
      scenario: 'Modal virtual: $10,000. Risiko 1% = $100. Kamu ingin membeli saham pada harga $50 dengan Stop Loss di $48.',
      analysis: 'Jarak Stop Loss = $50 - $48 = $2 per lembar saham. Jumlah maksimal lembar saham yang boleh dibeli = $100 / $2 = 50 lembar (total nilai posisi $2,500).'
    },
    keyTakeaways: [
      'Batas risiko maksimal per transaksi = 1% dari total modal.',
      'Besar posisi disesuaikan dengan jarak titik Stop Loss.',
      'Aturan 1% menjamin ketahanan psikologis saat menghadapi loss streak.'
    ],
    quiz: {
      id: 'quiz-position-sizing-1percent',
      title: 'Kuis Aturan 1%',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qps-1',
          question: 'Berapa batas kerugian uang virtual maksimal per transaksi jika kamu mematuhi Aturan 1% dengan modal awal $10,000?',
          options: ['$10', '$100', '$1,000', '$5,000'],
          correctIndex: 1,
          explanation: '1% dari $10,000 adalah $100. Nilai ini menjadi batas mutlak kerugian yang ditoleransi pada satu posisi.'
        }
      ]
    }
  },
  {
    id: 'lesson-stop-loss-take-profit',
    categoryId: 'risk',
    title: 'Stop Loss, Take Profit & Rasio Risk/Reward Minimal 1:2',
    subtitle: 'Kunci mencetak profit konsisten meski win rate analisamu hanya 50%.',
    track: 'intermediate',
    durationMinutes: 8,
    readTime: '8 menit',
    xpReward: 20,
    intro: 'Kamu tidak perlu benar di setiap transaksi untuk menghasilkan keuntungan bersih di akhir bulan.',
    content: [
      'Stop Loss (SL): Titik harga di mana kamu secara sukarela keluar dari posisi untuk membatasi kerugian sebelum bertambah parah.',
      'Take Profit (TP): Titik harga target di mana kamu mengunci keuntungan sesuai rencana.',
      'Rasio Risk to Reward (R:R): Perbandingan antara potensi kerugian (risk) dengan potensi keuntungan (reward).',
      'Standar Emas R:R 1:2: Untuk setiap $1 risiko kerugian, kamu menargetkan potensi keuntungan minimal $2.',
      'Keajaiban R:R 1:2: Dari 10 transaksi, jika kamu salah 5 kali (kalah 5 x $100 = -$500) dan benar 5 kali (menang 5 x $200 = +$1,000), kamu tetap mengantongi PROFIT BERSIH +$500!'
    ],
    example: {
      title: 'Simulasi Rasio 1:2 pada Bitcoin',
      scenario: 'Beli BTC di $60,000. Pasang Stop Loss di $59,000 (risiko $1,000) dan Take Profit di $62,000 (reward $2,000).',
      analysis: 'Rasio Risk:Reward adalah 1:2. Keuntungan saat menang bernilai dua kali lipat dibanding kerugian saat kalah.'
    },
    keyTakeaways: [
      'Selalu tentukan SL dan TP sebelum menekan tombol order.',
      'Gunakan rasio Risk/Reward minimal 1:2.',
      'Dengan rasio 1:2, win rate 50% sudah cukup untuk menghasilkan pertumbuhan modal konsisten.'
    ],
    quiz: {
      id: 'quiz-stop-loss-take-profit',
      title: 'Kuis Risk/Reward',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qrr-1',
          question: 'Jika kamu merisikokan $50 pada sebuah transaksi, berapa target keuntungan yang harus ditetapkan untuk memenuhi rasio Risk/Reward 1:2?',
          options: ['$25', '$50', '$100', '$250'],
          correctIndex: 2,
          explanation: 'Dengan rasio 1:2, target reward adalah 2 kali lipat dari risiko: 2 * $50 = $100.'
        },
        {
          id: 'qrr-2',
          question: 'Mengapa trader disiplin selalu memasang batas Stop Loss?',
          options: [
            'Agar aplikasi trading bisa memungut biaya lebih besar',
            'Untuk membatasi kerugian terukur jika pergerakan pasar berlawanan dengan analisa',
            'Menghapus riwayat transaksi lama',
            'Menjamin harga pasti berbalik arah'
          ],
          correctIndex: 1,
          explanation: 'Stop Loss adalah jaring pengaman otomatis untuk mencegah kerugian kecil berkembang menjadi kerugian fatal.'
        }
      ]
    }
  },

  // =================================================================
  // KATEGORI F: PSIKOLOGI TRADING (PSYCHOLOGY)
  // =================================================================
  {
    id: 'lesson-fomo-discipline',
    categoryId: 'psychology',
    title: 'Mengatasi FOMO (Fear of Missing Out)',
    subtitle: 'Menolak dorongan impulsif mengejar lilin hijau yang sudah terbang tinggi.',
    track: 'beginner',
    durationMinutes: 6,
    readTime: '6 menit',
    xpReward: 20,
    intro: 'FOMO adalah rasa takut tertinggal keuntungan yang sering memicu trader membeli di pucuk harga sebelum pasar berbalik jatuh.',
    content: [
      'Ketika melihat harga sebuah koin atau saham melonjak puluhan persen dalam hitungan jam, otak manusia secara biologis memicu dorongan serakah (greed).',
      'Membeli saat harga sudah mengalami kenaikan parabola adalah salah satu cara tercepat kehilangan modal.',
      'Ingat prinsip pasar: Pasar selalu menyajikan peluang baru setiap hari. Melewatkan satu peluang jauh lebih baik daripada kehilangan uang sungguhan.'
    ],
    example: {
      title: 'Siklus FOMO Klasik',
      scenario: 'Koin meme melonjak +80% dalam 4 jam. Trader yang merasa FOMO langsung membeli di harga tertinggi karena takut tertinggal.',
      analysis: 'Pembeli awal mulai merealisasikan keuntungan (take profit), volume beli habis, dan harga terkoreksi 40%. Trader FOMO kini terjebak di posisi rugi.'
    },
    keyTakeaways: [
      'Jangan pernah mengejar harga yang sudah melonjak terlalu jauh.',
      'Peluang di pasar finansial tidak akan pernah habis.',
      'Trading yang baik adalah trading yang tenang dan terencana, bukan impulsif.'
    ],
    quiz: {
      id: 'quiz-fomo-discipline',
      title: 'Kuis Mengatasi FOMO',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qfomo-1',
          question: 'Tindakan paling bijak saat melihat aset yang melonjak drastis tanpa rencana trading matang adalah:',
          options: [
            'Langsung membeli dengan seluruh modal yang ada menggunakan market order',
            'Tetap tenang, jangan mengejar harga, dan tunggu terbentuknya struktur koreksi atau setup baru',
            'Meminjam dana tambahan untuk memperbesar posisi',
            'Menyalahkan pengguna lain di media sosial'
          ],
          correctIndex: 1,
          explanation: 'Disiplin menahan diri dari FOMO dan menunggu setup harga yang wajar adalah tanda kematangan seorang trader.'
        }
      ]
    }
  },
  {
    id: 'lesson-emotional-revenge',
    categoryId: 'psychology',
    title: 'Menghindari Revenge Trading & Keputusan Emosional',
    subtitle: 'Cara tetap berkepala dingin setelah mengalami transaksi yang merugi.',
    track: 'intermediate',
    durationMinutes: 7,
    readTime: '7 menit',
    xpReward: 20,
    intro: 'Revenge Trading adalah dorongan emosional untuk segera "membalas dendam" ke pasar setelah terkena Stop Loss.',
    content: [
      'Rasa marah dan frustrasi akibat rugi sering memicu trader melipatgandakan ukuran posisi tanpa analisa objektif.',
      'Pasar tidak memiliki emosi dan tidak berutang apapun kepada siapapun. Melawan pasar saat emosi tidak stabil hampir pasti berujung kehancuran portofolio.',
      'Solusi Praktis: Terapkan aturan "Cool-off Period". Jika kamu mengalami 2 kali kerugian dalam satu hari, tutup aplikasi trading dan istirahat sejenak.'
    ],
    example: {
      title: 'Bahaya Revenge Trading',
      scenario: 'Setelah merugi $100 di BTC, seorang trader langsung membuka posisi baru bernilai 3x lipat di ETH tanpa membaca grafik sama sekali.',
      analysis: 'Keputusan ini murni didorong emosi amarah. Ketika ETH turun lagi sedikit saja, kerugian membengkak menjadi -$400.'
    },
    keyTakeaways: [
      'Kerugian adalah biaya operasional bisnis trading yang wajar.',
      'Jangan pernah mencoba membalas dendam ke pasar.',
      'Gunakan jeda istirahat jika emosi mulai mengaburkan objektivitas analisamu.'
    ],
    quiz: {
      id: 'quiz-emotional-revenge',
      title: 'Kuis Revenge Trading',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qer-1',
          question: 'Apa yang dimaksud dengan fenomena "Revenge Trading"?',
          options: [
            'Membuka transaksi impulsif dengan risiko berlebih untuk segera mengembalikan kerugian sebelumnya',
            'Berbagi keuntungan dengan teman',
            'Melakukan riset fundamental mendalam selama seminggu',
            'Menyimpan seluruh aset dalam dompet dingin (cold wallet)'
          ],
          correctIndex: 0,
          explanation: 'Revenge trading dipicu oleh kemarahan pasca-loss dan merupakan salah satu penyebab utama hancurnya modal trader.'
        }
      ]
    }
  },

  // =================================================================
  // KATEGORI G: PRAKTIK SIMULASI VIRTUAL (PRACTICE)
  // =================================================================
  {
    id: 'lesson-simulator-practice',
    categoryId: 'practice',
    title: 'Memaksimalkan Simulator TRDS Secara Efektif',
    subtitle: 'Membangun kebiasaan disiplin trading tanpa mempertaruhkan tabungan nyata.',
    track: 'beginner',
    durationMinutes: 6,
    readTime: '6 menit',
    xpReward: 20,
    intro: 'Simulator TRDS dirancang khusus untuk mereplikasi dinamika pasar sesungguhnya dengan saldo demo $10,000 USDT.',
    content: [
      'Perlakukan Saldo Virtual Seperti Uang Sungguhan: Kunci kesuksesan belajar di simulator adalah menjaga mindset seolah modal tersebut adalah hasil jerih payahmu sendiri.',
      'Gunakan Limit Order untuk Melatih Kesabaran: Jangan selalu menggunakan Market Order. Pasang Limit Buy di area support dan amati bagaimana pasar merespons.',
      'Eksplorasi Fitur Portofolio: Pantau Unrealized PnL dan Realized PnL secara berkala untuk mengevaluasi efektivitas strategimu.'
    ],
    example: {
      title: 'Latihan Rutin di Simulator TRDS',
      scenario: 'Pilih salah satu aset (misal ETH/USD). Analisa grafik 1H, tentukan support di $3,350, dan pasang Limit Order Beli.',
      analysis: 'Begitu tereksekusi, catat alasan entrimu dan pantau apakah harga memantul sesuai ekspektasi tanpa risiko uang sepeserpun.'
    },
    keyTakeaways: [
      'TRDS 100% menggunakan dana virtual edukasi.',
      'Perlakukan saldo demo dengan kesungguhan yang sama seperti modal riil.',
      'Evaluasi portofolio membantumu mengenali kelemahan dan kelebihan strategimu.'
    ],
    quiz: {
      id: 'quiz-simulator-practice',
      title: 'Kuis Praktik Simulator TRDS',
      rewardXp: 30,
      bonusPassXp: 20,
      questions: [
        {
          id: 'qsp-1',
          question: 'Bagaimana cara paling efektif memanfaatkan saldo demo $10,000 USDT di TRDS?',
          options: [
            'Langsung menghabiskan seluruh modal dalam satu kali tebakan',
            'Berlatih menguji aturan manajemen risiko 1% dan eksekusi order secara disiplin',
            'Mencoba menarik dana virtual tersebut ke rekening bank',
            'Menunggu saldo bertambah secara otomatis tanpa melakukan apa-apa'
          ],
          correctIndex: 1,
          explanation: 'Simulator TRDS adalah sarana edukasi terbaik untuk melatih kedisiplinan eksekusi dan manajemen risiko tanpa tekanan finansial nyata.'
        }
      ]
    }
  },

  // =================================================================
  // MATERI EKSKLUSIF TRDS PREMIUM (ADVANCED CURRICULUM)
  // =================================================================
  {
    id: 'lesson-advanced-risk-sharpe',
    categoryId: 'risk',
    title: 'Analisis Risiko Lanjutan: Sharpe Ratio & Maximum Drawdown',
    subtitle: 'Metrik kuantitatif institusional untuk mengukur ketahanan strategi portofolio virtual.',
    track: 'advanced',
    durationMinutes: 9,
    readTime: '9 menit',
    xpReward: 35,
    isPremium: true,
    intro: 'Trader profesional dan dana institusional tidak hanya mengevaluasi keuntungan absolut, melainkan seberapa besar risiko yang diambil untuk menghasilkan keuntungan tersebut.',
    content: [
      'Sharpe Ratio mengukur imbal hasil berlebih (excess return) relatif terhadap volatilitas risiko aset. Semakin tinggi angka Sharpe (> 1.0), semakin efisien strategi tersebut.',
      'Maximum Drawdown (MDD) mencatat penurunan persentase puncak-ke-dasar (peak-to-trough) terdalam pada kurva ekuitas portofolio.',
      'Kombinasi metrik ini membantu trader membedakan apakah hasil profit berasal dari keahlian konsisten atau sekadar keberuntungan spekulatif berisiko tinggi.',
      'Di simulator TRDS Premium, kamu dapat melihat visualisasi metrik ini secara real-time pada tab Simulator Analytics.'
    ],
    example: {
      title: 'Perbandingan Dua Strategi',
      scenario: 'Strategi A menghasilkan return 40% dengan drawdown ekstrem 35%. Strategi B menghasilkan return 25% dengan drawdown terkontrol hanya 6%.',
      analysis: 'Strategi B memiliki Sharpe Ratio jauh lebih superior dan risiko kebangkrutan yang sangat minim. Strategi A sangat rentan hancur sewaktu-waktu.'
    },
    keyTakeaways: [
      'Return tinggi tanpa manajemen risiko adalah bom waktu.',
      'Sharpe Ratio mengukur kualitas profit per unit risiko volatilitas.',
      'Drawdown yang terkontrol menjamin kelangsungan modal jangka panjang.'
    ],
    quiz: {
      id: 'quiz-advanced-risk-sharpe',
      title: 'Kuis Evaluasi Portofolio Pro',
      rewardXp: 45,
      bonusPassXp: 25,
      isPremium: true,
      questions: [
        {
          id: 'qars-1',
          question: 'Mengapa Maximum Drawdown (MDD) menjadi metrik krusial dalam evaluasi trading?',
          options: [
            'Untuk mengetahui jumlah follower di media sosial',
            'Mengukur persentase penurunan modal terbesar dari titik tertinggi sebagai batas toleransi risiko psikologis & modal',
            'Menentukan jumlah biaya penarikan ke rekening bank',
            'Memaksa aplikasi menutup posisi secara acak'
          ],
          correctIndex: 1,
          explanation: 'Drawdown terdalam menunjukkan risiko maksimal yang pernah dialami portofolio sebelum berhasil memulihkan nilai ekuitasnya.'
        }
      ]
    }
  },
  {
    id: 'lesson-multi-timeframe-divergence',
    categoryId: 'indicators',
    title: 'Strategi Konfluensi Multi-Timeframe & RSI Divergence',
    subtitle: 'Mendeteksi sinyal pelemahan momentum tren sebelum pembalikan arah harga terjadi.',
    track: 'advanced',
    durationMinutes: 10,
    readTime: '10 menit',
    xpReward: 40,
    isPremium: true,
    intro: 'Divergensi terjadi ketika pergerakan harga pada grafik tidak lagi didukung oleh momentum osilator teknikal seperti Relative Strength Index (RSI).',
    content: [
      'Bearish Divergence: Harga membentuk Higher High baru, namun puncak RSI justru membentuk Lower High. Ini mengindikasikan bahwa pembeli mulai kehabisan daya dorong.',
      'Bullish Divergence: Harga membentuk Lower Low lebih dalam, namun lembah RSI membentuk Higher Low. Ini menandakan tekanan jual mulai mereda dan potensi pantulan naik terbuka.',
      'Konfluensi Multi-Timeframe: Validitas divergensi meningkat drastis ketika ditemukan di area Support/Resistance utama pada timeframe tinggi (4H atau 1D).',
      'Aturan Eksekusi: Jangan langsung masuk saat divergensi muncul; tunggu konfirmasi lilin penolakan (rejection candle) atau penembusan garis tren minor.'
    ],
    example: {
      title: 'Mengidentifikasi RSI Bearish Divergence',
      scenario: 'Harga Bitcoin mencetak all-time-high baru di $69,000, namun indikator RSI 14-periode di timeframe 4H turun dari level 78 ke 65.',
      analysis: 'Meski harga terlihat naik, kekuatan momentum beli internal melemah drastis. Penurunan korektif besar segera terjadi tak lama kemudian.'
    },
    keyTakeaways: [
      'Divergensi adalah sinyal peringatan dini potensi pembalikan momentum.',
      'Bearish divergence memperingatkan puncak tren naik.',
      'Bullish divergence memperingatkan dasar tren turun.',
      'Selalu gabungkan dengan konfirmasi aksi harga dan manajemen risiko yang ketat.'
    ],
    quiz: {
      id: 'quiz-multi-timeframe-divergence',
      title: 'Kuis RSI Divergence Pro',
      rewardXp: 45,
      bonusPassXp: 25,
      isPremium: true,
      questions: [
        {
          id: 'qdiv-1',
          question: 'Apa yang diindikasikan oleh Bearish Divergence pada grafik teknikal?',
          options: [
            'Harga akan naik tanpa batas selamanya',
            'Harga membuat level tinggi baru namun momentum indikator RSI melemah, memperingatkan potensi koreksi',
            'Koneksi internet pengguna sedang terputus',
            'Order beli akan dieksekusi dengan biaya 0%'
          ],
          correctIndex: 1,
          explanation: 'Bearish divergence mengindikasikan tenaga pembeli mulai habis meskipun harga secara kasat mata masih mencetak titik tertinggi baru.'
        }
      ]
    }
  }
];
